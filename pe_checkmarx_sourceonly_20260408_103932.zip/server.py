"""
Standalone server for running pe_app with HttpPlatformHandler
This uses waitress as a production WSGI server
"""
import os
import sys
from pathlib import Path

# Add the app directory to path
app_dir = Path(__file__).parent
sys.path.insert(0, str(app_dir))

# Import the Flask app
from pe_app import app

if __name__ == '__main__':
    # Get port from environment variable (set by HttpPlatformHandler or AspNetCore)
    port = int(os.environ.get('ASPNETCORE_PORT', os.environ.get('HTTP_PLATFORM_PORT', '8000')))

    print(f"Starting server on port {port}...")
    print(f"App directory: {app_dir}")

    try:
        # Use waitress as the production WSGI server
        from waitress import serve
        print(f"Using waitress WSGI server")
        serve(app, host='127.0.0.1', port=port, threads=4)
    except ImportError:
        # Fallback to Flask's built-in server (not recommended for production)
        print("Warning: waitress not found, using Flask development server")
        app.run(host='127.0.0.1', port=port, debug=False)
