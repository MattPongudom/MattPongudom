# Security Scan Quickstart (PE App)

Use this flow when sharing source with security teams. It avoids the common "no scan results" issue from incomplete zip packages.

## 1) Build a clean scan bundle

From PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File C:\inetpub\wwwroot\pe\scripts\prepare_security_scan_bundle.ps1
```

This creates a timestamped bundle under:

- `C:\inetpub\wwwroot\pe\exports\pe_scan_bundle_YYYYMMDD_HHMMSS.zip`

The bundle excludes noisy/sensitive paths (`venv`, `logs`, `web.config`, backups, caches).

## 2) Team must unzip and scan from the bundle root

Required files are included:

- `requirements-security-scan.txt`
- app source (`*.py`)
- templates/static/scripts (as needed)

If they scan from the wrong folder depth, tools often return no results.

## 3) Recommended scanner commands

### Semgrep (SAST)

```powershell
python -m pip install semgrep
semgrep --config auto --json --output semgrep-report.json .
```

### Bandit (Python SAST)

```powershell
python -m pip install bandit
bandit -r . -f json -o bandit-report.json
```

### pip-audit (dependencies)

```powershell
python -m pip install pip-audit
pip-audit -r requirements-security-scan.txt -f json -o pip-audit-report.json
```

## 4) Why scans usually fail to return results

- Scan started in wrong folder (no Python files at that level)
- Missing dependency file
- Zip included broken directory structure
- Scanner crashed silently on parse/runtime setup
- Report generated but not exported/published

## 5) Minimum items to send back to you

- `bandit-report.json`
- `semgrep-report.json`
- `pip-audit-report.json`
- full scanner console logs
