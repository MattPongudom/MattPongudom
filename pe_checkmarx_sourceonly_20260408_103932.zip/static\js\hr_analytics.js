(function () {
  const data = window.HR_CHARTS || {};
  const centerTextPlugin = {
    id: 'centerText',
    afterDraw(chart) {
      if (chart.config.type !== 'doughnut') return;
      const opts = chart?.options?.plugins?.centerText;
      if (!opts || !opts.display) return;
      const meta = chart.getDatasetMeta(0);
      if (!meta || !meta.data || !meta.data.length) return;
      const x = meta.data[0].x;
      const y = meta.data[0].y;
      const ctx = chart.ctx;
      const total = (chart.data.datasets[0].data || []).reduce((a, b) => a + Number(b || 0), 0);
      const value = opts.value != null ? String(opts.value) : new Intl.NumberFormat().format(total);
      const label = opts.label || 'Total';
      ctx.save();
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = tc.text;
      ctx.font = '700 28px "DM Sans", "Noto Sans Thai", sans-serif';
      ctx.fillText(value, x, y - 4);
      ctx.fillStyle = tc.tick;
      ctx.font = '500 12px "DM Sans", "Noto Sans Thai", sans-serif';
      ctx.fillText(label, x, y + 24);
      ctx.restore();
    },
  };
  if (window.ChartDataLabels) {
    Chart.register(window.ChartDataLabels);
  }
  Chart.register(centerTextPlugin);

  var isDark = document.documentElement.getAttribute('data-theme') === 'dark';
  function themeColors(dark) {
    return {
      text:  dark ? '#e2e8f0' : '#1e293b',
      tick:  dark ? '#94a3b8' : '#475569',
      grid:  dark ? '#334155' : '#e2e8f0',
      label: dark ? '#cbd5e1' : '#0f172a',
      gradEnd: dark ? { r: 51, g: 65, b: 85 } : { r: 226, g: 232, b: 240 },
    };
  }
  var tc = themeColors(isDark);
  var chartInstances = [];

  const palette = {
    blue: '#0284c7',
    cyan: '#06b6d4',
    orange: '#f97316',
    amber: '#f59e0b',
    green: '#16a34a',
    rose: '#e11d48',
    violet: '#7c3aed',
    slate: '#334155',
  };

  function makeTooltipLabel(context) {
    const values = context.dataset.data || [];
    const total = values.reduce((a, b) => a + Number(b || 0), 0);
    const value = Number(context.raw || 0);
    const pct = total > 0 ? ((value / total) * 100).toFixed(1) : '0.0';
    return `${context.label}: ${value} (${pct}%)`;
  }

  function makeDataLabel(value, chart) {
    const arr = chart.data.datasets[0].data || [];
    const total = arr.reduce((a, b) => a + Number(b || 0), 0);
    const pct = total > 0 ? ((Number(value || 0) / total) * 100).toFixed(1) : '0.0';
    return `${value} (${pct}%)`;
  }

  function buildBaseOptions(withScales) {
    const options = {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'nearest', intersect: false },
      plugins: {
        legend: { labels: { color: tc.text } },
        datalabels: { display: false },
        tooltip: {
          enabled: true,
          callbacks: {
            label(context) {
              return makeTooltipLabel(context);
            },
          },
        },
      },
    };
    if (withScales) {
      options.scales = {
        x: { ticks: { color: tc.tick }, grid: { color: tc.grid } },
        y: { ticks: { color: tc.tick }, grid: { color: tc.grid }, beginAtZero: true },
      };
    }
    return options;
  }

  function labelsValues(rows) {
    return {
      labels: (rows || []).map((r) => r.label),
      values: (rows || []).map((r) => Number(r.value || 0)),
    };
  }

  function makeBar(id, rows, color, horizontal, minPctLabel, axisCfg) {
    const el = document.getElementById(id);
    if (!el) return;
    const lv = labelsValues(rows);
    if (horizontal) {
      const targetHeight = Math.max(300, lv.labels.length * 24);
      el.style.height = `${targetHeight}px`;
    }
    const minPct = (minPctLabel == null) ? 3 : Number(minPctLabel);
    const cfg = {
      type: 'bar',
      data: {
        labels: lv.labels,
        datasets: [{
          label: 'Headcount',
          data: lv.values,
          backgroundColor: gradientColors(lv.values, color),
          borderRadius: 6,
          categoryPercentage: horizontal ? 0.78 : 0.72,
          barPercentage: 0.9,
          maxBarThickness: horizontal ? 18 : 34,
        }],
      },
      options: buildBaseOptions(true),
    };
    if (horizontal) cfg.options.indexAxis = 'y';
    if (axisCfg && cfg.options && cfg.options.scales && cfg.options.scales.x) {
      if (axisCfg.max != null) cfg.options.scales.x.max = Number(axisCfg.max);
      if (axisCfg.stepSize != null) cfg.options.scales.x.ticks.stepSize = Number(axisCfg.stepSize);
    }
    cfg.options.scales.x.ticks.autoSkip = false;
    cfg.options.scales.y.ticks.autoSkip = false;
    cfg.options.plugins.datalabels = {
      color: tc.label,
      anchor: horizontal ? 'end' : 'end',
      align: horizontal ? 'right' : 'end',
      offset: 2,
      clamp: true,
      display(ctx) {
        const arr = ctx.chart.data.datasets[0].data || [];
        const total = arr.reduce((a, b) => a + Number(b || 0), 0);
        const value = Number(ctx.raw || 0);
        const pct = total > 0 ? (value / total) * 100 : 0;
        return pct >= minPct;
      },
      formatter(value, ctx) {
        return makeDataLabel(value, ctx.chart);
      },
      font: { weight: '600', size: 10 },
    };
    chartInstances.push(new Chart(el, cfg));
  }

  function makeFunnelJobLevel(id, rows, color, minLevel, maxLevel) {
    const el = document.getElementById(id);
    if (!el) return;

    const minL = Number.isFinite(Number(minLevel)) ? Number(minLevel) : 4;
    const maxL = Number.isFinite(Number(maxLevel)) ? Number(maxLevel) : 13;

    // Normalize job levels into a fixed range so the funnel always shows 4..13.
    const map = {};
    (rows || []).forEach((r) => {
      const k = String(r && r.label != null ? r.label : '').trim();
      if (!k) return;
      map[k] = Number(r.value || 0);
    });

    const levelsAsc = [];
    for (let l = minL; l <= maxL; l++) levelsAsc.push(String(l));
    const labels = levelsAsc.slice().reverse(); // highest at top, JL4 at bottom
    const values = labels.map((k) => Number(map[k] || 0));

    const maxVal = Math.max(...values, 0);
    const xStep = 100;
    const xMax = maxVal > 0 ? Math.ceil(maxVal / xStep) * xStep : xStep;
    // Slightly left-shift the funnel so wide bars don't collide with the right edge.
    // Total padding is (xMax - v). We allocate more of it to the right side.
    const leftFactor = 0.35; // < 0.5 shifts bars left
    const padL = values.map((v) => (xMax - v) * leftFactor);
    const padR = values.map((v) => (xMax - v) * (1 - leftFactor));

    // Make the chart taller so all job levels are readable.
    el.style.height = `${Math.max(320, labels.length * 26)}px`;

    const cfg = {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label: '__padL',
            data: padL,
            backgroundColor: 'rgba(0,0,0,0)',
            borderWidth: 0,
            borderRadius: 0,
            stack: 's',
          },
          {
            label: 'Headcount',
            data: values,
            backgroundColor: gradientColors(values, color || '#7c3aed'),
            borderRadius: 8,
            maxBarThickness: 20,
            stack: 's',
          },
          {
            label: '__padR',
            data: padR,
            backgroundColor: 'rgba(0,0,0,0)',
            borderWidth: 0,
            borderRadius: 0,
            stack: 's',
          },
        ],
      },
      options: (function () {
        const opt = buildBaseOptions(true);
        opt.indexAxis = 'y';
        opt.scales.x.stacked = true;
        opt.scales.y.stacked = true;
        // Keep the funnel contained and readable.
        opt.scales.x.max = xMax;
        opt.scales.x.ticks.stepSize = xStep;
        opt.scales.x.grace = '0%';
        opt.scales.x.ticks.autoSkip = false;
        opt.scales.y.ticks.autoSkip = false;
        opt.layout = { padding: { right: 26 } };
        opt.plugins.legend = {
          display: false,
        };
        opt.plugins.tooltip.callbacks.label = function (ctx) {
          if (!ctx || !ctx.dataset || ctx.dataset.label !== 'Headcount') return null;
          return makeTooltipLabel(ctx);
        };
        opt.plugins.datalabels = {
          color: tc.label,
          anchor: 'end',
          // Dynamically keep labels inside the plot area when bars approach the max gridline.
          align(ctx) {
            if (!ctx || !ctx.chart) return 'right';
            if (!ctx.dataset || ctx.dataset.label !== 'Headcount') return 'right';
            const meta = ctx.chart.getDatasetMeta(ctx.datasetIndex);
            const el = meta && meta.data ? meta.data[ctx.dataIndex] : null;
            const right = ctx.chart.chartArea ? ctx.chart.chartArea.right : null;
            if (!el || right == null) return 'right';
            const barRight = el.x; // px
            return (right - barRight) < 70 ? 'left' : 'right';
          },
          offset(ctx) {
            if (!ctx || !ctx.chart) return 2;
            if (!ctx.dataset || ctx.dataset.label !== 'Headcount') return 0;
            const meta = ctx.chart.getDatasetMeta(ctx.datasetIndex);
            const el = meta && meta.data ? meta.data[ctx.dataIndex] : null;
            const right = ctx.chart.chartArea ? ctx.chart.chartArea.right : null;
            if (!el || right == null) return 2;
            const barRight = el.x;
            return (right - barRight) < 70 ? -6 : 2;
          },
          clamp: true,
          clip: true,
          display(ctx) {
            return ctx.dataset && ctx.dataset.label === 'Headcount';
          },
          formatter(value, ctx) {
            return makeDataLabel(value, ctx.chart);
          },
          font: { weight: '600', size: 10 },
        };
        return opt;
      })(),
    };

    chartInstances.push(new Chart(el, cfg));
  }

  function orderJobLevels(rows, minLevel, maxLevel) {
    const minL = Number.isFinite(Number(minLevel)) ? Number(minLevel) : 4;
    const maxL = Number.isFinite(Number(maxLevel)) ? Number(maxLevel) : 13;
    const map = {};
    (rows || []).forEach((r) => {
      const k = String(r && r.label != null ? r.label : '').trim();
      if (!k) return;
      map[k] = Number(r.value || 0);
    });
    const out = [];
    // y-axis renders top-to-bottom; use descending labels so JL4 ends up at the bottom.
    for (let l = maxL; l >= minL; l--) {
      const key = String(l);
      out.push({ label: key, value: Number(map[key] || 0) });
    }
    return out;
  }

  function makeDoughnut(id, rows, colors) {
    const el = document.getElementById(id);
    if (!el) return;
    const lv = labelsValues(rows);
    chartInstances.push(new Chart(el, {
      type: 'doughnut',
      data: {
        labels: lv.labels,
        datasets: [{ data: lv.values, backgroundColor: colors }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        aspectRatio: 1,
        cutout: '62%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: { color: tc.text, usePointStyle: true, pointStyle: 'rectRounded', boxWidth: 10, boxHeight: 10 },
          },
          centerText: { display: id === 'degreeChart' },
          tooltip: buildBaseOptions(false).plugins.tooltip,
          datalabels: {
            color: tc.label,
            display(ctx) {
              const arr = ctx.chart.data.datasets[0].data || [];
              const total = arr.reduce((a, b) => a + Number(b || 0), 0);
              const value = Number(ctx.raw || 0);
              const pct = total > 0 ? (value / total) * 100 : 0;
              return pct >= 4;
            },
            formatter(value, ctx) {
              return makeDataLabel(value, ctx.chart);
            },
            font: { weight: '600', size: 10 },
          },
        },
      },
    }));
  }

  function makePie(id, rows, colors) {
    const el = document.getElementById(id);
    if (!el) return;
    const lv = labelsValues(rows);
    if (!lv.labels.length) {
      // Render a friendly placeholder instead of a blank card.
      if (el.parentElement) {
        el.style.display = 'none';
        if (!el.parentElement.querySelector('.chart-empty')) {
          el.parentElement.insertAdjacentHTML('beforeend', '<div class=\"chart-empty\">No data available for this chart.</div>');
        }
      }
      return;
    }
    chartInstances.push(new Chart(el, {
      type: 'pie',
      data: {
        labels: lv.labels,
        datasets: [{ data: lv.values, backgroundColor: colors }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        aspectRatio: 1,
        plugins: {
          legend: { labels: { color: tc.text } },
          tooltip: buildBaseOptions(false).plugins.tooltip,
          datalabels: {
            color: tc.label,
            display(ctx) {
              const arr = ctx.chart.data.datasets[0].data || [];
              const total = arr.reduce((a, b) => a + Number(b || 0), 0);
              const value = Number(ctx.raw || 0);
              const pct = total > 0 ? (value / total) * 100 : 0;
              return pct >= 4;
            },
            formatter(value, ctx) {
              return makeDataLabel(value, ctx.chart);
            },
            font: { weight: '600', size: 10 },
          },
        },
      },
    }));
  }

  function buildColors(count) {
    const pool = ['#0284c7', '#06b6d4', '#16a34a', '#f59e0b', '#f97316', '#7c3aed', '#334155', '#e11d48', '#0ea5e9', '#14b8a6'];
    return Array.from({ length: count }, (_, i) => pool[i % pool.length]);
  }

  function gradientColors(values, baseColor) {
    const maxVal = Math.max(...(values || [0]), 0);
    const minVal = Math.min(...(values || [0]), 0);
    const range = Math.max(1, maxVal - minVal);
    const start = hexToRgb(baseColor || '#0284c7');
    const end = tc.gradEnd;
    return (values || []).map((v) => {
      const t = (maxVal - Number(v || 0)) / range;
      const r = Math.round(start.r * (1 - t) + end.r * t);
      const g = Math.round(start.g * (1 - t) + end.g * t);
      const b = Math.round(start.b * (1 - t) + end.b * t);
      return `rgb(${r}, ${g}, ${b})`;
    });
  }

  function hexToRgb(hex) {
    const h = String(hex || '').replace('#', '');
    if (h.length !== 6) return { r: 2, g: 132, b: 199 };
    return {
      r: parseInt(h.slice(0, 2), 16),
      g: parseInt(h.slice(2, 4), 16),
      b: parseInt(h.slice(4, 6), 16),
    };
  }

  makeBar('divisionChart', data.division, palette.blue, true);
  makeBar('universityChart', data.universities, palette.violet, true);
  makeDoughnut('instituteTypeChart', data.institute_type, buildColors((data.institute_type || []).length));
  makeDoughnut('degreeChart', data.degree, buildColors((data.degree || []).length));
  makeDoughnut('techMixChart', data.tech_mix, ['#0ea5e9', '#14b8a6', '#f59e0b', '#94a3b8']);
  makeDoughnut('employmentMixChart', data.employment_mix, ['#2563eb', '#f59e0b', '#94a3b8']);
  makeBar('jobLevelChart', orderJobLevels(data.job_level, 4, 13), palette.violet, true, 0, { stepSize: 100, max: 500 });
  makeBar('ageGroupChart', data.age_group, palette.amber, false);
  makeBar('tenureChart', data.tenure, palette.green, false);
  makeDoughnut('generationChart', data.generation, buildColors((data.generation || []).length));
  makeDoughnut('companyChart', data.company, buildColors((data.company || []).length));
  makeDoughnut('genderChart', data.gender, ['#0ea5e9', '#f43f5e', '#a855f7', '#22c55e']);

  const trendEl = document.getElementById('trendChart');
  if (trendEl && data.trend) {
    chartInstances.push(new Chart(trendEl, {
      type: 'line',
      data: {
        labels: data.trend.labels || [],
        datasets: [
          {
            label: 'Hires',
            data: data.trend.hires || [],
            borderColor: '#0284c7',
            backgroundColor: 'rgba(2,132,199,.14)',
            tension: .25,
            fill: true,
          },
          {
            label: 'Resignations',
            data: data.trend.resigns || [],
            borderColor: '#ef4444',
            backgroundColor: 'rgba(239,68,68,.14)',
            tension: .25,
            fill: true,
          },
        ],
      },
      options: buildBaseOptions(true),
    }));
  }

  const yearlyEl = document.getElementById('yearlyRatesChart');
  if (yearlyEl && data.yearly_metrics) {
    chartInstances.push(new Chart(yearlyEl, {
      type: 'line',
      data: {
        labels: data.yearly_metrics.labels || [],
        datasets: [
          {
            label: 'Growth Rate %',
            data: data.yearly_metrics.growth_rate || [],
            borderColor: '#0284c7',
            backgroundColor: 'rgba(2,132,199,.14)',
            tension: .25,
            fill: true,
          },
          {
            label: 'Turnover Rate %',
            data: data.yearly_metrics.turnover_rate || [],
            borderColor: '#f97316',
            backgroundColor: 'rgba(249,115,22,.14)',
            tension: .25,
            fill: true,
          },
        ],
      },
      options: buildBaseOptions(true),
    }));
  }

  function makeRateTooltip(payload) {
    return function(context) {
      const idx = context.dataIndex;
      const rate = Number(context.raw || 0);
      const resigns = (payload && payload.resigns && payload.resigns[idx] != null) ? payload.resigns[idx] : null;
      const headcount = (payload && payload.headcount && payload.headcount[idx] != null) ? payload.headcount[idx] : null;
      const startHc = (payload && payload.start_headcount && payload.start_headcount[idx] != null) ? payload.start_headcount[idx] : null;
      const endHc = (payload && payload.end_headcount && payload.end_headcount[idx] != null) ? payload.end_headcount[idx] : null;
      const denomLabel = (payload && payload.denominator_label) ? payload.denominator_label : 'headcount';
      if (resigns == null || headcount == null) return `${context.label}: ${rate}%`;
      if (startHc != null && endHc != null) {
        return `${context.label}: ${rate}% (resigned ${resigns}, ${denomLabel} ${headcount}; start ${startHc}, end ${endHc})`;
      }
      return `${context.label}: ${rate}% (resigned ${resigns}, ${denomLabel} ${headcount})`;
    };
  }

  function makeRateLine(id, payload, color) {
    const el = document.getElementById(id);
    if (!el || !payload) return;
    chartInstances.push(new Chart(el, {
      type: 'line',
      data: {
        labels: payload.labels || [],
        datasets: [{
          label: 'Turnover Rate %',
          data: payload.rates || [],
          borderColor: color || '#f97316',
          backgroundColor: 'rgba(249,115,22,.14)',
          tension: .25,
          fill: true,
        }],
      },
      options: (function() {
        const opt = buildBaseOptions(true);
        opt.plugins.tooltip.callbacks.label = makeRateTooltip(payload);
        opt.scales.y.ticks.callback = function(v) { return v + '%'; };
        return opt;
      })(),
    }));
  }

  function makeRateBar(id, payload, color) {
    const el = document.getElementById(id);
    if (!el || !payload) return;
    chartInstances.push(new Chart(el, {
      type: 'bar',
      data: {
        labels: payload.labels || [],
        datasets: [{
          label: 'Turnover Rate %',
          data: payload.rates || [],
          backgroundColor: gradientColors(payload.rates || [], color || '#f97316'),
          borderRadius: 6,
          maxBarThickness: 34,
        }],
      },
      options: (function() {
        const opt = buildBaseOptions(true);
        opt.plugins.tooltip.callbacks.label = makeRateTooltip(payload);
        opt.scales.y.ticks.callback = function(v) { return v + '%'; };
        return opt;
      })(),
    }));
  }

  makeRateLine('turnoverMonthlyChart', data.turnover_monthly, '#f97316');
  makeRateBar('turnoverQuarterlyChart', data.turnover_quarterly, '#f59e0b');
  makeRateBar('turnoverYearlyChart', data.turnover_yearly, '#fb923c');

  function makeHeadcountLine(id, payload, color) {
    const el = document.getElementById(id);
    if (!el || !payload) return;
    const labels = payload.labels || [];
    const series = payload.headcount || [];
    if (!labels.length || !series.length) return;
    chartInstances.push(new Chart(el, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: 'Active Employees (Month-End)',
          data: series,
          borderColor: color || '#0284c7',
          backgroundColor: 'rgba(2,132,199,.14)',
          tension: .25,
          fill: true,
          pointRadius: 3,
          pointHoverRadius: 5,
        }],
      },
      options: (function() {
        const opt = buildBaseOptions(true);
        opt.plugins.tooltip.callbacks.label = function(ctx) {
          const v = Number(ctx.raw || 0);
          return `${ctx.label}: ${v.toLocaleString()} active`;
        };
        opt.plugins.datalabels = { display: false };
        opt.scales.y.ticks.callback = function(v) { return Number(v).toLocaleString(); };
        // Improve readability for headcount scale
        opt.scales.y.beginAtZero = true;
        return opt;
      })(),
    }));
  }

  function makeSeasonalityLine(id, payload) {
    const el = document.getElementById(id);
    if (!el || !payload) return;
    const labels = payload.labels || [];
    const series = payload.series || {};
    if (!labels.length) return;

    const colors = ['#0284c7', '#16a34a', '#f97316'];
    const fillColors = ['rgba(2,132,199,.12)', 'rgba(22,163,74,.10)', 'rgba(249,115,22,.10)'];
    const years = Object.keys(series).sort();
    const datasets = years.map((y, idx) => ({
      label: String(y),
      data: series[y] || [],
      borderColor: colors[idx % colors.length],
      backgroundColor: fillColors[idx % fillColors.length],
      tension: .25,
      fill: false,
      pointRadius: 3,
      pointHoverRadius: 5,
      spanGaps: true,
    }));

    chartInstances.push(new Chart(el, {
      type: 'line',
      data: { labels, datasets },
      options: (function() {
        const opt = buildBaseOptions(true);
        opt.plugins.datalabels = { display: false };
        opt.plugins.tooltip.callbacks.label = function(ctx) {
          const v = ctx.raw;
          if (v == null || v === '') return `${ctx.dataset.label}: -`;
          return `${ctx.dataset.label}: ${Number(v).toLocaleString()} active`;
        };
        opt.scales.y.ticks.callback = function(v) { return Number(v).toLocaleString(); };
        opt.scales.y.beginAtZero = true;
        return opt;
      })(),
    }));
  }

  makeSeasonalityLine('activeHeadcountChart', data.active_seasonality);

  function escapeHtml(s) {
    // Avoid String.prototype.replaceAll for older browsers.
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function getFilterSummaryLines() {
    const ids = [
      'calendar_year', 'calendar_month',
      'company', 'division', 'department',
      'job_level', 'gender', 'generation',
      'tech_nontech', 'work_location',
    ];
    const labels = {
      calendar_year: 'Year',
      calendar_month: 'Month',
      company: 'Company',
      division: 'Division',
      department: 'Department',
      job_level: 'Job Level',
      gender: 'Gender',
      generation: 'Generation',
      tech_nontech: 'Tech/Non-Tech',
      work_location: 'Work Location',
    };

    const parts = [];
    ids.forEach(function(id) {
      const el = document.getElementById(id);
      if (!el) return;
      const v = (el.value || '').trim();
      if (!v) return;
      if (id === 'calendar_month') {
        const mm = String(v).padStart(2, '0');
        parts.push(`${labels[id]}: ${mm}`);
        return;
      }
      parts.push(`${labels[id]}: ${v}`);
    });

    const asOf = (document.querySelector('.month-badge') && document.querySelector('.month-badge').textContent) ? document.querySelector('.month-badge').textContent.trim() : '';
    const lines = [];
    if (asOf) lines.push(`As of: ${asOf.replace(/^As of\\s*/i, '')}`);
    if (parts.length) lines.push(parts.join('  |  '));
    if (!parts.length) lines.push('Filters: All');
    return lines;
  }

  function canvasToImgHtml(canvasId) {
    const c = document.getElementById(canvasId);
    if (!c || !c.toDataURL) return '<div class="ph">Chart unavailable</div>';
    try {
      const url = c.toDataURL('image/png', 1.0);
      return `<img class="chart-img" src="${url}" alt="${escapeHtml(canvasId)}" />`;
    } catch (e) {
      return '<div class="ph">Chart unavailable</div>';
    }
  }

  function payloadToTableHtml(title, payload, limitLastN, denominatorAsInteger) {
    if (!payload || !payload.labels || !payload.rates) {
      return `<div class="ph">${escapeHtml(title)} data unavailable</div>`;
    }
    const labels = payload.labels || [];
    const rates = payload.rates || [];
    const resigns = payload.resigns || [];
    const headcount = payload.headcount || [];

    let start = 0;
    if (limitLastN && labels.length > limitLastN) start = labels.length - limitLastN;

    let rows = '';
    for (let i = start; i < labels.length; i++) {
      const period = labels[i] != null ? String(labels[i]) : '';
      const r = (rates[i] != null && rates[i] !== '') ? Number(rates[i]) : null;
      const resign = (resigns[i] != null && resigns[i] !== '') ? Number(resigns[i]) : null;
      const hc = (headcount[i] != null && headcount[i] !== '') ? Number(headcount[i]) : null;
      const rDisp = (r == null || Number.isNaN(r)) ? '' : r.toFixed(2);
      const resignDisp = (resign == null || Number.isNaN(resign)) ? '' : String(resign);
      const hcDisp = (hc == null || Number.isNaN(hc))
        ? ''
        : (denominatorAsInteger ? String(Math.round(hc)) : String(hc));
      rows += `<tr><td>${escapeHtml(period)}</td><td>${escapeHtml(hcDisp)}</td><td>${escapeHtml(resignDisp)}</td><td>${escapeHtml(rDisp)}</td></tr>`;
    }

    return `
      <div class="table-block">
        <h2>${escapeHtml(title)}</h2>
        <table>
          <thead>
            <tr>
              <th>Period</th>
              <th>Active Headcount (End)</th>
              <th>Resigned</th>
              <th>Turnover Rate %</th>
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </div>
    `;
  }

  function buildTurnoverPrintHtml() {
    const title = 'Turnover Rate Report';
    const now = new Date();
    const dt = now.toLocaleString();
    const lines = getFilterSummaryLines();

    // Build tables from the chart payload (more reliable than scraping DOM).
    const monthlyTable = payloadToTableHtml('Monthly (Latest 13)', data.turnover_monthly, 13, false);
    const quarterlyTable = payloadToTableHtml('Quarterly', data.turnover_quarterly, null, true);
    const yearlyTable = payloadToTableHtml('Yearly', data.turnover_yearly, null, true);

    const monthlyImg = canvasToImgHtml('turnoverMonthlyChart');
    const quarterlyImg = canvasToImgHtml('turnoverQuarterlyChart');
    const yearlyImg = canvasToImgHtml('turnoverYearlyChart');

    return `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(title)}</title>
  <style>
    :root { color-scheme: light; }
    body { font-family: Arial, sans-serif; margin: 22px; color: #0f172a; }
    h1 { margin: 0; font-size: 22px; }
    .meta { margin-top: 6px; color: #475569; font-size: 12px; }
    .meta div { margin-top: 2px; }
    .grid { display: grid; grid-template-columns: 1fr; gap: 14px; margin-top: 14px; }
    .card { border: 1px solid #e2e8f0; border-radius: 12px; padding: 12px; }
    .charts { display: grid; grid-template-columns: 1fr; gap: 12px; }
    .chart-block h2 { margin: 0 0 8px; font-size: 14px; color: #1e293b; }
    .chart-img { width: 100%; max-height: 320px; object-fit: contain; border: 1px solid #e2e8f0; border-radius: 10px; }
    .ph { padding: 16px; background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 10px; color: #64748b; }
    .table-block h2 { margin: 12px 0 6px; font-size: 14px; color: #1e293b; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 12px; }
    th, td { border: 1px solid #e2e8f0; padding: 6px 8px; text-align: left; }
    thead th { background: #f1f5f9; }
    @media print {
      body { margin: 0.4in; }
      .card { break-inside: avoid; }
      .chart-img { max-height: 260px; }
    }
  </style>
</head>
<body>
  <h1>${escapeHtml(title)}</h1>
    <div class="meta">
      <div>Generated: ${escapeHtml(dt)}</div>
      ${lines.map(l => `<div>${escapeHtml(l)}</div>`).join('')}
    </div>

  <div class="grid">
    <div class="card charts">
      <div class="chart-block">
        <h2>Monthly</h2>
        ${monthlyImg}
      </div>
      <div class="chart-block">
        <h2>Quarterly</h2>
        ${quarterlyImg}
      </div>
      <div class="chart-block">
        <h2>Yearly</h2>
        ${yearlyImg}
      </div>
    </div>

    <div class="card">
      <h2 style="margin:0; font-size:14px;">Turnover Rate Data Tables</h2>
      ${monthlyTable}
      ${quarterlyTable}
      ${yearlyTable}
    </div>
  </div>

  <script>
    // Give the browser time to decode chart images before printing.
    window.addEventListener('load', function() { setTimeout(function(){ window.print(); }, 800); });
  </script>
</body>
</html>`;
  }

  function openTurnoverPrint() {
    let w = null;
    try {
      const html = buildTurnoverPrintHtml();
      // Some browsers return a window handle that is not writable when using 'noopener' in features.
      // Keep features minimal for reliability.
      w = window.open('', '_blank', 'width=980,height=780');
      if (!w) return;
      w.document.open();
      w.document.write(html);
      w.document.close();
    } catch (e) {
      console.error('Turnover print failed', e);
      try {
        if (!w) w = window.open('', '_blank', 'width=980,height=780');
        if (w) {
          const msg = (e && (e.stack || e.message)) ? (e.stack || e.message) : String(e);
          w.document.open();
          w.document.write('<!doctype html><meta charset="utf-8"><title>Print Error</title><pre style="white-space:pre-wrap;font-family:Arial,sans-serif;padding:16px;">Print failed:\\n' + escapeHtml(msg) + '</pre>');
          w.document.close();
        }
      } catch (_) {}
      alert('Print failed. Open DevTools Console for details.');
    }
  }

  (function wirePrintButton() {
    const btn = document.getElementById('printTurnoverBtn');
    if (!btn) return;
    btn.addEventListener('click', openTurnoverPrint);
  })();

  // Live theme update for all charts
  window.updateChartsTheme = function(dark) {
    tc = themeColors(dark);
    chartInstances.forEach(function(chart) {
      if (chart.options.plugins && chart.options.plugins.legend && chart.options.plugins.legend.labels) {
        chart.options.plugins.legend.labels.color = tc.text;
      }
      if (chart.options.plugins && chart.options.plugins.datalabels && chart.options.plugins.datalabels !== false) {
        if (typeof chart.options.plugins.datalabels === 'object') {
          chart.options.plugins.datalabels.color = tc.label;
        }
      }
      if (chart.options.scales) {
        ['x', 'y'].forEach(function(axis) {
          if (chart.options.scales[axis]) {
            if (chart.options.scales[axis].ticks) chart.options.scales[axis].ticks.color = tc.tick;
            if (chart.options.scales[axis].grid) chart.options.scales[axis].grid.color = tc.grid;
          }
        });
      }
      chart.update();
    });
  };
})();
