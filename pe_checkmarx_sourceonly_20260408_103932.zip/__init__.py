# Marks performanceapp as a package for WSGI imports.
