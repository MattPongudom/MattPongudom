from typing import Dict, Any, Optional, TypedDict, Union, cast
from decimal import Decimal
import json

class UserDict(TypedDict):
    employee_id: str
    username: str
    password: str

class ProfileDict(TypedDict):
    employee_id: str
    data_json: Optional[str]

class ScoreData(TypedDict):
    total_score: Union[str, float]
    group_result: Union[str, float]

def safe_get(d: Optional[Dict[str, Any]], key: str, default: Any = None) -> Any:
    """Safely get a value from a dictionary"""
    if d is None:
        return default
    return d.get(key, default)

def safe_float(value: Any, default: float = 0.0) -> float:
    """Safely convert a value to float"""
    if value is None:
        return default
    try:
        if isinstance(value, str):
            value = value.strip()
            if value.replace('.', '', 1).isdigit():
                return float(value)
            return default
        return float(value)
    except (ValueError, TypeError):
        return default

def safe_int(value: Any, default: int = 0) -> int:
    """Safely convert a value to int"""
    try:
        if value is None:
            return default
        return int(float(str(value)))
    except (ValueError, TypeError):
        return default

def safe_dict_get(value: Any) -> Dict[str, Any]:
    """Safely convert a value to a dictionary"""
    if isinstance(value, dict):
        return value
    if value is None:
        return {}
    try:
        if isinstance(value, str):
            return json.loads(value)
        return dict(value)
    except (ValueError, TypeError, AttributeError):
        return {}