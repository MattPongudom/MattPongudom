from flask import Flask, g, redirect, request, session, url_for
from decimal import Decimal
import base64
import json
import mysql.connector
from mysql.connector import Error
from mysql.connector.connection import MySQLConnection
from mysql.connector.pooling import PooledMySQLConnection
from mysql.connector.cursor import MySQLCursor
import csv
import os
import re
import sys
import secrets
import tempfile
import time
import datetime
import requests
import msal
from urllib.parse import quote, quote_plus
from typing import Union, Dict, Any, Optional, TypeVar, Type, List, Tuple, cast, TypedDict
from pathlib import Path
from pe_helpers import safe_get, safe_float, safe_int, safe_dict_get

# Enhanced type definitions with proper type vars
T = TypeVar('T')
ConnectionType = Union[MySQLConnection, PooledMySQLConnection]
CursorType = MySQLCursor
RowType = Dict[str, Any]

def handle_cursor(connection: Optional[ConnectionType]) -> Optional[CursorType]:
    """Helper to safely create a cursor with proper typing"""
    if not connection:
        return None
    try:
        cursor = connection.cursor(dictionary=True)
        return cast(MySQLCursor, cursor)
    except Exception as e:
        print(f"Error creating cursor: {e}")
        return None


def _get_request_cache(cache_name: str) -> Dict[Any, Any]:
    cache = getattr(g, cache_name, None)
    if not isinstance(cache, dict):
        cache = {}
        setattr(g, cache_name, cache)
    return cache

class UserProfile(TypedDict):
    employee_id: str
    username: str
    password: str

class EmployeeProfile(TypedDict):
    employee_id: str
    data_json: Optional[str]
    name: Optional[str]

class ScoreDataType(TypedDict):
    total_score: Union[str, float]
    group_result: Union[str, float]

from flask import Flask, render_template_string, request, session, redirect, url_for, flash, send_file, \
    after_this_request, jsonify
from mysql.connector import Error

from flask import make_response
from weasyprint import HTML, CSS

try:
    import requests
except ImportError:
    requests = None

# Ensure DB tables exist once per process (IIS won't hit __main__)
_tables_verified = False

# Helper functions for safe data handling
def safe_get(d: Optional[Dict[str, Any]], key: str, default: Any = None) -> Any:
    """Safely get a value from a dictionary"""
    if d is None:
        return default
    return d.get(key, default)

def safe_float(value: Any, default: float = 0.0) -> float:
    """Safely convert a value to float"""
    if value is None:
        return default
    try:
        if isinstance(value, str):
            value = value.strip()
            if value.replace('.', '', 1).isdigit():
                return float(value)
            return default
        return float(value)
    except (ValueError, TypeError):
        return default

def safe_int(value: Any, default: int = 0) -> int:
    """Safely convert a value to int"""
    try:
        if value is None:
            return default
        return int(float(str(value)))
    except (ValueError, TypeError):
        return default

app = Flask(__name__)
# app.secret_key = 'super_secret_key'
app.secret_key = os.environ.get('APP_SECRET_KEY', secrets.token_urlsafe(32))


@app.before_request
def _ensure_tables_once():
    global _tables_verified
    if _tables_verified:
        return
    verify_table_exists()
    verify_versions_table_exists()
    verify_summary_table_exists()
    verify_supervisor_review_table_exists()
    verify_staff_promotion_table_exists()
    _tables_verified = True

# Database connection configuration
DB_CONFIG = {
    'host': os.environ.get('PE_DB_HOST', os.environ.get('HR_DB_HOST', 'localhost')),
    'port': int(os.environ.get('PE_DB_PORT', os.environ.get('HR_DB_PORT', '3306'))),
    'user': os.environ.get('PE_DB_USER', os.environ.get('HR_DB_USER', 'root')),
    'password': os.environ.get('PE_DB_PASSWORD', os.environ.get('HR_DB_PASSWORD', '')).strip(),
    'database': os.environ.get('PE_DB_NAME', os.environ.get('HR_DB_NAME', 'performance_eval_db')),
    'autocommit': True
}

DB_NAME = "performance_eval_db"
TABLE_NAME = "staff_saveddata"
TABLE_FQN = f"`{DB_NAME}`.`{TABLE_NAME}`"
VERSIONS_TABLE_NAME = "staff_saveddata_versions"
VERSIONS_TABLE_FQN = f"`{DB_NAME}`.`{VERSIONS_TABLE_NAME}`"
SUMMARY_TABLE_NAME = "staff_summary_history"
SUMMARY_TABLE_FQN = f"`{DB_NAME}`.`{SUMMARY_TABLE_NAME}`"
SUPERVISOR_REVIEW_TABLE_NAME = "staff_supervisor_reviews"
SUPERVISOR_REVIEW_TABLE_FQN = f"`{DB_NAME}`.`{SUPERVISOR_REVIEW_TABLE_NAME}`"
STAFF_PROMOTION_TABLE_NAME = "staff_promotion_forms"
STAFF_PROMOTION_TABLE_FQN = f"`{DB_NAME}`.`{STAFF_PROMOTION_TABLE_NAME}`"
AUTHORIZED_EXPORTER_ID = ('10300069', '10300044', '10300476', '11007655') # Primary admin employee IDs for special access
# Use a numeric-like ID to avoid DB type issues; store global Group KPI under the primary admin ID
GLOBAL_GROUP_KPI_EMPLOYEE_ID = AUTHORIZED_EXPORTER_ID
DIVISION_REVENUE_EBITDA_ADMIN_ID = "__DIVISION_REVENUE_EBITDA_ADMIN__"
HR_DIRECTOR_EMPLOYEE_ID = '10300476'
STAFF_PROMOTION_TESTER_ID = '10300069'
STAFF_PROMOTION_MODULE_ENABLED = True
ADMIN_MANAGED_GROUP_KPI_COMPANIES = {
    'TCCtech',
    'Shinasub',
    'Data Assets',
    'Leap Solutions Asia',
}

# Azure AD / MSAL configuration
TENANT = os.environ.get("AAD_TENANT_ID", "")
CLIENT_ID = os.environ.get("AAD_CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("AAD_CLIENT_SECRET", "")
AUTHORITY = f"https://login.microsoftonline.com/{TENANT}" if TENANT else ""
# Keep login scope minimal so users can authenticate even before admin consent is granted.
# Cross-user photo retrieval will use best-effort fallback and placeholder when unavailable.
AAD_SCOPES = ["User.Read"]  # Note: openid, profile, offline_access are automatically added by MSAL
AAD_REDIRECT_URI = os.environ.get("AAD_REDIRECT_URI", "https://pe.tcc-technology.com/auth/callback")

SPECIAL_EXPORT_ACCESS = {
    '10300069': None, # Developer
    '11007655': None, # Managing Director
    '10300476': None, # HR&Admin Director
    '10300044': None, # HRM Manager
    '10300098': ['Business Strategy'],
    '10300040': ['Client & Service Support - Rental & License Trading',
                 'Client & Service Support - Call Center Service Desk', 'Client & Service Support - IT Outsourcing',
                 'Client & Service Support - IT Services'],
    '10300064': ['Client Engagement - Sales & Sales Support', 'Business Strategy', 'Presales/PM'],
    '10300003': ['Data Assets', 'Solution Development - Application Development 1', 'Solution Development - Application Development 2',
                 'Solution Development - Application Development 3', 'Solution Development - Data Management',
                 'Solution Development - Cyber Security Solution', 'Operation'],
    '10300004': ['Corporate Communications - Marketing & Public Relations',
                 'Corporate Communications - Quality Assurance'],
    '10300006': ['Enterprise Operation - Connectivity', 'Enterprise Operation - ICT Operation',
                 'Enterprise Operation - Network Services', 'Shinasub'],
    '10300200': ['Enterprise Service - Application Managed Services'],
    '10300071': ['Finance & Business Support - Procurement'],
    '10300002': ['Finance & Business Support', 'Finance & Business Support - Legal',
                 'Finance & Business Support - Financial Planning & Analysis',
                 'Finance & Business Support - Finance & Accounting', 'Finance & Busines Support - Procurement',
                 'Finance & Business Support - Finance', 'Finance & Business Support - Accounting'],
    '10300016': ['Infrastructure - Data Center'],
    '10300299': ['Presales/PM'],
    '10300221': ['Smart Solution', 'Smart Solution - GIS', 'Smart Solution - District Command Center',
                 'Smart Solution - Center of Excellence'],
    '10305007': ['SAP Basis Managed Services', 'Cloud Infrastructure Services', 'Cloud Managed Services',
                 'DevOps Managed Services', 'SAP Infrastructure Services', 'Technical Support Center'],
    '63200': ['TSpace', 'Analytics Solution', 'Corporate Supports', 'Situation Awareness', 'Digital Marketing'],
    '00000000': ['Argento Tech', 'Business Innovation - Business Development', 'Technology Innovation - Quality Assurance', 'Business Innovation - Business Solution', 'Technology Innovation - System', 'Technology Innovation - Application Development', 'Business Operation - Commercial Support']
    }

# Division exclusions per admin (visibility + exports)
EXCLUDED_DIVISIONS_BY_EMPLOYEE = {
    '11007655': ['TSpace', 'Analytics Solution', 'Corporate Supports', 'Situation Awareness', 'Digital Marketing'],
}
TSPACE_LABELS = {'TSpace'}
TEMP_BLOCKED_PE_COMPANIES = {'TSpace', 'Argento Tech'}
PE_EXCLUDED_COMPANY_SQL = "TRIM(IFNULL(e.company, '')) NOT IN ('TSpace', 'Argento Tech')"
PE_ACTIVE_EMPLOYEE_MASTER_CONDITION = "LOWER(TRIM(IFNULL(em.employee_status, ''))) IN ('active', 'working')"
PE_PERMANENT_EMPLOYEE_MASTER_CONDITION = "LOWER(TRIM(IFNULL(em.employment_status, ''))) = 'permanent'"

# Admin helpers
ADMIN_EMPLOYEE_IDS = set(list(SPECIAL_EXPORT_ACCESS.keys()) + list(AUTHORIZED_EXPORTER_ID))

FIXED_BU_LOB_DIVISIONS = {
    'Client & Service Support',
    'Infrastructure',
    'Enterprise Operation',
    'Enterprise Service',
    'Smart Solution',
    'Solution Development',
    'Operation',
    'Technology',
    'Shinasub',
}
DIVISION_REVENUE_EBITDA_TARGET_DIVISIONS = (
    'Solution Development',
    'Smart Solution',
    'Infrastructure',
    'Enterprise Operation',
    'Enterprise Service',
    'Client & Service Support',
)
DIVISION_REVENUE_EBITDA_TARGET_COMPANIES = (
    'Leap Solutions Asia',
    'Shinasub',
    'Data Assets',
)
DIVISION_REVENUE_EBITDA_COMPANY_TO_DIVISION = {
    'Leap Solutions Asia': 'Enterprise Service',
    'Shinasub': 'Enterprise Operation',
    'Data Assets': 'Solution Development',
}

FIXED_BU_LOB_TARGETS = {
    'Infrastructure': {
        'Revenue (THB)': ['296,198,075.18', '299,320,715.79', '302,443,356.40', '306,606,877.22', '312,597,868.55'],
        'EBITDA (THB)': ['143,390,762.44', '147,499,380.28', '151,607,998.11', '154,894,892.38', '157,360,063.08'],
    },
    'Enterprise Service': {
        'Revenue (THB)': ['693,508,251.34', '700,819,497.47', '708,130,743.59', '717,879,071.76', '731,906,178.18'],
        'EBITDA (THB)': ['180,363,636.33', '185,531,648.83', '190,699,661.34', '194,834,071.34', '197,934,878.84'],
    },
    'Operation': {
        'Revenue (THB)': ['693,508,251.34', '700,819,497.47', '708,130,743.59', '717,879,071.76', '731,906,178.18'],
        'EBITDA (THB)': ['180,363,636.33', '185,531,648.83', '190,699,661.34', '194,834,071.34', '197,934,878.84'],
    },
    'Technology': {
        'Revenue (THB)': ['693,508,251.34', '700,819,497.47', '708,130,743.59', '717,879,071.76', '731,906,178.18'],
        'EBITDA (THB)': ['180,363,636.33', '185,531,648.83', '190,699,661.34', '194,834,071.34', '197,934,878.84'],
    },
    'Enterprise Operation': {
        'Revenue (THB)': ['400,791,778.81', '405,017,088.79', '409,242,398.78', '414,876,145.43', '422,982,680.46'],
        'EBITDA (THB)': ['93,115,158.91', '95,783,215.04', '98,451,271.17', '100,585,716.07', '102,186,549.75'],
    },
    'Shinasub': {
        'Revenue (THB)': ['400,791,778.81', '405,017,088.79', '409,242,398.78', '414,876,145.43', '422,982,680.46'],
        'EBITDA (THB)': ['93,115,158.91', '95,783,215.04', '98,451,271.17', '100,585,716.07', '102,186,549.75'],
    },
    'Solution Development': {
        'Revenue (THB)': ['700,895,933.67', '708,285,063.75', '715,674,193.83', '725,526,367.27', '739,702,899.17'],
        'EBITDA (THB)': ['93,171,747.61', '95,841,425.19', '98,511,102.78', '100,646,844.84', '102,248,651.39'],
    },
    'Smart Solution': {
        'Revenue (THB)': ['372,173,321.42', '376,096,923.99', '380,020,526.56', '385,251,996.64', '392,779,686.15'],
        'EBITDA (THB)': ['48,297,729.64', '49,681,618.75', '51,065,507.85', '52,172,619.13', '53,002,952.59'],
    },
    'Client & Service Support': {
        'Revenue (THB)': ['382,082,639.58', '386,110,710.21', '390,138,780.84', '395,509,541.68', '403,237,660.03'],
        'EBITDA (THB)': ['161,154,392.17', '165,771,996.53', '170,389,600.89', '174,083,684.37', '176,854,246.99'],
    },
}


def get_fixed_bu_lob_weight(job_level: Any) -> str:
    level = safe_int(job_level, 0)
    if level >= 12:
        return '15'
    if level >= 10:
        return '10'
    if level >= 8:
        return '5'
    return '0'


def resolve_division_revenue_ebitda_unit(division: Any, company: Any = None) -> str:
    division_name = str(division or '').strip()
    company_name = str(company or '').strip()
    if division_name in DIVISION_REVENUE_EBITDA_TARGET_DIVISIONS:
        return division_name
    if company_name in DIVISION_REVENUE_EBITDA_COMPANY_TO_DIVISION:
        return DIVISION_REVENUE_EBITDA_COMPANY_TO_DIVISION[company_name]
    return ''


def is_fixed_bu_lob_user(job_level: Any, division: Any, company: Any = None) -> bool:
    level = safe_int(job_level, 0)
    target_unit = resolve_division_revenue_ebitda_unit(division, company)
    return 8 <= level <= 14 and bool(target_unit)


def _default_division_revenue_ebitda_scores() -> Dict[str, Dict[str, str]]:
    return {
        division: {
            'revenue_score': '',
            'ebitda_score': '',
        }
        for division in DIVISION_REVENUE_EBITDA_TARGET_DIVISIONS
    }


def load_division_revenue_ebitda_scores(eval_year: int) -> Dict[str, Dict[str, str]]:
    payload = load_form_data_from_db(DIVISION_REVENUE_EBITDA_ADMIN_ID, 'division_revenue_ebitda', eval_year) or {}
    divisions = payload.get('divisions', {}) if isinstance(payload.get('divisions'), dict) else {}
    normalized = _default_division_revenue_ebitda_scores()
    for division in normalized.keys():
        division_payload = divisions.get(division, {}) if isinstance(divisions.get(division), dict) else {}
        normalized[division]['revenue_score'] = str(division_payload.get('revenue_score', '') or '').strip()
        normalized[division]['ebitda_score'] = str(division_payload.get('ebitda_score', '') or '').strip()
    return normalized


def save_division_revenue_ebitda_scores(eval_year: int, scores_by_division: Dict[str, Dict[str, str]]) -> bool:
    payload = {'divisions': _default_division_revenue_ebitda_scores()}
    for division in payload['divisions'].keys():
        division_payload = scores_by_division.get(division, {}) if isinstance(scores_by_division.get(division), dict) else {}
        payload['divisions'][division]['revenue_score'] = str(division_payload.get('revenue_score', '') or '').strip()
        payload['divisions'][division]['ebitda_score'] = str(division_payload.get('ebitda_score', '') or '').strip()
    return save_form_data_to_db_yearly(DIVISION_REVENUE_EBITDA_ADMIN_ID, 'division_revenue_ebitda', eval_year, payload)


def build_fixed_bu_lob_data(job_level: Any, division: Any, company: Any = None) -> Dict[str, Any]:
    target_unit = resolve_division_revenue_ebitda_unit(division, company)
    targets = FIXED_BU_LOB_TARGETS.get(target_unit, {})
    fixed_weight = get_fixed_bu_lob_weight(job_level)
    eval_year = resolve_eval_year_from_request()
    division_scores = load_division_revenue_ebitda_scores(eval_year).get(target_unit, {})

    revenue_targets = targets.get('Revenue (THB)', [''] * 5)
    ebitda_targets = targets.get('EBITDA (THB)', [''] * 5)
    revenue_score = str(division_scores.get('revenue_score', '') or '').strip()
    ebitda_score = str(division_scores.get('ebitda_score', '') or '').strip()
    revenue_result = "{:.2f}".format((safe_float(revenue_score, 0.0) * safe_float(fixed_weight, 0.0)) / 100) if revenue_score else '0.00'
    ebitda_result = "{:.2f}".format((safe_float(ebitda_score, 0.0) * safe_float(fixed_weight, 0.0)) / 100) if ebitda_score else '0.00'

    return {
        'descriptions': ['Revenue (THB)', 'EBITDA (THB)'],
        'weights': [fixed_weight, fixed_weight],
        'scores': [revenue_score, ebitda_score],
        'results': [revenue_result, ebitda_result],
        'short_descriptions': [revenue_targets, ebitda_targets],
        'total_score': "{:.2f}".format(safe_float(revenue_result, 0.0) + safe_float(ebitda_result, 0.0)),
    }


def apply_fixed_bu_lob_constraints(data: Dict[str, Any], job_level: Any, division: Any, company: Any = None) -> Dict[str, Any]:
    if not is_fixed_bu_lob_user(job_level, division, company):
        return data

    return build_fixed_bu_lob_data(job_level, division, company)


def is_admin_employee(employee_id: Optional[Union[str, int]]) -> bool:
    """Return True if the employee_id is in the admin list."""
    if employee_id is None:
        return False
    return str(employee_id).strip() in ADMIN_EMPLOYEE_IDS


def is_super_admin_employee(employee_id: Optional[Union[str, int]]) -> bool:
    if employee_id is None:
        return False
    return str(employee_id).strip() in set(AUTHORIZED_EXPORTER_ID)


def uses_admin_managed_group_kpi(company: Any) -> bool:
    company_name = str(company or '').strip()
    return company_name in ADMIN_MANAGED_GROUP_KPI_COMPANIES


def get_reporting_employee_ids(supervisor_id: str) -> List[str]:
    """Return employee_ids from pe_staff for a manager/director."""
    conn = get_db_connection()
    if not conn:
        return []

    cursor = None
    try:
        cursor = conn.cursor()
        supervisor_id = str(supervisor_id).strip()
        cursor.execute(
            "SELECT DISTINCT ps.employee_id "
            "FROM pe_staff ps "
            "INNER JOIN employee_master em ON TRIM(CAST(em.employee_id AS CHAR)) = TRIM(CAST(ps.employee_id AS CHAR)) "
            "WHERE (TRIM(CAST(ps.manager_id AS CHAR)) = %s "
            "OR TRIM(CAST(ps.director_id AS CHAR)) = %s) "
            f"AND {PE_ACTIVE_EMPLOYEE_MASTER_CONDITION} "
            f"AND {PE_PERMANENT_EMPLOYEE_MASTER_CONDITION}",
            (supervisor_id, supervisor_id)
        )
        rows = cursor.fetchall()
        return [str(row[0]) for row in rows if row and row[0] is not None]
    except Exception as e:
        print(f"Error fetching pe_staff data: {e}")
        return []
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


def _build_msal_app():
    """Create MSAL client if AAD settings are available."""
    if not (TENANT and CLIENT_ID and CLIENT_SECRET):
        return None
    try:
        return msal.ConfidentialClientApplication(
            CLIENT_ID,
            authority=AUTHORITY,
            client_credential=CLIENT_SECRET,
        )
    except Exception as exc:
        app.logger.warning("MSAL app initialization failed: %s", exc)
        return None


def _acquire_graph_app_token() -> Optional[str]:
    """Acquire app-only Graph token for server-side photo retrieval fallback."""
    auth_app = _build_msal_app()
    if not auth_app:
        return None
    try:
        token_result = auth_app.acquire_token_for_client(scopes=["https://graph.microsoft.com/.default"])
    except Exception as exc:
        app.logger.warning("App token acquisition failed: %s", exc)
        return None
    if not token_result or "access_token" not in token_result:
        app.logger.info("App token unavailable: %s", token_result.get("error_description") if isinstance(token_result, dict) else "unknown")
        return None
    return token_result.get("access_token")


def _extract_initials(full_name: Any) -> str:
    """Build a safe 1-2 character placeholder from a display name."""
    parts = [p for p in re.split(r"\s+", str(full_name or "").strip()) if p]
    if not parts:
        return "U"
    initials = "".join(part[0] for part in parts[:2]).upper()
    initials = re.sub(r"[^A-Z0-9]", "", initials)
    return initials or "U"


def _fetch_graph_profile_photo(
    access_token: Optional[str],
    graph_user_id: Optional[str] = None,
) -> tuple[Optional[bytes], Optional[str]]:
    """Fetch a profile photo from Microsoft Graph for the current or specified user."""
    if not access_token or requests is None:
        return None, None
    if graph_user_id:
        encoded_user = quote(str(graph_user_id), safe="")
        photo_url = f"https://graph.microsoft.com/v1.0/users/{encoded_user}/photo/$value"
    else:
        photo_url = "https://graph.microsoft.com/v1.0/me/photo/$value"
    try:
        response = requests.get(
            photo_url,
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=10,
        )
    except Exception as exc:
        app.logger.warning("Graph photo request failed: %s", exc)
        return None, None

    if response.status_code == 200 and response.content:
        return response.content, response.headers.get("Content-Type", "image/jpeg")

    if response.status_code != 404:
        app.logger.info(
            "Graph photo unavailable: status=%s target=%s",
            response.status_code,
            graph_user_id or "me",
        )
    return None, None

# Navigation configuration
NAVIGATION_ITEMS = [
    {'id': 'profile_page', 'label': 'Employee Profile', 'icon': '👤'},
    {'id': 'pe_weighting_page', 'label': 'PE Score Weighting Distribution Guideline', 'icon': '⚖️'},
    {'id': 'kpi_measurement_criteria', 'label': 'KPI Measurement Criteria', 'icon': '📏'},
    {'id': 'group_kpi_page', 'label': 'Group Shared KPI', 'icon': '🏢'},
    {'id': 'bu_lob_kpi_page', 'label': 'BU/LoB Shared KPI', 'icon': '📈'},
    {'id': 'org_capability_page', 'label': 'Organizational Capability Development', 'icon': '🎯'},
    {'id': 'people_dev_page', 'label': 'People Development', 'icon': '👥'},
    {'id': 'bu_objectives_page', 'label': 'Business Unit Objectives', 'icon': '🎯'},
    {'id': 'rating_criteria', 'label': 'Behavior Rating Criteria', 'icon': '⭐'},
    {'id': 'core_behaviors_page', 'label': 'Core Behaviors', 'icon': '💼'},
    {'id': 'leadership_behaviors_page', 'label': 'Leadership Behaviors', 'icon': '👔'},
    {'id': 'comments_page', 'label': 'Comments', 'icon': '💬'},
    {'id': 'summary_page', 'label': 'Score Summary', 'icon': '📋'},
]

# Core Behaviors data
CORE_BEHAVIORS_DATA = {
    1: {
        "title": "ACHIEVEMENT ORIENTATION การมุ่งเน้นความสำเร็จ",
        "description_en": "Tenaciously work to meet or surpass challenging goals with on time and in full through multiple efforts and commitments and continuously keep performance track of and progress in order to set broad functional or departmental goals, priorities and align structures, systems and resources for better performance and goal achievement.",
        "description_th": "มุ่งมั่นดำเนินการเพื่อบรรลุผลสำเร็จในเป้าหมายที่ท้าทายภายในเวลาที่กำหนดอย่างเต็มที่และมานะทุ่มเทอย่างเต็มกำลังและรักษาระดับผลงานและยกระดับให้มีความก้าวหน้าอย่างต่อเนื่องโดยกำหนดเป้าหมายของสายงานหรือหน่วยงาน จัดลำดับความสำคัญโครงสร้างงาน ระบบและทรัพยากรต่างๆ ให้เอื้อต่อการสร้างสรรค์ผลงานที่ดีขึ้นและการบรรลุเป้าหมายที่สูงขึ้น"
    },
    2: {
        "title": "ATTITUDE/COOPERATION/ADAPTABILITY การให้ความร่วมมือ/การปรับตัว",
        "description_en": "Commitment, team spirit, amount of interest and enthusiasm shown in the performance of responsibilities and attitude toward coworkers. Works effectively and willingly with others (individuals and departments) in positive, supportive, and cooperative relationship. Accepts new or changed situations, adjusting activities and plans to accommodate.",
        "description_th": "มีความมุ่งมั่นในงาน ทํางานเป็นทีม แสดงความสนใจและกระตือรือร้นผ่านความรับผิดชอบและทัศนคติที่ดีต่อผู้ร่วมงาน ปฏิบัติงานร่วมกับผู้อื่นได้อย่างมีประสิทธิภาพให้การสนับสนุนและความร่วมมือ (ทั้งในระดับบุคคลและระดับแผนก) ยอมรับสิ่งใหม่หรือสถานการณ์ที่มีการเปลี่ยนแปลงทั้งในเชิงกิจกรรมและแผนงานที่มีการปรับเปลี่ยน"
    },
    3: {
        "title": "COMMUNICATION SKILL ทักษะด้านการสื่อสาร (Consider written, verbal, and listening skills) พิจารณาด้านการเขียน การพูดและการฟัง",
        "description_en": "Demonstrates proficiency at expressing ideas and listening, asking for and providing productive feedback, providing accurate information and understanding, and has a positive, effective communication style.",
        "description_th": "มีความสามารถในการแสดงความคิดเห็นและการฟัง การสอบถามและการให้ความคิดเห็น รวมถึงการให้ข้อมูล การถ่ายทอดและวิเคราะห์ข้อมูลและสร้างความเข้าใจที่ถูกต้อง อีกทั้งยังมีรูปแบบการสื่อสารในเชิงบวกและมีประสิทธิภาพต่อบุคคลภายในและภายนอกองค์กร"
    },
    4: {
        "title": "DEPENDABILITY การเป็นผู้ที่เชื่อถือได้",
        "description_en": "Be able to understand and respond to the needs of customers, both internal and external, with an attitude of goodwill and helpfulness.Fulfills responsibilities, instills full confidence, works well, and deliver report to supervisor consistently and timely.",
        "description_th": "มีความรับผิดชอบ เต็มเปี่ยมไปด้วยความมั่นใจและสามารถปฏิบัติงานได้ดีและถูกต้อง นําเสนอรายงานอย่างสม่ำเสมอและทันเวลา"
    },
    5: {
        "title": "INITIATIVE ความคิดริเริ่ม",
        "description_en": "A self-starter who contributes and/or carries out new ideas or methods.",
        "description_th": "มีความคิดริเริ่ม สามารถนำเสนอความคิดและวิธีการใหม่ๆ เพื่อพัฒนาการทำงานให้ดียิ่งขึ้น"
    },
    6: {
        "title": "INTEGRITY ความซื่อสัตย์",
        "description_en": "Adheres work ethic and honesty in all aspects of the position.",
        "description_th": "ยึดหลักจรรยาบรรณและความซื่อสัตย์ในการปฏิบัติหน้าที่และความรับผิดชอบในทุกด้านของตำแหน่งงาน"
    },
    7: {
        "title": "KNOWLEDGE ความรู้",
        "description_en": "Demonstrates skills and an understanding of the position, policies, and procedures required in present job.",
        "description_th": "มีทักษะและความเข้าใจในหน้าที่ความรับผิดชอบของตำแหน่งงาน รวมถึงเข้าใจนโยบายและขั้นตอนการปฏิบัติงานในงานที่ปฏิบัติอยู่"
    },
    8: {
        "title": "NEGOTIATION การเจรจาต่อรอง",
        "description_en": "Demonstrates ability to effectively reach agreement with others to have win-win situation.",
        "description_th": "แสดงความสามารถในการบรรลุข้อตกลงกับผู้อื่นได้อย่างมีประสิทธิผลและเป็นประโยชน์กับทั้งสองฝ่าย"
    },
    9: {
        "title": "PLANNING การวางแผน",
        "description_en": "Develops and utilizes methods and work organization to efficiently complete overall workload on a timely basis.",
        "description_th": "สามารถพัฒนาและวางแนวทางการปฏิบัติงานอย่างมีประสิทธิภาพเพื่อทำให้งานเสร็จสมบูรณ์และตรงเวลา"
    },
    10: {
        "title": "PRESENTATION การนำเสนองาน",
        "description_en": "Performs presentations in an effective, credible, and professional manner. Disseminates information to group participants in a way that is concise and easy to understand.",
        "description_th": "นำเสนองานอย่างมีประสิทธิผล น่าเชื่อถือและมีความเป็นมืออาชีพ ถ่ายทอดข้อมูลให้กับผู้ฟังได้อย่างกระชับและเข้าใจง่าย"
    },
    11: {
        "title": "PROBLEM SOLVING การแก้ไขปัญหา",
        "description_en": "The ability to understand and manage one's own emotions and to respond appropriately to the emotions of others.Identifies problems and determines their causes, assesses alternatives; makes recommendations/decisions to achieve goals.",
        "description_th": "ระบุปัญหาและสาเหตุของปัญหา ประเมินทางเลือก สามารถนำเสนอวิธีการแก้ไขปัญหาและการตัดสินใจเพื่อให้งานบรรลุผลสำเร็จ"
    },
    12: {
        "title": "PUNCTUALITY ความตรงต่อเวลา",
        "description_en": "Consistent attendance, punctually arrives and leaves work, meetings and appointments.",
        "description_th": "มาปฏิบัติงานอย่างสม่ำเสมอ ตรงต่อเวลาในการมาและออกจากที่ทำงาน รวมถึงการประชุมและการนัดหมาย"
    },
    13: {
        "title": "QUALITY คุณภาพ",
        "description_en": "Works with attention to detail and absence of error and deliver outputs that provide benefits to the company.",
        "description_th": "ทำงานโดยให้ความสำคัญกับรายละเอียดเพื่อให้ปราศจากข้อผิดพลาดและเกิดผลงานที่เป็นประโยชน์ต่อบริษัทฯ"
    },
    14: {
        "title": "QUANTITY ปริมาณ",
        "description_en": "The amount of work an individual accomplishes. Consistently and accurately applies ability and completes work in given time frame.",
        "description_th": "สามารถปฏิบัติงานในปริมาณที่บุคคลหนึ่งจะกระทำให้สำเร็จ ประยุกต์ใช้ความสามารถและทำงานให้สำเร็จภายในเวลาที่กำหนดอย่างสม่ำเสมอและมีความถูกต้อง"
    },
    15: {
        "title": "RESPONSIVENESS การสนองตอบในการให้ข้อมูล",
        "description_en": "Responds quickly and appropriately to requests for documents, reports, or information, whether verbal or written.",
        "description_th": "ตอบสนองในการจัดทําเอกสารรายงานหรือข้อมูลไม่ว่าจะด้วยวาจาหรือลายลักษณ์อักษรได้อย่างรวดเร็วและถูกต้องครบถ้วน"
    },
    16: {
        "title": "SELF-DEVELOPMENT การพัฒนาตนเอง",
        "description_en": "Seeks both informal and formal development opportunities.",
        "description_th": "แสวงหาโอกาสในการพัฒนาตนเองทั้งจากการเรียนรู้เพิ่มเติมด้วยตัวเองและการเข้ารับการฝึกอบรมและพัฒนา"
    },
}



# Core Behaviors rating levels by job level group
CORE_BEHAVIORS_RATING_LEVELS = {
    "L4-L7": {
        1: [
            "Fails to achieve work goals.\nไม่สามารถบรรลุเป้าหมายงานได้",
            "Achieves some goals but not consistently.\nบรรลุเป้าหมายได้บางส่วน",
            "Meets assigned goals.\nปฏิบัติงานตามเป้าหมายที่กำหนด",
            "Delivers results to achieve targets.\nทำงานจนบรรลุเป้าหมาย",
            "Drives results beyond targets and creates additional value.\nมุ่งมั่นสร้างผลลัพธ์ที่เกินเป้าหมาย",
        ],
        2: [
            "Resists change or refuses to cooperate.\nต่อต้านการเปลี่ยนแปลง หรือไม่ให้ความร่วมมือ",
            "Cooperates/adapts in limited situations.\nปรับตัวหรือร่วมมือได้จำกัด",
            "Cooperates and adapts as expected.\nให้ความร่วมมือและปฏิบัติงานตามบทบาท",
            "Works well with others and adapts to situations.\nทำงานร่วมกับผู้อื่นได้ดี และปรับตัวตามสถานการณ์",
            "Demonstrates positive mindset and supports team success and change.\nสนับสนุนทีม เปิดรับการเปลี่ยนแปลง สร้างบรรยากาศที่ดี",
        ],
        3: [
            "Communication causes misunderstanding or issues.\nการสื่อสารทำให้เกิดความเข้าใจผิดหรือปัญหา",
            "Communication is unclear; requires repeated clarification.\nสื่อสารไม่ชัดเจน ต้องอาศัยการชี้แจงเพิ่มเติม",
            "Communicates adequately within the role.\nสื่อสารได้ตามบทบาทและหน้าที่",
            "Shares information accurately and listens effectively.\nถ่ายทอดข้อมูลถูกต้อง รับฟังและตอบสนองได้ดี",
            "Communicates clearly and helps enable collaboration and problem solving.\nสื่อสารชัดเจน ช่วยแก้ปัญหาและสร้างความร่วมมือ",
        ],
        4: [
            "Is not reliable; cannot be depended on.\nขาดความน่าเชื่อถือในงาน",
            "Requires close follow-up and reminders.\nยังต้องติดตามหรือเตือน",
            "Is dependable in assigned responsibilities.\nทำงานได้ตามหน้าที่ที่รับผิดชอบ",
            "Consistently delivers as committed.\nปฏิบัติงานได้ตามที่มอบหมายอย่างสม่ำเสมอ",
            "Highly trusted for critical tasks and responsibilities.\nได้รับความไว้วางใจให้รับผิดชอบงานสำคัญ",
        ],
        6: [
            "Violates rules or shows inappropriate conduct.\nฝ่าฝืนกฎหรือแสดงพฤติกรรมไม่เหมาะสม",
            "Complies partially; requires reminders.\nปฏิบัติตามกฎบางส่วน ยังต้องได้รับการเตือน",
            "Complies with rules, policies, and standards.\nปฏิบัติตามกฎ ระเบียบ และข้อบังคับ",
            "Acts with honesty and follows code of conduct.\nปฏิบัติงานด้วยความซื่อสัตย์ ยึดหลักจรรยาบรรณ",
            "Serves as a role model for ethics and accountability.\nเป็นแบบอย่างด้านจริยธรรมและความรับผิดชอบ",
        ],
        7: [
            "Does not understand job duties or procedures.\nขาดความเข้าใจในหน้าที่หรือขั้นตอนงาน",
            "Understands parts of the job; needs frequent guidance.\nเข้าใจงานบางส่วน ยังต้องพึ่งพาคำแนะนำ",
            "Understands own responsibilities within the role.\nเข้าใจงานในขอบเขตหน้าที่ของตน",
            "Understands procedures and performs work correctly.\nเข้าใจงานและขั้นตอน ปฏิบัติงานได้ถูกต้อง",
            "Demonstrates deep understanding and can guide others.\nเข้าใจงานลึกซึ้ง สามารถอธิบายหรือแนะนำผู้อื่นได้",
        ],
        12: [
            "Does not meet time commitments; impacts work.\nไม่รักษาเวลา ส่งผลกระทบต่องาน",
            "Occasionally late or misses timelines.\nมีความล่าช้าเป็นบางครั้ง",
            "Meets working hours and agreed timelines.\nปฏิบัติตามเวลางานและเวลาที่กำหนด",
            "Arrives and delivers work on time.\nเข้างาน ประชุม และส่งมอบงานตรงเวลา",
            "Plans and manages time effectively; sets a good example.\nวางแผนและบริหารเวลาได้ดี เป็นแบบอย่าง",
        ],
        13: [
            "Work contains significant errors impacting others.\nงานมีข้อผิดพลาดสูง ส่งผลกระทบต่องาน",
            "Work quality is inconsistent; errors occur.\nงานมีข้อผิดพลาดบางส่วน คุณภาพไม่สม่ำเสมอ",
            "Work meets acceptable standards.\nงานอยู่ในเกณฑ์มาตรฐานที่ยอมรับได้",
            "Work is accurate and meets required standards.\nงานถูกต้อง ครบถ้วน ตามมาตรฐาน",
            "Delivers high-quality work that adds value and reduces errors.\nงานมีคุณภาพสูง ลดข้อผิดพลาด และสร้างคุณค่าเพิ่ม",
        ],
        14: [
            "Unable to deliver required output.\nไม่สามารถส่งมอบงานตามที่กำหนดได้",
            "Delivers incomplete work or misses deadlines.\nส่งมอบงานไม่ครบหรือใช้เวลามากกว่าที่กำหนด",
            "Delivers expected volume of work.\nส่งมอบงานได้ตามปริมาณที่คาดหวัง",
            "Delivers target output within agreed timelines.\nส่งมอบงานได้ตามเป้าหมายและเวลาที่กำหนด",
            "Exceeds targets without compromising quality.\nส่งมอบงานเกินเป้าหมายโดยไม่กระทบคุณภาพ",
        ],
        15: [
            "Does not respond; causes negative impact.\nไม่ตอบสนอง ส่งผลกระทบต่องาน",
            "Responds late or incompletely.\nตอบสนองล่าช้าหรือไม่ครบถ้วน",
            "Responds as assigned.\nตอบสนองตามที่ได้รับมอบหมาย",
            "Responds accurately and within required timelines.\nตอบสนองคำขอได้ถูกต้องและทันเวลา",
            "Responds proactively and anticipates needs.\nตอบสนองรวดเร็วและคาดการณ์ความต้องการล่วงหน้า",
        ],
        16: [
            "Shows no interest in learning or development.\nไม่แสดงความสนใจในการพัฒนาตนเอง",
            "Develops only when instructed.\nพัฒนาตนเองเมื่อได้รับคำสั่ง",
            "Participates in development as required.\nเข้าร่วมการพัฒนาตามที่กำหนด",
            "Develops skills needed for the role.\nพัฒนาทักษะที่จำเป็นต่อบทบาท",
            "Learns and applies new knowledge to improve performance measurably.\nเรียนรู้และนำมาพัฒนางานอย่างเห็นผล",
        ],
    },
    "L8-L9": {
        1: [
            "Team fails to achieve goals.\nทีมไม่สามารถบรรลุเป้าหมาย",
            "Team achieves only some goals.\nทีมบรรลุเป้าหมายบางส่วน",
            "Team meets goals as expected.\nทีมทำงานตามเป้าหมาย",
            "Drives team to achieve targets.\nทำให้ทีมบรรลุเป้าหมาย",
            "Drives the team to achieve challenging targets with strategic impact.\nขับเคลื่อนทีมให้บรรลุเป้าหมายที่ท้าทาย",
        ],
        2: [
            "Resists change and collaboration.\nต่อต้านการเปลี่ยนแปลง",
            "Limited adaptability and cooperation.\nปรับตัวหรือร่วมมือได้จำกัด",
            "Cooperates and adapts as expected.\nให้ความร่วมมือและปรับตัวตามบทบาท",
            "Supports change and collaboration within the team.\nเปิดรับการเปลี่ยนแปลงและสนับสนุนทีม",
            "Role model for positive mindset and team energy.\nเป็นแบบอย่างด้านทัศนคติและพลังบวกให้ทีม",
        ],
        3: [
            "Communication creates misunderstanding.\nการสื่อสารก่อให้เกิดความเข้าใจผิด",
            "Communication is unclear at team level.\nการสื่อสารยังไม่ชัดเจน",
            "Communicates adequately within role.\nสื่อสารตามบทบาทหน้าที่",
            "Communicates goals and key information clearly to the team.\nสื่อสารเป้าหมายและข้อมูลให้ทีมเข้าใจ",
            "Communicates clearly and builds alignment with stakeholders.\nสื่อสารชัดเจน สร้างความเข้าใจและความร่วมมือ",
        ],
        4: [
            "Not reliable in the role.\nขาดความน่าเชื่อถือ",
            "Requires close supervision and follow-up.\nยังต้องติดตามหรือควบคุมใกล้ชิด",
            "Meets responsibilities as assigned.\nปฏิบัติงานได้ตามความรับผิดชอบ",
            "Dependable for team deliverables and support.\nเป็นที่พึ่งพาได้ในงานของทีม",
            "Highly trusted for important assignments at unit level.\nได้รับความไว้วางใจในงานสำคัญระดับหน่วยงาน",
        ],
        5: [
            "Shows no improvement-oriented thinking.\nไม่แสดงความคิดเชิงพัฒนา",
            "Lacks initiative.\nขาดความริเริ่ม",
            "Follows assigned approaches.\nปฏิบัติงานตามแนวทางที่กำหนด",
            "Proposes ideas to improve work.\nเสนอแนวคิดเพื่อปรับปรุงงาน",
            "Initiates changes that create measurable team results.\nริเริ่มแนวทางใหม่ที่สร้างผลลัพธ์ให้ทีม",
        ],
        7: [
            "Lacks understanding of the role and team process.\nขาดความเข้าใจในงานและบทบาท",
            "Understands partially; depends heavily on others.\nเข้าใจงานบางส่วน ยังต้องพึ่งพาผู้อื่น",
            "Understands own and team responsibilities.\nเข้าใจงานในความรับผิดชอบของตนและทีม",
            "Understands process and can support the team effectively.\nเข้าใจงานและกระบวนการ สามารถสนับสนุนทีมได้",
            "Understands work deeply and provides systemic guidance to the team.\nเข้าใจงานเชิงลึกและภาพรวม สามารถให้คำแนะนำเชิงระบบแก่ทีม",
        ],
        9: [
            "Does not plan work; causes disruption.\nขาดการวางแผน",
            "Plans are unclear or unrealistic.\nแผนงานไม่ชัดเจน",
            "Plans within assigned scope.\nวางแผนงานตามที่ได้รับมอบหมาย",
            "Plans team work effectively.\nวางแผนงานทีมได้อย่างมีประสิทธิภาพ",
            "Plans proactively by linking goals, risks, and resources.\nวางแผนเชิงรุก เชื่อมโยงเป้าหมายและทรัพยากร",
        ],
        10: [
            "Presentation lacks credibility or is inappropriate.\nการนำเสนอไม่เหมาะสมหรือขาดความน่าเชื่อถือ",
            "Presentation is unclear or poorly structured.\nการนำเสนอยังไม่ชัดเจน",
            "Presents required content adequately.\nนำเสนอได้ตามเนื้อหาที่กำหนด",
            "Presents clearly with complete and understandable information.\nนำเสนอข้อมูลได้ครบถ้วน เข้าใจง่าย",
            "Presents professionally and persuades effectively.\nนำเสนออย่างมืออาชีพและโน้มน้าวได้",
        ],
        11: [
            "Unable to resolve work problems.\nไม่สามารถแก้ไขปัญหาในงานได้",
            "Resolves only limited issues; relies on others.\nแก้ปัญหาได้จำกัด ต้องพึ่งพาผู้อื่น",
            "Resolves problems within the team scope.\nแก้ไขปัญหาในขอบเขตทีม",
            "Analyzes issues and makes sound decisions for the team.\nวิเคราะห์ปัญหาและตัดสินใจแก้ไขได้",
            "Solves problems systemically and establishes prevention.\nวิเคราะห์ปัญหาเชิงระบบและป้องกันในอนาคต",
        ],
        12: [
            "Lack of time discipline causes major impact.\nขาดวินัยด้านเวลา ส่งผลกระทบชัดเจน",
            "Delays impact team delivery.\nมีความล่าช้าที่ส่งผลต่อทีม",
            "Meets required timelines.\nปฏิบัติตามเวลางานและกำหนดการ",
            "Ensures the team delivers on time.\nควบคุมให้ทีมทำงานตรงเวลา",
            "Builds effective planning and time-management practices for the team.\nวางแผนและบริหารเวลาให้ทีมได้อย่างมีประสิทธิภาพ",
        ],
        13: [
            "Team output has clear quality issues.\nงานทีมมีปัญหาด้านคุณภาพ",
            "Team quality is inconsistent.\nคุณภาพงานทีมไม่สม่ำเสมอ",
            "Team output meets basic standards.\nงานทีมอยู่ในเกณฑ์มาตรฐาน",
            "Controls and ensures team quality to required standards.\nควบคุมคุณภาพงานทีมตามมาตรฐาน",
            "Improves team standards measurably and sustainably.\nยกระดับมาตรฐานงานทีมอย่างชัดเจน",
        ],
        14: [
            "Team cannot deliver required output.\nทีมไม่สามารถส่งมอบงานได้",
            "Team delivery is late or incomplete.\nทีมส่งมอบงานล่าช้าหรือไม่ครบ",
            "Team delivers expected output.\nทีมส่งมอบงานได้ตามเป้าหมาย",
            "Team delivers according to plan.\nทีมส่งมอบงานได้ตามแผน",
            "Optimizes resources so the team exceeds targets.\nบริหารทรัพยากรทีม ส่งมอบงานเกินเป้าหมาย",
        ],
        16: [
            "Shows no interest in developing self/team.\nไม่สนใจพัฒนาตนเอง",
            "Develops only when necessary or instructed.\nพัฒนาเมื่อได้รับคำสั่ง",
            "Learns as required by the organization.\nเรียนรู้ตามที่องค์กรกำหนด",
            "Develops skills needed for leadership responsibilities.\nพัฒนาทักษะที่จำเป็นต่อบทบาทหัวหน้างาน",
            "Develops self and actively upgrades team capability.\nพัฒนาตนเองและนำมาพัฒนาทีม",
        ],
    },
    "L10-L11": {
        2: [
            "Does not support change or collaboration.\nต่อต้านหรือไม่สนับสนุนการเปลี่ยนแปลง",
            "Adapts slowly at unit level.\nปรับตัวช้าในระดับหน่วยงาน",
            "Cooperates and adapts as expected.\nให้ความร่วมมือและปรับตัวตามสถานการณ์",
            "Supports collaboration and change within the unit.\nสนับสนุนความร่วมมือและการเปลี่ยนแปลง",
            "Drives change and cross-functional collaboration.\nขับเคลื่อนการเปลี่ยนแปลงและสร้างความร่วมมือ",
        ],
        3: [
            "Communication creates confusion at management level.\nการสื่อสารก่อให้เกิดความสับสน",
            "Communication lacks clarity across the unit.\nการสื่อสารยังไม่ชัดเจนในระดับหน่วยงาน",
            "Communicates adequately within role.\nสื่อสารได้ตามบทบาท",
            "Communicates effectively to build understanding and alignment.\nสื่อสารเชิงบริหารและสร้างความเข้าใจ",
            "Communicates strategically and influences key stakeholders.\nสื่อสารเชิงกลยุทธ์ โน้มน้าวผู้มีส่วนได้ส่วนเสีย",
        ],
        4: [
            "Not reliable as a leader.\nขาดความน่าเชื่อถือในบทบาทผู้นำ",
            "Requires close oversight.\nยังต้องได้รับการกำกับใกล้ชิด",
            "Meets leadership responsibilities.\nรับผิดชอบงานในบทบาทได้",
            "Dependable for executives and teams.\nเป็นที่พึ่งพาได้ของทีมและผู้บริหาร",
            "Highly trusted at organizational level for critical responsibilities.\nได้รับความไว้วางใจในระดับองค์กร",
        ],
        5: [
            "Shows no initiative.\nไม่แสดงความคิดริเริ่ม",
            "Initiative is limited and tactical.\nริเริ่มในขอบเขตจำกัด",
            "Follows assigned direction.\nดำเนินงานตามแนวทางที่กำหนด",
            "Initiates managerial improvements.\nริเริ่มปรับปรุงงานเชิงบริหาร",
            "Initiates strategic changes that create organizational impact.\nริเริ่มเชิงกลยุทธ์สร้างผลกระทบองค์กร",
        ],
        6: [
            "Shows unethical behavior or lacks accountability.\nพฤติกรรมขัดต่อจริยธรรมหรือความรับผิดชอบ",
            "Requires governance and reminders on ethics/compliance.\nต้องได้รับการกำกับด้านจริยธรรม",
            "Complies with rules and code of conduct.\nปฏิบัติตามจรรยาบรรณและกฎระเบียบ",
            "Acts as a role model for honesty and accountability.\nเป็นแบบอย่างด้านความซื่อสัตย์",
            "Upholds ethics and builds a transparent culture across the unit.\nยืนหยัดจริยธรรมและสร้างวัฒนธรรมความโปร่งใส",
        ],
        7: [
            "Lacks understanding of role and organizational context.\nขาดความเข้าใจในบทบาทและภาพรวมองค์กร",
            "Understands the role narrowly; limited linkage to broader context.\nเข้าใจบทบาทเชิงจำกัด ยังไม่เชื่อมโยงภาพรวม",
            "Understands role and function responsibilities.\nเข้าใจบทบาทและงานในสายงานของตน",
            "Connects work with unit direction and priorities.\nเข้าใจงานและเชื่อมโยงกับทิศทางหน่วยงาน",
            "Demonstrates strategic understanding aligned with organizational direction.\nเข้าใจเชิงกลยุทธ์ เชื่อมโยงนโยบายและทิศทางองค์กร",
        ],
        8: [
            "Lacks negotiation capability.\nขาดทักษะการเจรจา",
            "Negotiation rarely achieves outcomes.\nการเจรจายังไม่เกิดผล",
            "Negotiates adequately within role.\nเจรจาได้ตามบทบาท",
            "Negotiates effectively to reach outcomes.\nเจรจาได้อย่างมีประสิทธิภาพ",
            "Negotiates strategically for sustainable win-win results.\nเจรจาเชิงกลยุทธ์สร้างผลลัพธ์ win-win",
        ],
        10: [
            "Presentation lacks credibility at management level.\nการนำเสนอขาดความน่าเชื่อถือ",
            "Presentation is not appropriate or not well-prepared.\nการนำเสนอยังไม่เหมาะสม",
            "Presents required content adequately.\nนำเสนอได้ตามเนื้อหา",
            "Presents professionally to management audiences.\nนำเสนออย่างมืออาชีพ",
            "Presents strategically and influences management decisions.\nนำเสนอเชิงบริหาร โน้มน้าวผู้บริหาร",
        ],
        12: [
            "Time discipline at unit level is poor; causes impact.\nขาดวินัยด้านเวลาในระดับหน่วยงาน",
            "Delays create noticeable impact.\nมีความล่าช้าส่งผลกระทบ",
            "Meets timelines at an acceptable level.\nบริหารเวลาได้ตามเกณฑ์",
            "Ensures team delivery on time.\nกำกับทีมให้ทำงานตรงเวลา",
            "Builds systems and discipline for effective time management.\nสร้างระบบบริหารเวลาและวินัยการทำงาน",
        ],
        13: [
            "Unit output has significant quality issues.\nคุณภาพงานหน่วยงานมีปัญหาชัดเจน",
            "Quality is inconsistent across the unit.\nคุณภาพงานยังไม่สม่ำเสมอ",
            "Unit output meets required standards.\nงานหน่วยงานอยู่ในเกณฑ์มาตรฐาน",
            "Controls and improves quality effectively.\nควบคุมและยกระดับคุณภาพงานได้ดี",
            "Defines and elevates quality standards systematically across the unit.\nกำหนดมาตรฐานและยกระดับคุณภาพอย่างเป็นระบบ",
        ],
        14: [
            "Unable to manage workload and delivery volume.\nไม่สามารถบริหารปริมาณงานได้",
            "Delays and resource gaps impact delivery.\nงานล่าช้าหรือทรัพยากรไม่เพียงพอ",
            "Manages delivery according to plan.\nบริหารงานได้ตามแผน",
            "Prioritizes and allocates resources effectively.\nจัดลำดับความสำคัญและทรัพยากรได้ดี",
            "Improves unit productivity and delivery outcomes significantly.\nเพิ่มประสิทธิภาพและผลลัพธ์ของหน่วยงาน",
        ],
        15: [
            "Unit response is slow and impacts stakeholders.\nหน่วยงานตอบสนองล่าช้า",
            "Response is not managed systematically.\nการตอบสนองยังไม่เป็นระบบ",
            "Responds within agreed frameworks.\nตอบสนองตามกรอบที่กำหนด",
            "Manages response effectively and resolves escalations.\nกำกับการตอบสนองได้อย่างมีประสิทธิภาพ",
            "Builds proactive response systems and improves service experience.\nสร้างระบบการตอบสนองเชิงรุก",
        ],
        16: [
            "Does not develop self or the team.\nไม่พัฒนาตนเองหรือทีม",
            "Develops only when necessary.\nพัฒนาตนเองเฉพาะเมื่อจำเป็น",
            "Develops within organizational expectations.\nพัฒนาตนเองตามกรอบองค์กร",
            "Develops leadership capability and strengthens the team.\nพัฒนาศักยภาพผู้นำและทีมงาน",
            "Builds future leaders and creates a strong learning culture.\nสร้างผู้นำรุ่นถัดไปและวัฒนธรรมการเรียนรู้",
        ],
    },
}

# Leadership Behaviors data
LEADERSHIP_BEHAVIORS_DATA = {
    1: {
        "title": "LEADERSHIP ABILITY",
        "description_en": "Motivates employees and co-workers into performing duties needed to be accomplished. Functions consistently and effectively in an objective and rational manner regardless of pressures. Maintains a high degree of employee morale in order to accomplish department goals.",
        "description_th": "กระตุ้นพนักงานและเพื่อนร่วมงานให้ปฏิบัติหน้าที่เพื่อให้งานบรรลุเป้าหมายที่กำหนดไว้ ปฏิบัติหน้าที่อย่างต่อเนื่องและมีเหตุมีผลอย่างสม่ำเสมอและมีประสิทธิภาพภายใต้แรงกดดัน รักษาระดับขวัญและกำลังใจของพนักงานเพื่อบรรลุเป้าหมายของแผนก"
    },
    2: {
        "title": "APPRAISAL, PEOPLE MANAGEMENT AND DEVELOPMENT",
        "description_en": "Exhibits fairness and impartiality in employees in assigning job duties and objectively appraises work performance. Demonstrates the ability to select, train and effectively develop subordinates. Demonstrates the ability to set up clear plan and influence subordinates to realize the mutual responsibility in achieving goals.",
        "description_th": "แสดงความเป็นธรรมและเที่ยงธรรมในการมอบหมายงานและประเมินผลการปฏิบัติงานของพนักงาน มีความสามารถในการคัดเลือกฝึกอบรมและพัฒนาผู้ใต้บังคับบัญชาอย่างมีประสิทธิผล วางเป้าหมายการทำงานได้อย่างชัดเจนและทำให้ผู้ใต้บังคับบัญชาตระหนักถึงการมีส่วนร่วมรับผิดชอบต่อการบรรลุผลสำเร็จตามเป้าหมายที่กำหนดร่วมกันด้วยความสามัคคี"
    },
    3: {
        "title": "VISIONING AND STRATEGIC THINKING AND PLANNING",
        "description_en": "Able to provide direction and communicate the vision to encourage alignment within the organization. Understands rapidly changing technological trends at regional and global levels. Able to develop and implement strategic plans for both corporate and department levels. Delegates responsibility and authority; promotes accountability to achieve strategic goals.",
        "description_th": "ความสามารถในการมองการณ์ไกลในอนาคตเพื่อสามารถกำหนดทิศทางเพื่อสร้างการมีส่วนร่วมให้กับองค์กร เข้าใจการเปลี่ยนแปลงทางเทคโนโลยีในระดับภูมิภาคและระดับโลก สามารถกำหนดแผนเชิงกลยุทธ์ทั้งในระดับองค์กรและแผนกได้ และสามารถนำไปสู่การปฏิบัติได้อย่างเป็นรูปธรรม มีภาวะผู้นำในการถ่ายทอดและมอบหมายความรับผิดชอบเพื่อให้ทีมสามารถบรรลุเป้าหมายเชิงกลยุทธ์ตามที่ได้วางแผนไว้"
    },
    4: {
        "title": "TEAMWORK BUILDING",
        "description_en": "Demonstrates ability to work with others toward a shared goal, participating actively, sharing responsibility and rewards, and contributing to the capability of the team. Empathizes and creates an atmosphere of respect, helpfulness, and cooperation. Seeks to understand and building on differing perspectives of others to enhance team efficiency and quality outcomes.",
        "description_th": "แสดงให้เห็นถึงความสามารถในการทำงานร่วมกับผู้อื่นเพื่อบรรลุเป้าหมายร่วมกัน ให้ความสำคัญและสร้างบรรยากาศของการเคารพ การช่วยเหลือและการร่วมมือซึ่งกันและกัน เข้าใจถึงมุมมองที่แตกต่างของแต่ละคนเพื่อที่จะเสริมสร้างความมีประสิทธิภาพให้กับทีมและผลงานที่เป็นเลิศ"
    },
    5: {
        "title": "ACHIEVEMENT ORIENTATION",
        "description_en": "Tenaciously work to meet or surpass challenging goals with a drive to see a task full through multiple efforts and commitments. Continuously keep performance track of and progress in order to set broad functional/departmental goals, priority and align structures, systems and resources for better performance and goal achievement.",
        "description_th": "มุ่งมั่นดำเนินการเพื่อบรรลุผลสำเร็จในเป้าหมายที่ท้าทายภายในเวลาที่กำหนดอย่างเต็มที่และมานะทุ่มเทอย่างเต็มกำลัง รักษาระดับผลงานและยกระดับให้มีความก้าวหน้าอย่างต่อเนื่องโดยกำหนดเป้าหมายของสายงานหน่วยงาน จัดลำดับความสำคัญโครงสร้างงาน ระบบและทรัพยากรต่างๆ ให้เอื้อต่อการสร้างสรรค์ผลงานที่ดีขึ้นและการบรรลุเป้าหมายที่สูงขึ้น"
    },
}

CORE_BEHAVIORS_WORKBOOK_PATH = Path(__file__).with_name("core_behaviors_workbook.json")
CORE_BEHAVIORS_GROUPED_DATA: Dict[str, List[Dict[str, Any]]] = {}
LEADERSHIP_BEHAVIORS_WORKBOOK_PATH = Path(__file__).with_name("leadership_behaviors_workbook.json")
LEADERSHIP_BEHAVIORS_GROUPED_DATA: Dict[str, List[Dict[str, Any]]] = {}


def load_core_behaviors_workbook() -> Dict[str, List[Dict[str, Any]]]:
    """Load group-specific core behavior definitions exported from the workbook."""
    if not CORE_BEHAVIORS_WORKBOOK_PATH.exists():
        return {}

    try:
        workbook_data = json.loads(CORE_BEHAVIORS_WORKBOOK_PATH.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"Error loading core behaviors workbook data: {exc}")
        return {}

    normalized: Dict[str, List[Dict[str, Any]]] = {}
    for group_name, rows in workbook_data.items():
        if not isinstance(rows, list):
            continue

        normalized_rows = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            normalized_rows.append({
                "title": str(row.get("title", "")).strip(),
                "description_en": str(row.get("description_en", "")).strip(),
                "description_th": str(row.get("description_th", "")).strip(),
                "rating_levels": [
                    str(level).strip()
                    for level in row.get("rating_levels", [])
                    if str(level).strip()
                ],
            })

        if normalized_rows:
            normalized[group_name] = normalized_rows

    return normalized


CORE_BEHAVIORS_GROUPED_DATA = load_core_behaviors_workbook()


def get_core_behavior_group(job_level: Any) -> Optional[str]:
    level = safe_int(job_level, 0)
    if 4 <= level <= 7:
        return "L4-L7"
    if 8 <= level <= 9:
        return "L8-L9"
    if 10 <= level <= 11:
        return "L10-L11"
    return None


def get_core_behaviors_display_map(job_level: Any) -> Dict[int, Dict[str, Any]]:
    group_name = get_core_behavior_group(job_level)
    group_rows = CORE_BEHAVIORS_GROUPED_DATA.get(group_name or "", [])
    if group_rows:
        return {
            index: {
                "title": row.get("title", ""),
                "description_en": row.get("description_en", ""),
                "description_th": row.get("description_th", ""),
                "rating_levels": row.get("rating_levels", []),
            }
            for index, row in enumerate(group_rows, start=1)
        }

    rating_levels_by_behavior = CORE_BEHAVIORS_RATING_LEVELS.get(group_name or "", {})
    behavior_ids = sorted(rating_levels_by_behavior.keys()) or sorted(CORE_BEHAVIORS_DATA.keys())
    fallback_map: Dict[int, Dict[str, Any]] = {}
    for behavior_id in behavior_ids:
        if behavior_id not in CORE_BEHAVIORS_DATA:
            continue
        fallback_map[behavior_id] = {
            **CORE_BEHAVIORS_DATA[behavior_id],
            "rating_levels": rating_levels_by_behavior.get(behavior_id, []),
        }
    return fallback_map


def load_leadership_behaviors_workbook() -> Dict[str, List[Dict[str, Any]]]:
    """Load group-specific leadership behavior definitions with track-specific rating scales."""
    if not LEADERSHIP_BEHAVIORS_WORKBOOK_PATH.exists():
        return {}

    try:
        workbook_data = json.loads(LEADERSHIP_BEHAVIORS_WORKBOOK_PATH.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"Error loading leadership behaviors workbook data: {exc}")
        return {}

    normalized: Dict[str, List[Dict[str, Any]]] = {}
    for group_name, rows in workbook_data.items():
        if not isinstance(rows, list):
            continue

        normalized_rows = []
        for row in rows:
            if not isinstance(row, dict):
                continue

            behavior_text = str(row.get("behavior_text", "")).strip()
            meaning_text = str(row.get("meaning_text", "")).strip()
            row_rating_levels = [
                str(level).strip()
                for level in row.get("rating_levels", [])
                if str(level).strip()
            ]
            tracks = []
            for track in row.get("tracks", []):
                if not isinstance(track, dict):
                    continue
                label = str(track.get("label", "")).strip()
                rating_levels = [
                    str(level).strip()
                    for level in track.get("rating_levels", [])
                    if str(level).strip()
                ]
                if label:
                    tracks.append({
                        "label": label,
                        "meaning_text": str(track.get("meaning_text", "")).strip(),
                        "rating_levels": rating_levels,
                    })

            if behavior_text:
                title_line = next((line.strip() for line in behavior_text.splitlines() if line.strip()), "")
                normalized_rows.append({
                    "title": title_line,
                    "behavior_text": behavior_text,
                    "meaning_text": meaning_text,
                    "tracks": tracks,
                    "rating_levels": row_rating_levels,
                    "description_en": meaning_text,
                    "description_th": "",
                })

        if normalized_rows:
            normalized[group_name] = normalized_rows

    return normalized


LEADERSHIP_BEHAVIORS_GROUPED_DATA = load_leadership_behaviors_workbook()


def get_leadership_behavior_group(job_level: Any) -> Optional[str]:
    level = safe_int(job_level, 0)
    if 8 <= level <= 9:
        return "L8-L9"
    if 10 <= level <= 11:
        return "L10-L11"
    if 12 <= level <= 15:
        return "L12-15"
    return None


def format_leadership_behavior_title(title: Any) -> str:
    raw_title = str(title or "").strip()
    if not raw_title:
        return ""

    lowercased = "".join(ch.lower() if "A" <= ch <= "Z" else ch for ch in raw_title)
    for index, ch in enumerate(lowercased):
        if "a" <= ch <= "z":
            return lowercased[:index] + ch.upper() + lowercased[index + 1:]
    return lowercased


def get_leadership_behaviors_display_map(job_level: Any) -> Dict[int, Dict[str, Any]]:
    group_name = get_leadership_behavior_group(job_level)
    group_rows = LEADERSHIP_BEHAVIORS_GROUPED_DATA.get(group_name or "", [])
    if group_rows:
        return {
            index: {
                "title": format_leadership_behavior_title(row.get("title", "")),
                "behavior_text": row.get("behavior_text", ""),
                "tracks": row.get("tracks", []),
                "description_en": row.get("description_en", ""),
                "description_th": row.get("description_th", ""),
                "rating_levels": row.get("rating_levels", []),
            }
            for index, row in enumerate(group_rows, start=1)
        }
    return LEADERSHIP_BEHAVIORS_DATA

# Common styles with THEME SWITCHER ENHANCEMENT
# CSS to add for theme toggle

# HTML to add for theme toggle
THEME_HTML = '''
    <!-- Theme Toggle Section -->
    <div class="theme-toggle">
        <label class="theme-toggle-label">Theme</label>
        <label class="theme-switch">
            <input type="checkbox" id="themeToggle">
            <div class="theme-switch-track">
                <div class="theme-switch-thumb">
                    <span id="themeIcon">🌙</span>
                </div>
            </div>
            <span class="theme-switch-text" id="themeText">Light</span>
        </label>
    </div>
    
'''

# JavaScript to add for theme switching
THEME_JS = '''
    <!-- Theme Switcher Script -->
    <script>
    (function() {
        const THEME_KEY = 'pe-app-theme';
        const themeToggle = document.getElementById('themeToggle');
        const themeText = document.getElementById('themeText');
        const themeIcon = document.getElementById('themeIcon');
        const html = document.documentElement;
        
        function loadTheme() {
            const savedTheme = localStorage.getItem(THEME_KEY) || 'light';
            applyTheme(savedTheme);
        }
        
        function applyTheme(theme) {
            html.setAttribute('data-theme', theme);
            if (themeToggle) themeToggle.checked = (theme === 'dark');
            updateThemeUI(theme);
        }
        
        function updateThemeUI(theme) {
            if (theme === 'dark') {
                if (themeText) themeText.textContent = 'Dark';
                if (themeIcon) themeIcon.textContent = '☀️';
            } else {
                if (themeText) themeText.textContent = 'Light';
                if (themeIcon) themeIcon.textContent = '🌙';
            }
        }
        
        if (themeToggle) {
            themeToggle.addEventListener('change', function() {
                const newTheme = this.checked ? 'dark' : 'light';
                applyTheme(newTheme);
                localStorage.setItem(THEME_KEY, newTheme);
                
                html.style.transition = 'background 0.3s ease, color 0.3s ease';
                setTimeout(() => {
                    html.style.transition = '';
                }, 300);
            });
        }
        
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', loadTheme);
        } else {
            loadTheme();
        }
        
        if (typeof window.addEventListener === 'function') {
            window.addEventListener('popstate', loadTheme);
        }
    })();
    </script>
'''


# Login template
LOGIN_TEMPLATE = """
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Performance Evaluation System</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='css/app.css') }}">
    <style>
    .login-container {
        max-width: 450px;
        margin: 0 auto;
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        padding-top: 0;
    }
    body {
        padding-top: 0;
    }
    </style>
</head>
<body>
    <div class="particle particle-1"></div>
    <div class="particle particle-2"></div>
    <div class="particle particle-3"></div>

    <div class="login-container">
        <div class="content-card" style="width: 100%;">
            <div class="logo-icon">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="white" style="width: 40px; height: 40px;">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
        </svg>
        </div>

            <div style="text-align: center; margin-bottom: 30px;">
                <h1 class="gradient-text" style="font-size: 2em; margin-bottom: 10px;">Welcome</h1>
                <p style="color: #64748b; font-size: 0.9em;">Sign in with your work Microsoft 365 account</p>
            </div>

            {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, message in messages %}
                <div class="alert-{{ category }}">
                    <strong>{{ message }}</strong>
                </div>
                {% endfor %}
            {% endif %}
            {% endwith %}

            <form method="POST" style="margin-top: 20px;">
                <button type="submit" class="btn-primary" style="width: 100%; background: linear-gradient(135deg, #00A4EF 0%, #0078D4 100%);">
                    <span style="position: relative; z-index: 1; display: flex; align-items: center; justify-content: center; gap: 12px;">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 23 23" style="width: 21px; height: 21px;">
                            <path fill="#f3f3f3" d="M0 0h23v23H0z"/>
                            <path fill="#f35325" d="M1 1h10v10H1z"/>
                            <path fill="#81bc06" d="M12 1h10v10H12z"/>
                            <path fill="#05a6f0" d="M1 12h10v10H1z"/>
                            <path fill="#ffba08" d="M12 12h10v10H12z"/>
                        </svg>
                        <span>Sign in with Microsoft 365</span>
                    </span>
                </button>
            </form>

            <div class="info-box" style="margin-top: 25px;">
                <div class="info-box-title">🔐 Security Notice</div>
                <div class="info-box-text">
                    Your credentials are encrypted and secure. Please ensure you're on a trusted network.
                </div>
            </div>
        </div>
    </div>
    <div style="position: fixed; bottom: 0; left: 0; right: 0; padding: 15px; text-align: center; z-index: 9999;">
        <p style="color: white; margin: 0; font-size: 13px;">Powered by TCCtech HRIT®2026</p>
    </div> 
</body>
</html>
"""

PRINT_SUMMARY_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print Performance Evaluation</title>
    <style>
        @page {
            size: A4;
            margin: 1.2cm 1.1cm 1.4cm 1.1cm;
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #ffffff;
            color: #1f2937;
            margin: 0;
            font-size: 11px;
            line-height: 1.45;
        }

        .container {
            width: 100%;
            max-width: 18.8cm;
            margin: 0 auto;
        }

        .report-header {
            border-bottom: 2px solid #0f4c81;
            padding-bottom: 10px;
            margin-bottom: 14px;
        }

        .report-title {
            margin: 0 0 4px 0;
            font-size: 22px;
            font-weight: 700;
            color: #0f172a;
        }

        .report-subtitle {
            margin: 0;
            font-size: 10px;
            color: #475569;
        }

        .section {
            margin-top: 14px;
            page-break-inside: avoid;
        }

        .section-title {
            margin: 0 0 8px 0;
            padding: 6px 10px;
            background: #eaf2fb;
            border-left: 4px solid #0f4c81;
            font-size: 14px;
            font-weight: 700;
            color: #0f172a;
        }

        .subsection-title {
            margin: 12px 0 6px 0;
            font-size: 12px;
            font-weight: 700;
            color: #1e3a5f;
        }

        .profile-grid {
            display: table;
            width: 100%;
            border-collapse: separate;
            border-spacing: 8px 8px;
        }

        .profile-row {
            display: table-row;
        }

        .profile-card {
            display: table-cell;
            width: 50%;
            padding: 8px 10px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            background: #f8fafc;
            vertical-align: top;
        }

        .profile-label {
            display: block;
            margin-bottom: 2px;
            font-size: 9px;
            font-weight: 700;
            letter-spacing: 0.04em;
            text-transform: uppercase;
            color: #64748b;
        }

        .profile-value {
            font-size: 12px;
            font-weight: 600;
            color: #0f172a;
            word-break: break-word;
        }

        .score-grid {
            width: 100%;
            border-collapse: separate;
            border-spacing: 8px 8px;
        }

        .score-card,
        .score-card-final {
            width: 50%;
            padding: 10px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            background: #ffffff;
            vertical-align: top;
        }

        .score-card-final {
            background: #edf6ff;
            border-color: #93c5fd;
        }

        .score-name {
            margin: 0 0 6px 0;
            font-size: 11px;
            font-weight: 700;
            color: #1e3a5f;
        }

        .score-meta {
            display: table;
            width: 100%;
        }

        .score-meta-cell {
            display: table-cell;
            width: 50%;
            vertical-align: top;
        }

        .score-meta-cell.full {
            width: 100%;
        }

        .score-meta-label {
            display: block;
            font-size: 9px;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }

        .score-meta-value {
            display: block;
            margin-top: 2px;
            font-size: 14px;
            font-weight: 700;
            color: #0f172a;
        }

        .modern-table {
            border-collapse: collapse;
            width: 100%;
            margin: 6px 0 0 0;
            table-layout: fixed;
        }

        .modern-table th,
        .modern-table td {
            border: 1px solid #cbd5e1;
            padding: 7px 8px;
            text-align: left;
            vertical-align: top;
            word-wrap: break-word;
            overflow-wrap: break-word;
            word-break: normal;
        }

        .modern-table th {
            background: #eff6ff;
            color: #1e3a5f;
            font-size: 10px;
            font-weight: 700;
        }

        .modern-table th:nth-child(1),
        .modern-table td:nth-child(1) {
            width: 84%;
        }

        .modern-table th:nth-child(2),
        .modern-table td:nth-child(2) {
            width: 16%;
            text-align: center;
        }

        .modern-table tr {
            page-break-inside: avoid;
        }

        .behavior-card {
            margin-top: 10px;
            padding: 10px 11px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            background: #ffffff;
            page-break-inside: avoid;
        }

        .behavior-header {
            display: table;
            width: 100%;
            margin-bottom: 8px;
        }

        .behavior-title {
            display: table-cell;
            padding-right: 10px;
            font-size: 12px;
            font-weight: 700;
            color: #0f172a;
            vertical-align: top;
        }

        .behavior-title-plain {
            font-weight: 400;
        }

        .behavior-score {
            display: table-cell;
            width: 78px;
            text-align: center;
            vertical-align: top;
        }

        .score-pill {
            display: inline-block;
            min-width: 54px;
            padding: 5px 8px;
            border-radius: 999px;
            background: #dbeafe;
            color: #1d4ed8;
            font-weight: 700;
            font-size: 12px;
        }

        .behavior-text,
        .comment-text {
            margin: 0;
            color: #334155;
            white-space: pre-line;
        }

        .behavior-text + .behavior-text {
            margin-top: 4px;
        }

        .track-grid {
            margin-top: 8px;
        }

        .track-card {
            margin-top: 7px;
            padding: 8px 9px;
            border: 1px solid #dbe4f0;
            border-radius: 6px;
            background: #f8fafc;
            page-break-inside: avoid;
        }

        .track-title {
            margin: 0 0 4px 0;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            color: #1e3a5f;
        }

        .track-meaning {
            margin: 0 0 5px 0;
            color: #334155;
            white-space: pre-line;
        }

        [data-theme="dark"] .track-meaning,
        [data-theme="dark"] .track-meaning strong {
            color: #111827 !important;
        }

        .guideline-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 4px;
            table-layout: fixed;
        }

        .guideline-table td {
            border: 1px solid #dbe4f0;
            padding: 5px 6px;
            vertical-align: top;
        }

        .guideline-label {
            display: block;
            margin-bottom: 2px;
            font-size: 9px;
            font-weight: 700;
            color: #1e3a5f;
            text-transform: uppercase;
        }

        .guideline-text {
            display: block;
            color: #334155;
            white-space: pre-line;
        }

        .comments-grid {
            display: table;
            width: 100%;
            border-collapse: separate;
            border-spacing: 8px 0;
        }

        .comment-card {
            display: table-cell;
            width: 50%;
            padding: 10px;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
            background: #ffffff;
            vertical-align: top;
        }

        .comment-title {
            margin: 0 0 6px 0;
            font-size: 11px;
            font-weight: 700;
            color: #1e3a5f;
        }

        .average-score {
            margin-top: 10px;
            padding: 8px 10px;
            border: 1px solid #bfdbfe;
            border-radius: 6px;
            background: #eff6ff;
            font-size: 11px;
            font-weight: 700;
            color: #1e3a5f;
            text-align: right;
        }

        .muted {
            color: #64748b;
        }

        .page-break {
            page-break-before: always;
        }

        .page-break-avoid {
            page-break-inside: avoid;
        }

        hr.section-rule {
            border: none;
            border-top: 1px solid #dbe4f0;
            margin: 12px 0;
        }
    </style>
</head>
<body onload="window.print()">
    <div class="container">
        <div class="report-header">
            <h1 class="report-title">Performance Evaluation Summary</h1>
            <p class="report-subtitle">Formal evaluation report for review, calibration, and PDF export.</p>
        </div>

        <div class="section">
            <h2 class="section-title">Employee Profile</h2>
            <div class="profile-grid">
                <div class="profile-row">
                    <div class="profile-card">
                        <span class="profile-label">Employee Name</span>
                        <span class="profile-value">{{ profile.get('full_name', '') }}</span>
                    </div>
                    <div class="profile-card">
                        <span class="profile-label">Employee ID</span>
                        <span class="profile-value">{{ profile.get('employee_id', '') }}</span>
                    </div>
                </div>
                <div class="profile-row">
                    <div class="profile-card">
                        <span class="profile-label">Position</span>
                        <span class="profile-value">{{ profile.get('position', '') }}</span>
                    </div>
                    <div class="profile-card">
                        <span class="profile-label">Division / Department</span>
                        <span class="profile-value">{{ profile.get('division', '') }}</span>
                    </div>
                </div>
                <div class="profile-row">
                    <div class="profile-card">
                        <span class="profile-label">Job Level</span>
                        <span class="profile-value">{{ profile.get('job_level', '') }}</span>
                    </div>
                    <div class="profile-card">
                        <span class="profile-label">Evaluation Year</span>
                        <span class="profile-value">{{ selected_year or summary_data.get('eval_year') or session.get('eval_year') or 2026 }}</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="section">
            <h2 class="section-title">Score Summary</h2>
            <table class="score-grid">
                <tr>
                    <td class="score-card">
                        <p class="score-name">Performance KPI</p>
                        <div class="score-meta">
                            <div class="score-meta-cell">
                                <span class="score-meta-label">Weight</span>
                                <span class="score-meta-value">{{ "%.2f"|format((summary_data.get('perf_kpi_weight_pct', 0) or 0)|float) }}%</span>
                            </div>
                            <div class="score-meta-cell">
                                <span class="score-meta-label">Score</span>
                                <span class="score-meta-value">{{ "%.2f"|format((summary_data.get('perf_kpi_score', 0) or 0)|float) }}</span>
                            </div>
                        </div>
                    </td>
                    <td class="score-card">
                        <p class="score-name">Core Behaviors</p>
                        <div class="score-meta">
                            <div class="score-meta-cell">
                                <span class="score-meta-label">Weight</span>
                                <span class="score-meta-value">{{ "%.2f"|format((summary_data.get('core_behaviors_weight_pct', 0) or 0)|float) }}%</span>
                            </div>
                            <div class="score-meta-cell">
                                <span class="score-meta-label">Score</span>
                                <span class="score-meta-value">{{ "%.2f"|format((summary_data.get('core_behaviors_score', 0) or 0)|float) }}</span>
                            </div>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td class="score-card">
                        <p class="score-name">Leadership Behaviors</p>
                        <div class="score-meta">
                            <div class="score-meta-cell">
                                <span class="score-meta-label">Weight</span>
                                <span class="score-meta-value">{{ "%.2f"|format((summary_data.get('leadership_behaviors_weight_pct', 0) or 0)|float) }}%</span>
                            </div>
                            <div class="score-meta-cell">
                                <span class="score-meta-label">Score</span>
                                <span class="score-meta-value">{{ "%.2f"|format((summary_data.get('leadership_behaviors_score', 0) or 0)|float) }}</span>
                            </div>
                        </div>
                    </td>
                    <td class="score-card-final">
                        <p class="score-name">Final Result</p>
                        <div class="score-meta">
                            <div class="score-meta-cell full">
                                <span class="score-meta-label">Final Total Weighted Score</span>
                                <span class="score-meta-value">{{ "%.2f"|format((summary_data.get('final_total_score', 0) or 0)|float) }}</span>
                            </div>
                        </div>
                    </td>
                </tr>
            </table>
        </div>

        <div class="section">
            <h2 class="section-title">Detailed Objectives</h2>

        {% if job_level >= 8 and has_group_kpi_data %}
        <h3 class="subsection-title">Group Shared KPI</h3>
        <p><strong>Score:</strong> {{ "%.2f"|format((group_kpi_data.get('group_score', 0) or 0)|float) }}</p>
        <p><strong>Total Weighted Score:</strong> {{ "%.2f"|format((group_kpi_data.get('group_result', 0) or 0)|float) }}</p>
        <hr class="section-rule">
        {% endif %}

        {% if bu_lob_kpi_filtered %}
        <h3 class="subsection-title">BU/LoB Shared KPI</h3>
        <p><strong>Total Weighted Score:</strong> {{ "%.2f"|format((bu_lob_kpi_data.get('total_score', 0) or 0)|float) }}</p>
        <table class="modern-table">
            <thead>
                <tr><th>Description</th><th>Score</th></tr>
            </thead>
            <tbody>
                {% for row in bu_lob_kpi_filtered %}
                <tr>
                    <td>{{ row.description }}</td>
                    <td>{{ "%.2f"|format((row.score or 0)|float) }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
        <hr class="section-rule">
        {% endif %}

        {% if org_cap_filtered %}
        <h3 class="subsection-title">Organizational Capability Development</h3>
        <p><strong>Total Weighted Score:</strong> {{ "%.2f"|format((org_cap_data.get('total_score', 0) or 0)|float) }}</p>
        <table class="modern-table">
            <thead>
                <tr><th>Description</th><th>Score</th></tr>
            </thead>
            <tbody>
                {% for row in org_cap_filtered %}
                <tr>
                    <td>{{ row.description }}</td>
                    <td>{{ "%.2f"|format((row.score or 0)|float) }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
        <hr class="section-rule">
        {% endif %}

        {% if job_level >= 8 and people_dev_filtered %}
        <h3 class="subsection-title">People Development</h3>
        <p><strong>Total Weighted Score:</strong> {{ "%.2f"|format((people_dev_data.get('total_score', 0) or 0)|float) }}</p>
        <table class="modern-table">
            <thead>
                <tr><th>Description</th><th>Score</th></tr>
            </thead>
            <tbody>
                {% for row in people_dev_filtered %}
                <tr>
                    <td>{{ row.description }}</td>
                    <td>{{ "%.2f"|format((row.score or 0)|float) }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
        <hr class="section-rule">
        {% endif %}

        {% if bu_obj_filtered %}
        <h3 class="subsection-title">Business Unit Objectives</h3>
        <p><strong>Total Weighted Score:</strong> {{ "%.2f"|format((bu_obj_data.get('total_score', 0) or 0)|float) }}</p>
        <table class="modern-table">
            <thead>
                <tr><th>Description</th><th>Score</th></tr>
            </thead>
            <tbody>
                {% for row in bu_obj_filtered %}
                <tr>
                    <td>{{ row.description }}</td>
                    <td>{{ "%.2f"|format((row.score or 0)|float) }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
        {% endif %}
        </div>

        {% if job_level <= 11 and core_behaviors_data.scores %}
        <div class="section page-break">
            <h2 class="section-title">Core Behaviors</h2>
            <p class="muted">Behavior definitions and scores are shown according to the employee job-level group.</p>
            {% for id, score in core_behaviors_data.scores.items() %}
            {% set behavior = core_behaviors_map.get(id|int) %}
            {% if behavior %}
            <div class="behavior-card">
                <div class="behavior-header">
                    <div class="behavior-title behavior-title-plain">{{ behavior.title }}</div>
                    <div class="behavior-score"><span class="score-pill">{{ "%.2f"|format((score or 0)|float) }}</span></div>
                </div>
                {% if behavior.description_en %}
                <p class="behavior-text">{{ behavior.description_en }}</p>
                {% endif %}
                {% if behavior.description_th %}
                <p class="behavior-text">{{ behavior.description_th }}</p>
                {% endif %}
            </div>
            {% endif %}
            {% endfor %}
            <div class="average-score">Average Score: {{ "%.2f"|format((summary_data.get('core_behaviors_avg', 0) or 0)|float) }}</div>
        </div>
        {% endif %}

{% if job_level >= 8 and leadership_behaviors_data.scores %}
        <div class="section page-break">
            <h2 class="section-title">Leadership Behaviors</h2>
            <p class="muted">Track-specific guidance is printed beneath each leadership behavior.</p>
            {% for id, score in leadership_behaviors_data.scores.items() %}
            {% set behavior = leadership_behaviors_map.get(id|int) %}
            {% if behavior %}
            <div class="behavior-card">
                <div class="behavior-header">
                    <div class="behavior-title behavior-title-plain">{{ behavior.title }}</div>
                    <div class="behavior-score"><span class="score-pill">{{ "%.2f"|format((score or 0)|float) }}</span></div>
                </div>
                {% if behavior.description_en %}
                <p class="behavior-text">{{ behavior.description_en }}</p>
                {% endif %}
                {% if behavior.description_th %}
                <p class="behavior-text">{{ behavior.description_th }}</p>
                {% endif %}
            </div>
            {% endif %}
            {% endfor %}
            <div class="average-score">Average Score: {{ "%.2f"|format((summary_data.get('leadership_behaviors_avg', 0) or 0)|float) }}</div>
        </div>
        {% endif %}

        <div class="section">
            <h2 class="section-title">Comments</h2>
            <div class="comments-grid">
                <div class="comment-card">
                    <p class="comment-title">Employee Comments</p>
                    <p class="comment-text">{{ comments_data.get('employee_comments', 'N/A') }}</p>
                </div>
                <div class="comment-card">
                    <p class="comment-title">Supervisor Comments</p>
                    <p class="comment-text">{{ comments_data.get('supervisor_comments', 'N/A') }}</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
"""


def get_db_connection() -> Optional[mysql.connector.MySQLConnection]:
    """Establish and return a database connection with proper typing."""
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        return cast(mysql.connector.MySQLConnection, conn)
    except Error as e:
        print(f"Error connecting to database: {e}")
        return None
def get_db_cursor(connection: Optional[mysql.connector.MySQLConnection]) -> Optional[MySQLCursor]:
    """Get a database cursor with proper typing."""
    if not connection:
        return None
    try:
        cursor = connection.cursor(dictionary=True)
        return cast(MySQLCursor, cursor)
    except Error as e:
        print(f"Error creating cursor: {e}")
        return None
        return None


def verify_table_exists():
    """Verify that the staff_saveddata table exists and create it if it doesn't."""
    connection = get_db_connection()
    if not connection:
        return False
    cursor = None
    try:
        cursor = connection.cursor()
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
                employee_id VARCHAR(50) NOT NULL,
                form_id VARCHAR(100) NOT NULL,
                data_json TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (employee_id, form_id)
            )
        """)
        connection.commit()
        return True
    except Error as e:
        print(f"Error verifying/creating table: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        connection.close()


def verify_versions_table_exists():
    """Ensure a yearly versions table exists to store per-eval-year form data."""
    connection = get_db_connection()
    if not connection:
        return False
    cursor = None
    try:
        cursor = connection.cursor()
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS {VERSIONS_TABLE_NAME} (
                employee_id VARCHAR(50) NOT NULL,
                form_id VARCHAR(100) NOT NULL,
                eval_year INT NOT NULL,
                data_json TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (employee_id, form_id, eval_year)
            )
        """)
        connection.commit()
        return True
    except Error as e:
        print(f"Error verifying/creating versions table: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        connection.close()

def verify_summary_table_exists():
    """Ensure the summary history table exists for year-by-year archives."""
    connection = get_db_connection()
    if not connection:
        return False
    cursor = None
    try:
        cursor = connection.cursor()
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS {SUMMARY_TABLE_NAME} (
                employee_id VARCHAR(50) NOT NULL,
                eval_year INT NOT NULL,
                summary_json TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (employee_id, eval_year)
            )
        """)
        connection.commit()
        return True
    except Error as e:
        print(f"Error verifying/creating summary table: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        connection.close()


def verify_supervisor_review_table_exists():
    """Ensure the supervisor review table exists for separate supervisor-entered scoring."""
    connection = get_db_connection()
    if not connection:
        return False
    cursor = None
    try:
        cursor = connection.cursor()
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS {SUPERVISOR_REVIEW_TABLE_NAME} (
                target_employee_id VARCHAR(50) NOT NULL,
                reviewer_employee_id VARCHAR(50) NOT NULL,
                form_id VARCHAR(100) NOT NULL,
                eval_year INT NOT NULL,
                data_json TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (target_employee_id, form_id, eval_year)
            )
        """)
        connection.commit()
        return True
    except Error as e:
        print(f"Error verifying/creating supervisor review table: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        connection.close()


def verify_staff_promotion_table_exists():
    """Ensure the staff promotion proposal table exists."""
    connection = get_db_connection()
    if not connection:
        return False
    cursor = None
    try:
        cursor = connection.cursor()
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS {STAFF_PROMOTION_TABLE_NAME} (
                id INT NOT NULL AUTO_INCREMENT,
                target_employee_id VARCHAR(50) NOT NULL,
                proposer_employee_id VARCHAR(50) NOT NULL,
                director_employee_id VARCHAR(50) DEFAULT NULL,
                current_reviewer_employee_id VARCHAR(50) DEFAULT NULL,
                hr_director_employee_id VARCHAR(50) NOT NULL,
                eval_year INT NOT NULL,
                profile_snapshot_json TEXT NOT NULL,
                score_history_json TEXT,
                current_job_description TEXT NOT NULL,
                proposed_job_level VARCHAR(50) NOT NULL,
                new_job_title TEXT NOT NULL,
                new_job_description TEXT NOT NULL,
                new_job_assignment TEXT NOT NULL,
                reasons_for_adjustment TEXT NOT NULL,
                status VARCHAR(30) NOT NULL DEFAULT 'submitted',
                viewed_at TIMESTAMP NULL DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                INDEX idx_staff_promotion_hr (hr_director_employee_id, status, created_at),
                INDEX idx_staff_promotion_target (target_employee_id, eval_year)
            )
        """)
        cursor.execute(f"SHOW COLUMNS FROM {STAFF_PROMOTION_TABLE_NAME} LIKE 'viewed_at'")
        viewed_column = cursor.fetchone()
        if not viewed_column:
            cursor.execute(f"ALTER TABLE {STAFF_PROMOTION_TABLE_NAME} ADD COLUMN viewed_at TIMESTAMP NULL DEFAULT NULL AFTER status")
        cursor.execute(f"SHOW COLUMNS FROM {STAFF_PROMOTION_TABLE_NAME} LIKE 'director_employee_id'")
        director_column = cursor.fetchone()
        if not director_column:
            cursor.execute(f"ALTER TABLE {STAFF_PROMOTION_TABLE_NAME} ADD COLUMN director_employee_id VARCHAR(50) DEFAULT NULL AFTER proposer_employee_id")
        cursor.execute(f"SHOW COLUMNS FROM {STAFF_PROMOTION_TABLE_NAME} LIKE 'current_reviewer_employee_id'")
        reviewer_column = cursor.fetchone()
        if not reviewer_column:
            cursor.execute(f"ALTER TABLE {STAFF_PROMOTION_TABLE_NAME} ADD COLUMN current_reviewer_employee_id VARCHAR(50) DEFAULT NULL AFTER director_employee_id")
        connection.commit()
        return True
    except Error as e:
        print(f"Error verifying/creating staff promotion table: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        connection.close()


def get_employee_profile(employee_id: str) -> Dict[str, Any]:
    """Fetches a single employee's profile from the database with proper error handling."""
    default_profile = {
        'full_name': 'Unknown Employee',
        'employee_id': employee_id,
        'position': 'N/A',
        'division': 'N/A',
        'section': 'N/A',
        'team': 'N/A',
        'job_level': 4,
        'current_supervisor': 'N/A',
        'company': 'N/A'
    }

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        if not conn:
            print("Could not establish database connection")
            return default_profile

        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM pe_staff WHERE employee_id=%s", (employee_id,))
        profile = cursor.fetchone()

        if not profile:
            return default_profile

        # Convert profile to dictionary with proper type handling
        profile_dict: Dict[str, Any] = {}
        if profile and isinstance(profile, dict):
            # Cast to Dict to satisfy type checker since dictionary=True guarantees dict
            profile_dict = cast(Dict[str, Any], profile)
        elif profile:
            # Fallback: try to convert to dict if it's not already
            try:
                # Use dict() constructor with explicit Any type
                profile_dict = dict(cast(Any, profile))
            except (AttributeError, TypeError, ValueError):
                # If conversion fails, return default profile
                return default_profile

        result = {
            'full_name': safe_get(profile_dict, 'full_name', 'Unknown Employee'),
            'employee_id': safe_get(profile_dict, 'employee_id', employee_id),
            'position': safe_get(profile_dict, 'position', 'N/A'),
            'division': safe_get(profile_dict, 'division', 'N/A'),
            'section': safe_get(profile_dict, 'section', 'N/A'),
            'team': safe_get(profile_dict, 'team', 'N/A'),
            'job_level': safe_int(safe_get(profile_dict, 'job_level'), 4),
            'current_supervisor': safe_get(profile_dict, 'current_supervisor', 'N/A'),
            'company': safe_get(profile_dict, 'company', 'N/A')
        }
        return {**default_profile, **result}
    except Error as err:
        print(f"Error fetching employee profile: {err}")
        return default_profile
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


def get_user_by_credentials(username: str, password: str) -> Optional[Dict[str, Any]]:
    """Fetches a user from the directory based on username and password.

    Note: Local password login is disabled; use SSO.
    """
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        if not conn:
            print("Could not establish database connection")
            return None

        if password:
            # Local password auth is not supported after moving to SSO-only directory
            return None

        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            "SELECT employee_id, email, role FROM pe_staff "
            "WHERE LOWER(TRIM(email)) = %s OR LOWER(TRIM(username)) = %s OR CAST(employee_id AS CHAR) = %s",
            (username.casefold(), username.casefold(), username),
        )
        user = cursor.fetchone()

        if not user:
            return None

        # Handle the cursor result properly - it could be a dict or dict-like object
        # Convert to a clean dictionary with string keys and proper values
        user_dict_str: Dict[str, Any] = {}
        
        if isinstance(user, dict):
            # Already a dict, convert any bytes to strings
            for k, v in user.items():
                key = k.decode('utf-8') if isinstance(k, bytes) else str(k)
                value = v.decode('utf-8') if isinstance(v, bytes) else v
                user_dict_str[key] = value
        else:
            # Convert other dict-like objects to dict using cast
            try:
                # Cast to Any first to bypass type checking, then iterate
                temp_dict = cast(Dict[str, Any], user)
                for k, v in temp_dict.items():
                    key = k.decode('utf-8') if isinstance(k, bytes) else str(k)
                    value = v.decode('utf-8') if isinstance(v, bytes) else v
                    user_dict_str[key] = value
            except (TypeError, ValueError, AttributeError):
                print("Error converting user result to dictionary")
                return None
        
        return {
            'employee_id': safe_get(user_dict_str, 'employee_id', ''),
            'username': safe_get(user_dict_str, 'email', ''),
            'password': '',
            'role': safe_get(user_dict_str, 'role', 'user')
        }
    except Error as err:
        print(f"Error fetching user: {err}")
        return None
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


def get_user_by_username(username: str) -> Optional[Dict[str, Any]]:
    """Fetch a user by email (used after Azure AD sign-in)."""
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        if not conn:
            print("Could not establish database connection")
            return None

        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            "SELECT employee_id, email, role FROM pe_staff "
            "WHERE LOWER(TRIM(email)) = %s OR LOWER(TRIM(username)) = %s OR CAST(employee_id AS CHAR) = %s",
            (username.casefold(), username.casefold(), username),
        )
        user = cursor.fetchone()
        if not user:
            return None

        user_dict: Dict[str, Any] = {}
        if isinstance(user, dict):
            for k, v in user.items():
                key = k.decode('utf-8') if isinstance(k, bytes) else str(k)
                value = v.decode('utf-8') if isinstance(v, bytes) else v
                user_dict[key] = value
        return {
            'employee_id': safe_get(user_dict, 'employee_id', ''),
            'username': safe_get(user_dict, 'email', ''),
            'password': '',
            'role': safe_get(user_dict, 'role', 'user')
        }
    except Error as err:
        print(f"Error fetching user by username: {err}")
        return None
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


def get_graph_user_identifier_by_employee_id(employee_id: Any) -> Optional[str]:
    """Resolve a usable Graph user identifier (email/UPN/username) for an employee."""
    emp_id = str(employee_id or "").strip()
    if not emp_id:
        return None

    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        if not conn:
            return None
        cursor = conn.cursor(dictionary=True)
        cursor.execute(
            "SELECT email, username FROM pe_staff WHERE CAST(employee_id AS CHAR) = %s LIMIT 1",
            (emp_id,),
        )
        row = cursor.fetchone()
        if not row or not isinstance(row, dict):
            return None

        email = str(safe_get(row, 'email', '') or '').strip()
        username = str(safe_get(row, 'username', '') or '').strip()
        candidates = [email, username]
        for candidate in candidates:
            if candidate and "@" in candidate:
                return candidate
        for candidate in candidates:
            if candidate:
                return candidate
        return None
    except Exception as exc:
        app.logger.warning("Graph identifier lookup failed for employee_id=%s: %s", emp_id, exc)
        return None
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if conn:
            try:
                conn.close()
            except Exception:
                pass


def can_view_employee_photo(viewer_employee_id: Any, target_employee_id: Any) -> bool:
    """Authorize whether current user can view target employee details/photo."""
    viewer_id = str(viewer_employee_id or "").strip()
    target_id = str(target_employee_id or "").strip()
    if not viewer_id or not target_id:
        return False
    if viewer_id == target_id:
        return True
    if is_admin_employee(viewer_id):
        return True

    reporting_employee_ids = get_reporting_employee_ids(viewer_id)
    if reporting_employee_ids:
        return target_id in {str(eid).strip() for eid in reporting_employee_ids}

    division_filter = SPECIAL_EXPORT_ACCESS.get(viewer_id)
    if division_filter is None:
        return False

    target_profile = get_employee_profile(target_id)
    target_division = target_profile.get('division')
    if isinstance(division_filter, list):
        return target_division in division_filter
    return target_division == division_filter


def is_director_promotion_user(employee_id: Any) -> bool:
    employee = str(employee_id or '').strip()
    return bool(employee) and is_director_level_reviewer(employee)


def is_staff_promotion_module_enabled() -> bool:
    return bool(STAFF_PROMOTION_MODULE_ENABLED)


def is_staff_promotion_dev_allowed(employee_id: Any) -> bool:
    if not is_staff_promotion_module_enabled():
        return False
    employee = str(employee_id or '').strip()
    return employee == STAFF_PROMOTION_TESTER_ID


def is_staff_promotion_test_super_admin(employee_id: Any) -> bool:
    if not is_staff_promotion_module_enabled():
        return False
    employee = str(employee_id or '').strip()
    return employee == STAFF_PROMOTION_TESTER_ID


def is_hr_director_user(employee_id: Any) -> bool:
    if not is_staff_promotion_module_enabled():
        return False
    employee = str(employee_id or '').strip()
    return employee == STAFF_PROMOTION_TESTER_ID


def get_staff_promotion_inbox_owner_id() -> str:
    current_employee = str(session.get('employee_id') or '').strip()
    if is_staff_promotion_test_super_admin(current_employee):
        return current_employee
    if is_hr_director_user(current_employee):
        return current_employee
    return HR_DIRECTOR_EMPLOYEE_ID


def get_staff_promotion_target_roles(target_employee_id: Any) -> Dict[str, str]:
    target_profile = get_employee_profile_row(target_employee_id)
    return {
        'manager_employee_id': str(target_profile.get('manager_id') or '').strip(),
        'director_employee_id': str(target_profile.get('director_id') or '').strip(),
    }


def is_staff_promotion_manager_for_target(viewer_employee_id: Any, target_employee_id: Any) -> bool:
    viewer_id = str(viewer_employee_id or '').strip()
    target_id = str(target_employee_id or '').strip()
    if not viewer_id or not target_id or viewer_id == target_id:
        return False
    target_roles = get_staff_promotion_target_roles(target_id)
    return viewer_id == str(target_roles.get('manager_employee_id') or '').strip()


def can_access_staff_promotion_inbox(employee_id: Any) -> bool:
    viewer_id = str(employee_id or '').strip()
    if not viewer_id:
        return False
    return is_staff_promotion_dev_allowed(viewer_id)


def get_employee_profile_row(employee_id: Any) -> Dict[str, Any]:
    employee = str(employee_id or '').strip()
    if not employee:
        return {}
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        if not conn:
            return {}
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM pe_staff WHERE CAST(employee_id AS CHAR) = %s LIMIT 1", (employee,))
        row = cursor.fetchone()
        return row if isinstance(row, dict) else {}
    except Exception as exc:
        print(f"Error loading employee profile row: {exc}")
        return {}
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if conn:
            try:
                conn.close()
            except Exception:
                pass


def get_employee_master_row(employee_id: Any) -> Dict[str, Any]:
    employee = str(employee_id or '').strip()
    if not employee:
        return {}
    conn = None
    cursor = None
    try:
        conn = get_db_connection()
        if not conn:
            return {}
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM employee_master WHERE CAST(employee_id AS CHAR) = %s LIMIT 1", (employee,))
        row = cursor.fetchone()
        return row if isinstance(row, dict) else {}
    except Exception as exc:
        print(f"Error loading employee_master row: {exc}")
        return {}
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if conn:
            try:
                conn.close()
            except Exception:
                pass


def _pick_profile_value(profile: Dict[str, Any], keys: List[str], default: str = '') -> str:
    for key in keys:
        value = profile.get(key)
        if value is None:
            continue
        text = str(value).strip()
        if text:
            return text
    return default


def _parse_profile_date(value: Any) -> Optional[datetime.date]:
    if value is None:
        return None
    if isinstance(value, datetime.datetime):
        return value.date()
    if isinstance(value, datetime.date):
        return value
    text = str(value).strip()
    if not text:
        return None
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y", "%Y/%m/%d", "%d %b %Y", "%d %B %Y"):
        try:
            return datetime.datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def _format_age_from_birth_date(birth_date: Optional[datetime.date]) -> str:
    if not birth_date:
        return "-"
    today = datetime.date.today()
    years = today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))
    return str(max(years, 0))


def _format_tenure_from_start_date(start_date: Optional[datetime.date]) -> str:
    if not start_date:
        return "-"
    today = datetime.date.today()
    months = (today.year - start_date.year) * 12 + (today.month - start_date.month)
    if today.day < start_date.day:
        months -= 1
    months = max(months, 0)
    years_part = months // 12
    months_part = months % 12
    if years_part and months_part:
        return f"{years_part} yrs. {months_part} mos."
    if years_part:
        return f"{years_part} yrs."
    return f"{months_part} mos."


def _format_year_month_value(value: Any) -> str:
    raw = str(value or '').strip()
    if not raw or raw in {'-', 'N/A'}:
        return "-"
    normalized = raw.replace(',', '.')
    if '.' in normalized:
        left, right = normalized.split('.', 1)
        if left.isdigit() and right.isdigit():
            years_part = safe_int(left, 0)
            if len(right) <= 2 and safe_int(right, -1) <= 11:
                months_part = max(0, safe_int(right, 0))
                if years_part and months_part:
                    return f"{years_part} yrs. {months_part} mos."
                if years_part:
                    return f"{years_part} yrs."
                return f"{months_part} mos."
            try:
                decimal_years = float(normalized)
                total_months = max(0, int(round(decimal_years * 12)))
                years_part = total_months // 12
                months_part = total_months % 12
                if years_part and months_part:
                    return f"{years_part} yrs. {months_part} mos."
                if years_part:
                    return f"{years_part} yrs."
                return f"{months_part} mos."
            except (ValueError, TypeError):
                return raw
    if raw.isdigit():
        return f"{safe_int(raw, 0)} yrs."
    return raw


def load_employee_summary_for_year(employee_id: Any, eval_year: int) -> Dict[str, Any]:
    employee = str(employee_id or '').strip()
    if not employee:
        return {}
    summary = load_summary_history(employee, eval_year)
    if summary:
        return summary
    subordinate_summary = get_subordinate_summary_data(employee)
    if subordinate_summary and isinstance(subordinate_summary, dict):
        return subordinate_summary
    snapshot = calculate_summary_snapshot_for_employee(employee, eval_year, use_supervisor_review=False)
    if isinstance(snapshot, dict):
        summary_data = snapshot.get('summary_data')
        if isinstance(summary_data, dict):
            return summary_data
    return {}


def get_staff_promotion_score_history(employee_id: Any, eval_year: int, limit: int = 3) -> List[Dict[str, Any]]:
    employee = str(employee_id or '').strip()
    if not employee:
        return []
    candidate_years = [y for y in list_summary_years(employee) if y >= 2026]
    if eval_year not in candidate_years:
        candidate_years.insert(0, eval_year)
    history_rows: List[Dict[str, Any]] = []
    for year in sorted(set(candidate_years), reverse=True):
        summary = load_employee_summary_for_year(employee, year)
        score_value = summary.get('final_total_score')
        score = safe_float(score_value, None)
        history_rows.append({
            'eval_year': year,
            'final_total_score': f"{score:.2f}" if score is not None else "-"
        })
        if len(history_rows) >= limit:
            break
    return history_rows


def build_staff_promotion_profile_snapshot(employee_id: Any, eval_year: int) -> Dict[str, Any]:
    employee = str(employee_id or '').strip()
    raw_profile = get_employee_profile_row(employee)
    employee_master = get_employee_master_row(employee)
    profile = get_employee_profile(employee)
    birth_date = _parse_profile_date(_pick_profile_value(employee_master, ['birth_date', 'date_of_birth', 'dob', 'birthday'], _pick_profile_value(raw_profile, ['date_of_birth', 'birth_date', 'dob', 'birthday'])))
    start_date = _parse_profile_date(_pick_profile_value(employee_master, ['hiring_date', 'join_date', 'start_date', 'hire_date', 'date_of_joining', 'employment_date'], _pick_profile_value(raw_profile, ['hiring_date', 'join_date', 'start_date', 'hire_date', 'date_of_joining', 'employment_date'])))
    score_history = get_staff_promotion_score_history(employee, eval_year, limit=3)
    current_score = next((row.get('final_total_score') for row in score_history if str(row.get('final_total_score') or '').strip() not in {'', '-'}), "-")
    department_value = _pick_profile_value(employee_master, ['department'], _pick_profile_value(raw_profile, ['department', 'section', 'team'], profile.get('section', 'N/A')))
    nickname_value = _pick_profile_value(employee_master, ['nickname', 'nick_name', 'preferred_name'], _pick_profile_value(raw_profile, ['nickname', 'nick_name', 'preferred_name'], ''))
    if not nickname_value:
        full_name = str(profile.get('full_name', '') or '').strip()
        nickname_value = full_name.split(' ', 1)[0] if full_name else '-'
    age_value = _pick_profile_value(employee_master, ['age'], _pick_profile_value(raw_profile, ['age'], ''))
    tenure_value = _pick_profile_value(employee_master, ['service_year_yy_mm', 'service_year'], _pick_profile_value(raw_profile, ['tenure', 'years_of_service'], ''))
    return {
        'full_name': profile.get('full_name', 'Unknown Employee'),
        'nickname': nickname_value or '-',
        'employee_id': profile.get('employee_id', employee),
        'company': profile.get('company', 'N/A'),
        'division': profile.get('division', 'N/A'),
        'department': department_value or 'N/A',
        'tenure': _format_year_month_value(tenure_value) if tenure_value else _format_tenure_from_start_date(start_date),
        'age': _format_year_month_value(age_value) if age_value else _format_age_from_birth_date(birth_date),
        'position': profile.get('position', 'N/A'),
        'job_level': safe_int(profile.get('job_level'), 0) or '-',
        'pe_score': current_score,
        'score_history': score_history,
    }


def get_staff_promotion_manual_year_options(eval_year: int, count: int = 8) -> List[int]:
    base_year = safe_int(eval_year, get_eval_year())
    return [base_year - offset for offset in range(max(1, count))]


def normalize_staff_promotion_manual_score_entries(entries: Any) -> List[Dict[str, str]]:
    normalized: List[Dict[str, str]] = []
    if not isinstance(entries, list):
        return normalized
    for entry in entries[:3]:
        if not isinstance(entry, dict):
            continue
        year_value = str(entry.get('eval_year') or '').strip()
        score_value = str(entry.get('final_total_score') or '').strip()
        if not year_value and not score_value:
            continue
        normalized.append({
            'eval_year': year_value,
            'final_total_score': score_value,
        })
    return normalized


def extract_staff_promotion_manual_score_entries(form_source: Any) -> Tuple[List[Dict[str, str]], Optional[str]]:
    entries: List[Dict[str, str]] = []
    seen_years: Set[str] = set()
    for index in range(1, 4):
        year_value = str((form_source.get(f'manual_score_year_{index}') if form_source else '') or '').strip()
        score_value = str((form_source.get(f'manual_score_value_{index}') if form_source else '') or '').strip()
        if not year_value and not score_value:
            continue
        if not year_value or not score_value:
            return [], "Please complete both Fiscal Year and PE Score for each manual PE score row."
        if year_value in seen_years:
            return [], "Please select three different fiscal years for the manual PE scores."
        score_number = safe_float(score_value, None)
        if score_number is None or score_number < 1 or score_number > 5:
            return [], "Manual PE scores must be between 1.00 and 5.00."
        seen_years.add(year_value)
        entries.append({
            'eval_year': year_value,
            'final_total_score': f"{score_number:.2f}",
        })
    return entries, None


def can_submit_staff_promotion(viewer_employee_id: Any, target_employee_id: Any) -> bool:
    viewer_id = str(viewer_employee_id or '').strip()
    target_id = str(target_employee_id or '').strip()
    if not viewer_id or not target_id or viewer_id == target_id:
        return False
    if not is_staff_promotion_dev_allowed(viewer_id):
        return False
    if is_staff_promotion_test_super_admin(viewer_id):
        return True
    return is_staff_promotion_manager_for_target(viewer_id, target_id)


def get_staff_promotion_latest_form_for_manager(target_employee_id: Any, proposer_employee_id: Any, eval_year: int) -> Optional[Dict[str, Any]]:
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return None
        cursor = handle_cursor(connection)
        if not cursor:
            return None
        cursor.execute(f"""
            SELECT *
            FROM {STAFF_PROMOTION_TABLE_NAME}
            WHERE target_employee_id=%s AND proposer_employee_id=%s AND eval_year=%s
            ORDER BY updated_at DESC, id DESC
            LIMIT 1
        """, (
            str(target_employee_id or '').strip(),
            str(proposer_employee_id or '').strip(),
            safe_int(eval_year, get_eval_year()),
        ))
        row = cursor.fetchone()
        return row if isinstance(row, dict) else None
    except Exception as exc:
        print(f"Error loading latest staff promotion form: {exc}")
        return None
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def save_staff_promotion_form(
    target_employee_id: Any,
    proposer_employee_id: Any,
    eval_year: int,
    profile_snapshot: Dict[str, Any],
    score_history: List[Dict[str, Any]],
    form_data: Dict[str, Any],
    status: str = 'draft_manager',
    director_employee_id: Any = None,
    current_reviewer_employee_id: Any = None,
    form_id: Any = None,
) -> bool:
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return False
        cursor = handle_cursor(connection)
        if not cursor:
            return False
        target_id = str(target_employee_id or '').strip()
        proposer_id = str(proposer_employee_id or '').strip()
        year = safe_int(eval_year, get_eval_year())
        desired_status = str(status or 'draft_manager').strip().lower()
        allowed_statuses = {'draft_manager', 'submitted_to_director', 'draft_director', 'submitted_to_hr', 'approved', 'rejected'}
        if desired_status not in allowed_statuses:
            desired_status = 'draft_manager'
        current_reviewer_id = str(current_reviewer_employee_id or '').strip() or proposer_id
        director_id = str(director_employee_id or '').strip()
        target_form_id = safe_int(form_id, 0)
        if target_form_id <= 0:
            cursor.execute(f"""
                SELECT id FROM {STAFF_PROMOTION_TABLE_NAME}
                WHERE target_employee_id=%s AND proposer_employee_id=%s AND eval_year=%s AND status IN ('draft_manager', 'submitted_to_director', 'draft_director', 'submitted_to_hr', 'approved', 'rejected')
                ORDER BY updated_at DESC, id DESC
                LIMIT 1
            """, (target_id, proposer_id, year))
            existing_row = cursor.fetchone()
            target_form_id = safe_int(existing_row.get('id') if isinstance(existing_row, dict) else 0, 0)
        if target_form_id > 0:
            cursor.execute(f"""
                UPDATE {STAFF_PROMOTION_TABLE_NAME}
                SET director_employee_id=%s,
                    current_reviewer_employee_id=%s,
                    hr_director_employee_id=%s,
                    profile_snapshot_json=%s,
                    score_history_json=%s,
                    current_job_description=%s,
                    proposed_job_level=%s,
                    new_job_title=%s,
                    new_job_description=%s,
                    new_job_assignment=%s,
                    reasons_for_adjustment=%s,
                    status=%s,
                    viewed_at=%s,
                    updated_at=CURRENT_TIMESTAMP
                WHERE id=%s
            """, (
                director_id or None,
                current_reviewer_id or None,
                HR_DIRECTOR_EMPLOYEE_ID,
                json.dumps(profile_snapshot, ensure_ascii=False),
                json.dumps(score_history, ensure_ascii=False),
                str(form_data.get('current_job_description', '')).strip(),
                str(form_data.get('proposed_job_level', '')).strip(),
                str(form_data.get('new_job_title', '')).strip(),
                str(form_data.get('new_job_description', '')).strip(),
                str(form_data.get('new_job_assignment', '')).strip(),
                str(form_data.get('reasons_for_adjustment', '')).strip(),
                desired_status,
                None if desired_status in {'submitted_to_director', 'submitted_to_hr'} else datetime.datetime.now(),
                target_form_id,
            ))
        else:
            cursor.execute(f"""
                INSERT INTO {STAFF_PROMOTION_TABLE_NAME} (
                    target_employee_id,
                    proposer_employee_id,
                    director_employee_id,
                    current_reviewer_employee_id,
                    hr_director_employee_id,
                    eval_year,
                    profile_snapshot_json,
                    score_history_json,
                    current_job_description,
                    proposed_job_level,
                    new_job_title,
                    new_job_description,
                    new_job_assignment,
                    reasons_for_adjustment,
                    status,
                    viewed_at
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                target_id,
                proposer_id,
                director_id or None,
                current_reviewer_id or None,
                HR_DIRECTOR_EMPLOYEE_ID,
                year,
                json.dumps(profile_snapshot, ensure_ascii=False),
                json.dumps(score_history, ensure_ascii=False),
                str(form_data.get('current_job_description', '')).strip(),
                str(form_data.get('proposed_job_level', '')).strip(),
                str(form_data.get('new_job_title', '')).strip(),
                str(form_data.get('new_job_description', '')).strip(),
                str(form_data.get('new_job_assignment', '')).strip(),
                str(form_data.get('reasons_for_adjustment', '')).strip(),
                desired_status,
                None if desired_status in {'submitted_to_director', 'submitted_to_hr'} else datetime.datetime.now(),
            ))
        connection.commit()
        return True
    except Exception as exc:
        print(f"Error saving staff promotion form: {exc}")
        return False
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def count_incoming_staff_promotion_forms() -> int:
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return 0
        cursor = handle_cursor(connection)
        if not cursor:
            return 0
        inbox_owner_id = get_staff_promotion_inbox_owner_id()
        if is_staff_promotion_test_super_admin(inbox_owner_id):
            cursor.execute(
                f"SELECT COUNT(*) AS cnt FROM {STAFF_PROMOTION_TABLE_NAME} "
                f"WHERE status IN ('submitted_to_director', 'submitted_to_hr') "
                f"AND viewed_at IS NULL"
            )
        else:
            cursor.execute(
                f"SELECT COUNT(*) AS cnt FROM {STAFF_PROMOTION_TABLE_NAME} "
                f"WHERE current_reviewer_employee_id=%s "
                f"AND status IN ('submitted_to_director', 'submitted_to_hr') "
                f"AND viewed_at IS NULL",
                (inbox_owner_id,)
            )
        row = cursor.fetchone()
        return safe_int(row.get('cnt') if isinstance(row, dict) else 0, 0)
    except Exception as exc:
        print(f"Error counting staff promotion forms: {exc}")
        return 0
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def list_staff_promotion_years() -> List[int]:
    connection = None
    cursor = None
    years: List[int] = []
    try:
        connection = get_db_connection()
        if not connection:
            return years
        cursor = handle_cursor(connection)
        if not cursor:
            return years
        inbox_owner_id = get_staff_promotion_inbox_owner_id()
        if is_staff_promotion_test_super_admin(inbox_owner_id):
            cursor.execute(
                f"SELECT DISTINCT eval_year FROM {STAFF_PROMOTION_TABLE_NAME} ORDER BY eval_year DESC"
            )
        else:
            cursor.execute(
                f"SELECT DISTINCT eval_year FROM {STAFF_PROMOTION_TABLE_NAME} WHERE current_reviewer_employee_id=%s ORDER BY eval_year DESC",
                (inbox_owner_id,)
            )
        for row in cursor.fetchall() or []:
            if isinstance(row, dict):
                val = safe_int(row.get('eval_year'), 0)
                if val > 0:
                    years.append(val)
        return years
    except Exception as exc:
        print(f"Error listing staff promotion years: {exc}")
        return years
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def list_staff_promotion_forms(eval_year: Optional[int] = None, sort_by: str = 'newest') -> List[Dict[str, Any]]:
    connection = None
    cursor = None
    forms: List[Dict[str, Any]] = []
    try:
        connection = get_db_connection()
        if not connection:
            return forms
        cursor = handle_cursor(connection)
        if not cursor:
            return forms
        inbox_owner_id = get_staff_promotion_inbox_owner_id()
        params: List[Any] = []
        query = f"""
            SELECT *
            FROM {STAFF_PROMOTION_TABLE_NAME}
            WHERE 1=1
        """
        if not is_staff_promotion_test_super_admin(inbox_owner_id):
            query += " AND current_reviewer_employee_id=%s"
            params.append(inbox_owner_id)
        if eval_year is not None:
            query += " AND eval_year=%s"
            params.append(safe_int(eval_year, get_eval_year()))
        normalized_sort = str(sort_by or 'newest').strip().lower()
        if normalized_sort == 'division':
            query += " ORDER BY JSON_UNQUOTE(JSON_EXTRACT(profile_snapshot_json, '$.division')) ASC, JSON_UNQUOTE(JSON_EXTRACT(profile_snapshot_json, '$.department')) ASC, JSON_UNQUOTE(JSON_EXTRACT(profile_snapshot_json, '$.full_name')) ASC, id DESC"
        elif normalized_sort == 'job_level_asc':
            query += " ORDER BY CAST(COALESCE(NULLIF(proposed_job_level, ''), JSON_UNQUOTE(JSON_EXTRACT(profile_snapshot_json, '$.job_level')), '0') AS UNSIGNED) ASC, JSON_UNQUOTE(JSON_EXTRACT(profile_snapshot_json, '$.full_name')) ASC, id DESC"
        elif normalized_sort == 'job_level_desc':
            query += " ORDER BY CAST(COALESCE(NULLIF(proposed_job_level, ''), JSON_UNQUOTE(JSON_EXTRACT(profile_snapshot_json, '$.job_level')), '0') AS UNSIGNED) DESC, JSON_UNQUOTE(JSON_EXTRACT(profile_snapshot_json, '$.full_name')) ASC, id DESC"
        else:
            query += " ORDER BY created_at DESC, id DESC"
        cursor.execute(query, params)
        for row in cursor.fetchall() or []:
            if not isinstance(row, dict):
                continue
            profile_snapshot = {}
            score_history = []
            try:
                profile_snapshot = json.loads(row.get('profile_snapshot_json') or '{}')
            except Exception:
                profile_snapshot = {}
            try:
                score_history = json.loads(row.get('score_history_json') or '[]')
            except Exception:
                score_history = []
            created_at = row.get('created_at')
            created_display = created_at.strftime('%d %b %Y %H:%M') if isinstance(created_at, (datetime.datetime, datetime.date)) else str(created_at or '-')
            forms.append({
                'id': safe_int(row.get('id'), 0),
                'target_employee_id': row.get('target_employee_id'),
                'proposer_employee_id': row.get('proposer_employee_id'),
                'director_employee_id': row.get('director_employee_id'),
                'current_reviewer_employee_id': row.get('current_reviewer_employee_id'),
                'eval_year': safe_int(row.get('eval_year'), get_eval_year()),
                'status': row.get('status') or 'submitted_to_hr',
                'viewed_at': row.get('viewed_at'),
                'is_viewed': row.get('viewed_at') is not None,
                'created_at': created_at,
                'created_at_display': created_display,
                'proposer_name': get_employee_display_name(row.get('proposer_employee_id')),
                'profile_snapshot': profile_snapshot,
                'score_history': score_history,
                'manual_score_entries': normalize_staff_promotion_manual_score_entries(profile_snapshot.get('manual_score_entries')),
                'current_job_description': row.get('current_job_description') or '',
                'proposed_job_level': row.get('proposed_job_level') or '',
                'new_job_title': row.get('new_job_title') or '',
                'new_job_description': row.get('new_job_description') or '',
                'new_job_assignment': row.get('new_job_assignment') or '',
                'reasons_for_adjustment': row.get('reasons_for_adjustment') or '',
            })
        return forms
    except Exception as exc:
        print(f"Error listing staff promotion forms: {exc}")
        return forms
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def get_staff_promotion_form(form_id: Any, eval_year: Optional[int] = None) -> Optional[Dict[str, Any]]:
    target_id = safe_int(form_id, 0)
    if target_id <= 0:
        return None
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return None
        cursor = handle_cursor(connection)
        if not cursor:
            return None
        params: List[Any] = [target_id]
        query = f"SELECT * FROM {STAFF_PROMOTION_TABLE_NAME} WHERE id=%s"
        if eval_year is not None:
            query += " AND eval_year=%s"
            params.append(safe_int(eval_year, get_eval_year()))
        query += " LIMIT 1"
        cursor.execute(query, params)
        row = cursor.fetchone()
        if not row or not isinstance(row, dict):
            return None
        profile_snapshot = {}
        score_history = []
        try:
            profile_snapshot = json.loads(row.get('profile_snapshot_json') or '{}')
        except Exception:
            profile_snapshot = {}
        try:
            score_history = json.loads(row.get('score_history_json') or '[]')
        except Exception:
            score_history = []
        created_at = row.get('created_at')
        created_display = created_at.strftime('%d %b %Y %H:%M') if isinstance(created_at, (datetime.datetime, datetime.date)) else str(created_at or '-')
        return {
            'id': safe_int(row.get('id'), 0),
            'target_employee_id': row.get('target_employee_id'),
            'proposer_employee_id': row.get('proposer_employee_id'),
            'director_employee_id': row.get('director_employee_id'),
            'current_reviewer_employee_id': row.get('current_reviewer_employee_id'),
            'hr_director_employee_id': row.get('hr_director_employee_id'),
            'eval_year': safe_int(row.get('eval_year'), get_eval_year()),
            'status': row.get('status') or '',
            'viewed_at': row.get('viewed_at'),
            'is_viewed': row.get('viewed_at') is not None,
            'created_at': created_at,
            'created_at_display': created_display,
            'proposer_name': get_employee_display_name(row.get('proposer_employee_id')),
            'profile_snapshot': profile_snapshot,
            'score_history': score_history,
            'manual_score_entries': normalize_staff_promotion_manual_score_entries(profile_snapshot.get('manual_score_entries')),
            'current_job_description': row.get('current_job_description') or '',
            'proposed_job_level': row.get('proposed_job_level') or '',
            'new_job_title': row.get('new_job_title') or '',
            'new_job_description': row.get('new_job_description') or '',
            'new_job_assignment': row.get('new_job_assignment') or '',
            'reasons_for_adjustment': row.get('reasons_for_adjustment') or '',
        }
    except Exception as exc:
        print(f"Error loading staff promotion form: {exc}")
        return None
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def mark_staff_promotion_form_viewed(form_id: Any) -> bool:
    target_id = safe_int(form_id, 0)
    if target_id <= 0:
        return False
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return False
        cursor = handle_cursor(connection)
        if not cursor:
            return False
        cursor.execute(
            f"UPDATE {STAFF_PROMOTION_TABLE_NAME} SET viewed_at=CURRENT_TIMESTAMP WHERE id=%s AND status IN ('submitted_to_director', 'submitted_to_hr') AND viewed_at IS NULL",
            (target_id,)
        )
        connection.commit()
        return True
    except Exception as exc:
        print(f"Error marking staff promotion form viewed: {exc}")
        return False
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def finalize_staff_promotion_form(form_id: Any, final_status: str) -> bool:
    target_id = safe_int(form_id, 0)
    desired_status = str(final_status or '').strip().lower()
    if target_id <= 0 or desired_status not in {'approved', 'rejected'}:
        return False
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return False
        cursor = handle_cursor(connection)
        if not cursor:
            return False
        cursor.execute(
            f"""
            UPDATE {STAFF_PROMOTION_TABLE_NAME}
            SET status=%s,
                current_reviewer_employee_id=%s,
                viewed_at=CURRENT_TIMESTAMP,
                updated_at=CURRENT_TIMESTAMP
            WHERE id=%s AND status='submitted_to_hr'
            """,
            (desired_status, HR_DIRECTOR_EMPLOYEE_ID, target_id)
        )
        connection.commit()
        return cursor.rowcount > 0
    except Exception as exc:
        print(f"Error finalizing staff promotion form: {exc}")
        return False
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def get_staff_promotion_draft(target_employee_id: Any, proposer_employee_id: Any, eval_year: int) -> Optional[Dict[str, Any]]:
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return None
        cursor = handle_cursor(connection)
        if not cursor:
            return None
        cursor.execute(f"""
            SELECT *
            FROM {STAFF_PROMOTION_TABLE_NAME}
            WHERE target_employee_id=%s AND proposer_employee_id=%s AND eval_year=%s AND status='draft_manager'
            ORDER BY updated_at DESC, id DESC
            LIMIT 1
        """, (
            str(target_employee_id or '').strip(),
            str(proposer_employee_id or '').strip(),
            safe_int(eval_year, get_eval_year()),
        ))
        row = cursor.fetchone()
        if not row or not isinstance(row, dict):
            return None
        return {
            'current_job_description': row.get('current_job_description') or '',
            'proposed_job_level': row.get('proposed_job_level') or '',
            'new_job_title': row.get('new_job_title') or '',
            'new_job_description': row.get('new_job_description') or '',
            'new_job_assignment': row.get('new_job_assignment') or '',
            'reasons_for_adjustment': row.get('reasons_for_adjustment') or '',
        }
    except Exception as exc:
        print(f"Error loading staff promotion draft: {exc}")
        return None
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def get_dashboard_staff_promotion_status_map(employee_ids: List[Any], eval_year: int, proposer_employee_id: Any = None) -> Dict[str, Dict[str, str]]:
    normalized_ids = [str(emp_id or '').strip() for emp_id in (employee_ids or []) if str(emp_id or '').strip()]
    if not normalized_ids:
        return {}
    connection = None
    cursor = None
    status_map: Dict[str, Dict[str, str]] = {}
    try:
        connection = get_db_connection()
        if not connection:
            return status_map
        cursor = handle_cursor(connection)
        if not cursor:
            return status_map
        placeholders = ", ".join(["%s"] * len(normalized_ids))
        params: List[Any] = [safe_int(eval_year, get_eval_year()), *normalized_ids]
        query = f"""
            SELECT *
            FROM {STAFF_PROMOTION_TABLE_NAME}
            WHERE eval_year=%s
              AND target_employee_id IN ({placeholders})
        """
        proposer_id = str(proposer_employee_id or '').strip()
        if proposer_id:
            query += " AND proposer_employee_id=%s"
            params.append(proposer_id)
        query += " ORDER BY updated_at DESC, id DESC"
        cursor.execute(query, params)
        for row in cursor.fetchall() or []:
            if not isinstance(row, dict):
                continue
            target_id = str(row.get('target_employee_id') or '').strip()
            if not target_id or target_id in status_map:
                continue
            raw_status = str(row.get('status') or '').strip().lower()
            if raw_status in {'submitted_to_director', 'draft_director', 'submitted_to_hr'}:
                status_map[target_id] = {
                    'label': 'Proposed',
                    'bg': 'linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%)',
                    'color': '#1d4ed8',
                    'border': '#93c5fd',
                }
            elif raw_status == 'approved':
                status_map[target_id] = {
                    'label': 'Approved',
                    'bg': 'linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%)',
                    'color': '#166534',
                    'border': '#86efac',
                }
            elif raw_status == 'rejected':
                status_map[target_id] = {
                    'label': 'Rejected',
                    'bg': 'linear-gradient(135deg, #fee2e2 0%, #fecaca 100%)',
                    'color': '#991b1b',
                    'border': '#fca5a5',
                }
            else:
                status_map[target_id] = {
                    'label': '-',
                    'bg': '#f8fafc',
                    'color': '#64748b',
                    'border': '#cbd5e1',
                }
        return status_map
    except Exception as exc:
        print(f"Error loading dashboard staff promotion status map: {exc}")
        return status_map
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def load_form_data_from_db(employee_id: Optional[str], form_id: Optional[str], eval_year: Optional[int] = None) -> Optional[Dict[str, Any]]:
    """Load form data keyed by employee/form/eval_year, with fallback to legacy table."""
    if employee_id is not None and not isinstance(employee_id, str):
        employee_id = str(employee_id)
    if form_id is not None and not isinstance(form_id, str):
        form_id = str(form_id)
    eval_year_value = get_eval_year() if eval_year is None else eval_year
    def _load_from_versions():
        # Load from yearly versions table
        connection = None
        cursor = None
        try:
            connection = get_db_connection()
            if not connection:
                return None
            cursor = handle_cursor(connection)
            if not cursor:
                return None
            query = f"SELECT data_json FROM {VERSIONS_TABLE_NAME} WHERE employee_id = %s AND form_id = %s AND eval_year = %s"
            cursor.execute(query, (employee_id, form_id, eval_year_value))
            result = cursor.fetchone() if cursor else None
            if result and isinstance(result, dict):
                result_dict = cast(Dict[str, Any], result)
                data_json = result_dict.get('data_json')
                if data_json:
                    return json.loads(data_json)
            return None
        except Exception as e:
            print(f"Error loading yearly form data: {e}")
            return None
        finally:
            if cursor:
                try:
                    cursor.close()
                except Exception:
                    pass
            if connection:
                try:
                    connection.close()
                except Exception:
                    pass

    if not employee_id or not isinstance(employee_id, str):
        print("Error: Invalid employee_id")
        return None
    if not form_id or not isinstance(form_id, str):
        print("Error: Invalid form_id")
        return None

    cache_key = (str(employee_id), str(form_id), safe_int(eval_year_value, get_eval_year()))
    form_cache = _get_request_cache('_form_data_cache')
    if cache_key in form_cache:
        return form_cache[cache_key]

    def _load_from_legacy():
        # Load from legacy table (no eval_year key)
        connection = None
        cursor = None
        try:
            connection = get_db_connection()
            if not connection:
                return None
            cursor = handle_cursor(connection)
            if not cursor:
                return None
            query = f"SELECT data_json FROM {TABLE_NAME} WHERE employee_id = %s AND form_id = %s"
            cursor.execute(query, (employee_id, form_id))
            result = cursor.fetchone() if cursor else None
            if result and isinstance(result, dict):
                result_dict = cast(Dict[str, Any], result)
                data_json = result_dict.get('data_json')
                if data_json:
                    return json.loads(data_json)
            return None
        except Exception as e:
            print(f"Error loading legacy form data: {e}")
            return None
        finally:
            if cursor:
                try:
                    cursor.close()
                except Exception:
                    pass
            if connection:
                try:
                    connection.close()
                except Exception:
                    pass

    # Try the per-year store first, then legacy
    data = _load_from_versions()
    if data is not None:
        form_cache[cache_key] = data
        return data
    legacy_data = _load_from_legacy()
    form_cache[cache_key] = legacy_data
    return legacy_data


def save_form_data_to_db(employee_id: Optional[str], form_id: Optional[str], data: Optional[Dict[str, Any]]) -> bool:
    """Save form data to the database with enhanced type safety and error handling.
    
    Args:
        employee_id: The employee's ID
        form_id: The form identifier 
        data: The form data to save

    Returns:
        bool: True if save was successful, False otherwise
    """
    # Type/value validation
    if not employee_id or not isinstance(employee_id, str):
        print("Error: Invalid employee_id")
        return False
        
    if not form_id or not isinstance(form_id, str):
        print("Error: Invalid form_id") 
        return False
        
    if not isinstance(data, dict):
        print("Error: Invalid data format")
        return False
        
    # DB operations with proper error handling    
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            print("Error: Could not establish database connection")
            return False
            
        cursor = handle_cursor(connection)
        if not cursor:
            print("Error: Could not create cursor")
            return False
            
        # Serialize data with error checking
        try:
            json_data = json.dumps(data, ensure_ascii=False)
        except (TypeError, ValueError) as e:
            print(f"Error serializing data: {e}")
            return False
            
        query = f"""
            INSERT INTO {TABLE_NAME} (employee_id, form_id, data_json)
            VALUES (%s, %s, %s)
            ON DUPLICATE KEY UPDATE 
                data_json = VALUES(data_json),
                updated_at = CURRENT_TIMESTAMP
        """
        
        cursor.execute(query, (employee_id, form_id, json_data))
        connection.commit()
        
        return True
        
    except Error as e:
        print(f"Database error: {e}")
        return False
    except Exception as e:
        print(f"Unexpected error: {e}")
        return False
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def save_form_data_to_db_yearly(employee_id: Optional[str], form_id: Optional[str], eval_year: int, data: Optional[Dict[str, Any]]) -> bool:
    """Save form data keyed by eval_year into the versions table (with legacy upsert fallback)."""
    if not employee_id or not isinstance(employee_id, str):
        return False
    if not form_id or not isinstance(form_id, str):
        return False
    if not isinstance(data, dict):
        return False
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return False
        cursor = handle_cursor(connection)
        if not cursor:
            return False
        json_data = json.dumps(data, ensure_ascii=False)
        versions_saved = False
        try:
            cursor.execute(f"""
                INSERT INTO {VERSIONS_TABLE_NAME} (employee_id, form_id, eval_year, data_json)
                VALUES (%s, %s, %s, %s)
                ON DUPLICATE KEY UPDATE data_json = VALUES(data_json), updated_at = CURRENT_TIMESTAMP
            """, (employee_id, form_id, eval_year, json_data))
            connection.commit()
            versions_saved = True
        except Exception as e:
            print(f"Error saving yearly form data: {e}")
        # Also write to legacy table for backward compatibility
        legacy_saved = save_form_data_to_db(employee_id, form_id, data)
        return versions_saved or legacy_saved
    except Exception as e:
        print(f"Error saving yearly form data: {e}")
        return False
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def save_summary_history(employee_id: str, eval_year: int, summary_data: Dict[str, Any]) -> bool:
    """Persist a summary snapshot for a given employee/year."""
    if not employee_id or not isinstance(employee_id, str):
        return False
    if not isinstance(eval_year, int):
        return False
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return False
        cursor = handle_cursor(connection)
        if not cursor:
            return False
        json_data = json.dumps(summary_data, ensure_ascii=False)
        cursor.execute(f"""
            INSERT INTO {SUMMARY_TABLE_NAME} (employee_id, eval_year, summary_json)
            VALUES (%s, %s, %s)
            ON DUPLICATE KEY UPDATE summary_json = VALUES(summary_json), updated_at = CURRENT_TIMESTAMP
        """, (employee_id, eval_year, json_data))
        connection.commit()
        return True
    except Exception as e:
        print(f"Error saving summary history: {e}")
        return False
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def load_summary_history(employee_id: str, eval_year: int) -> Optional[Dict[str, Any]]:
    """Load a saved summary snapshot for a given year."""
    if not employee_id or not isinstance(eval_year, int):
        return None
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return None
        cursor = handle_cursor(connection)
        if not cursor:
            return None
        cursor.execute(f"SELECT summary_json FROM {SUMMARY_TABLE_NAME} WHERE employee_id=%s AND eval_year=%s",
                       (employee_id, eval_year))
        row = cursor.fetchone()
        if row and isinstance(row, dict):
            # Safe dictionary access with type checking
            summary_json = row.get('summary_json')
            if summary_json and isinstance(summary_json, str):
                return json.loads(summary_json)
    except Exception as e:
        print(f"Error loading summary history: {e}")
        return None
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def can_review_subordinate(reviewer_employee_id: Any, target_employee_id: Any) -> bool:
    """Authorize whether a supervisor/director can review a target employee."""
    reviewer_id = str(reviewer_employee_id or "").strip()
    target_id = str(target_employee_id or "").strip()
    if not reviewer_id or not target_id or reviewer_id == target_id:
        return False

    if is_admin_employee(reviewer_id):
        return True

    reporting_employee_ids = get_reporting_employee_ids(reviewer_id)
    if reporting_employee_ids:
        return target_id in {str(eid).strip() for eid in reporting_employee_ids}

    division_filter = SPECIAL_EXPORT_ACCESS.get(reviewer_id)
    if division_filter is None:
        return False

    target_profile = get_employee_profile(target_id)
    target_division = target_profile.get('division')
    if isinstance(division_filter, list):
        return target_division in division_filter
    return target_division == division_filter


def load_supervisor_review_from_db(target_employee_id: Any, form_id: Any, eval_year: Optional[int] = None) -> Optional[Dict[str, Any]]:
    """Load supervisor review data for a target employee/form/year."""
    target_id = str(target_employee_id or "").strip()
    form_name = str(form_id or "").strip()
    year = get_eval_year() if eval_year is None else safe_int(eval_year, get_eval_year())
    if not target_id or not form_name:
        return None

    cache_key = (target_id, form_name, year)
    review_cache = _get_request_cache('_supervisor_review_cache')
    if cache_key in review_cache:
        return review_cache[cache_key]

    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return None
        cursor = handle_cursor(connection)
        if not cursor:
            return None
        cursor.execute(
            f"SELECT reviewer_employee_id, data_json FROM {SUPERVISOR_REVIEW_TABLE_NAME} "
            "WHERE target_employee_id=%s AND form_id=%s AND eval_year=%s",
            (target_id, form_name, year)
        )
        row = cursor.fetchone()
        if row and isinstance(row, dict):
            data_json = row.get('data_json')
            if data_json:
                payload = json.loads(data_json)
                if isinstance(payload, dict):
                    payload['_reviewer_employee_id'] = str(row.get('reviewer_employee_id', '') or '').strip()
                    review_cache[cache_key] = payload
                    return payload
        review_cache[cache_key] = None
        return None
    except Exception as e:
        print(f"Error loading supervisor review data: {e}")
        return None
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def save_supervisor_review_to_db(target_employee_id: Any, reviewer_employee_id: Any, form_id: Any, eval_year: int,
                                 data: Optional[Dict[str, Any]]) -> bool:
    """Save supervisor review data without overwriting employee-entered form data."""
    target_id = str(target_employee_id or "").strip()
    reviewer_id = str(reviewer_employee_id or "").strip()
    form_name = str(form_id or "").strip()
    if not target_id or not reviewer_id or not form_name or not isinstance(data, dict):
        return False

    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return False
        cursor = handle_cursor(connection)
        if not cursor:
            return False
        json_data = json.dumps(data, ensure_ascii=False)
        cursor.execute(f"""
            INSERT INTO {SUPERVISOR_REVIEW_TABLE_NAME}
                (target_employee_id, reviewer_employee_id, form_id, eval_year, data_json)
            VALUES (%s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                reviewer_employee_id = VALUES(reviewer_employee_id),
                data_json = VALUES(data_json),
                updated_at = CURRENT_TIMESTAMP
        """, (target_id, reviewer_id, form_name, eval_year, json_data))
        connection.commit()
        review_cache = _get_request_cache('_supervisor_review_cache')
        cache_payload = dict(data)
        cache_payload['_reviewer_employee_id'] = reviewer_id
        review_cache[(target_id, form_name, safe_int(eval_year, get_eval_year()))] = cache_payload
        return True
    except Exception as e:
        print(f"Error saving supervisor review data: {e}")
        return False
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass


def summarize_review_scores(review_data: Optional[Dict[str, Any]]) -> Tuple[Dict[str, str], str]:
    """Return formatted score map and formatted average from supervisor review data."""
    formatted_scores: Dict[str, str] = {}
    numeric_scores: List[float] = []
    scores = review_data.get('scores', {}) if isinstance(review_data, dict) else {}
    if isinstance(scores, dict):
        for key, raw_value in scores.items():
            raw_text = str(raw_value or '').strip()
            if not raw_text:
                continue
            score_value = safe_float(raw_text, 0.0)
            if 0 <= score_value <= 5:
                formatted_scores[str(key)] = f"{score_value:.2f}"
                numeric_scores.append(score_value)
    average = f"{(sum(numeric_scores) / len(numeric_scores)):.2f}" if numeric_scores else "-"
    return formatted_scores, average


def format_behavior_scores(scores_data: Optional[Dict[str, Any]]) -> Dict[str, str]:
    """Format behavior score dict values to 2 decimals for display."""
    formatted: Dict[str, str] = {}
    scores = scores_data.get('scores', {}) if isinstance(scores_data, dict) else {}
    if not isinstance(scores, dict):
        return formatted
    for key, raw_value in scores.items():
        raw_text = str(raw_value or '').strip()
        if not raw_text:
            continue
        value = safe_float(raw_text, 0.0)
        if 0 <= value <= 5:
            formatted[str(key)] = f"{value:.2f}"
    return formatted


def is_supervisor_review_finalized(target_employee_id: Any, eval_year: Optional[int] = None) -> bool:
    """Return whether supervisor review has been finalized for the employee/year."""
    status_data = load_supervisor_review_from_db(target_employee_id, 'supervisor_review_status', eval_year) or {}
    return bool(status_data.get('is_finalized'))


def get_supervisor_review_status(target_employee_id: Any, eval_year: Optional[int] = None) -> Dict[str, Any]:
    """Load supervisor review finalization metadata."""
    status_data = load_supervisor_review_from_db(target_employee_id, 'supervisor_review_status', eval_year) or {}
    if not isinstance(status_data, dict):
        return {}
    last_reviewer_id = str(status_data.get('last_reviewed_by', '') or '').strip()
    finalized_by_id = str(status_data.get('finalized_by', '') or '').strip()
    status_data['last_reviewed_by_name'] = get_employee_display_name(last_reviewer_id) if last_reviewer_id else '-'
    status_data['last_reviewed_at_text'] = format_review_timestamp(status_data.get('last_reviewed_at'))
    status_data['finalized_by_name'] = get_employee_display_name(finalized_by_id) if finalized_by_id else '-'
    status_data['finalized_at_text'] = format_review_timestamp(status_data.get('finalized_at'))
    return status_data


def is_director_level_reviewer(employee_id: Any) -> bool:
    """Return whether the reviewer is allowed to finalize division-level reviews."""
    return str(employee_id or '').strip() in SPECIAL_EXPORT_ACCESS


def is_employee_self_edit_locked(employee_id: Any, eval_year: int) -> bool:
    """Lock self-editing only after review or finalization."""
    status_data = get_supervisor_review_status(employee_id, eval_year)
    return bool(status_data.get('is_reviewed')) or bool(status_data.get('is_finalized'))


def merge_kpi_review_data(employee_data: Optional[Dict[str, Any]], review_data: Optional[Dict[str, Any]],
                          num_rows: int) -> Dict[str, Any]:
    """Overlay supervisor KPI scores/results onto employee KPI structure for official calculation."""
    base = dict(employee_data or {})
    if not isinstance(base.get('scores'), list):
        base['scores'] = [''] * num_rows
    if not isinstance(base.get('results'), list):
        base['results'] = [''] * num_rows
    review_scores = review_data.get('scores', []) if isinstance(review_data, dict) and isinstance(review_data.get('scores'), list) else []
    review_results = review_data.get('results', []) if isinstance(review_data, dict) and isinstance(review_data.get('results'), list) else []

    merged_scores = list(base.get('scores', []))
    merged_results = list(base.get('results', []))
    if len(merged_scores) < num_rows:
        merged_scores.extend([''] * (num_rows - len(merged_scores)))
    if len(merged_results) < num_rows:
        merged_results.extend([''] * (num_rows - len(merged_results)))

    for i in range(num_rows):
        if i < len(review_scores) and str(review_scores[i] or '').strip():
            merged_scores[i] = review_scores[i]
        if i < len(review_results) and str(review_results[i] or '').strip():
            merged_results[i] = review_results[i]

    base['scores'] = merged_scores
    base['results'] = merged_results
    total_score = sum(safe_float(x, 0.0) for x in merged_results if str(x or '').strip())
    base['total_score'] = f"{total_score:.2f}"
    return base


def merge_behavior_review_data(employee_data: Optional[Dict[str, Any]], review_data: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Overlay supervisor behavior scores onto employee behavior structure for official calculation."""
    base_scores = {}
    if isinstance(employee_data, dict) and isinstance(employee_data.get('scores'), dict):
        base_scores.update({str(k): v for k, v in employee_data.get('scores', {}).items()})
    if isinstance(review_data, dict) and isinstance(review_data.get('scores'), dict):
        for key, value in review_data.get('scores', {}).items():
            if str(value or '').strip():
                base_scores[str(key)] = value
    return {'scores': base_scores}


def build_supervisor_kpi_review_sections(target_employee_id: str, job_level: int, eval_year: int) -> Tuple[Optional[Dict[str, Any]], List[Dict[str, Any]]]:
    """Build read-only employee KPI rows plus supervisor score inputs for populated KPI items only."""
    group_section: Optional[Dict[str, Any]] = None
    sections: List[Dict[str, Any]] = []
    target_profile = get_employee_profile(target_employee_id) or {}
    target_division = str(target_profile.get('division', '') or '').strip()

    if job_level >= 8:
        group_data = load_form_data_from_db(GLOBAL_GROUP_KPI_EMPLOYEE_ID[0], 'group_kpi', eval_year) or {}
        group_weight = get_weight_limit('group_kpi', job_level)
        employee_score = safe_float(group_data.get('group_score'), 0.0)
        group_result = (employee_score * group_weight) / 100 if employee_score > 0 and group_weight > 0 else 0.0
        group_section = {
            'id': 'group_kpi',
            'title': 'Group Shared KPI',
            'description': str(group_data.get('group_desc') or 'Group Shared KPI'),
            'weight': f"{group_weight:.0f}",
            'admin_score': f"{employee_score:.2f}" if employee_score > 0 else '-',
            'admin_result': f"{group_result:.2f}" if group_result > 0 else '-',
        }

    kpi_defs: List[Tuple[str, str, int]] = [
        ('bu_lob_kpi', 'BU/LoB Shared KPI', 5),
        ('org_capability', 'Organizational Capability Development', 10),
        ('people_dev', 'People Development', 10),
        ('bu_obj', 'Business Unit Objectives', 15),
    ]

    for form_id, title, num_rows in kpi_defs:
        if form_id == 'people_dev' and job_level < 8:
            continue
        if form_id == 'bu_lob_kpi' and job_level < 8:
            continue

        data = load_form_data_from_db(target_employee_id, form_id, eval_year) or {}
        if form_id == 'bu_lob_kpi' and is_fixed_bu_lob_user(job_level, target_division, target_profile.get('company')):
            data = apply_fixed_bu_lob_constraints(data, job_level, target_division, target_profile.get('company'))
        review_data = load_supervisor_review_from_db(target_employee_id, form_id, eval_year) or {}
        descriptions = data.get('descriptions', []) if isinstance(data.get('descriptions'), list) else []
        weights = data.get('weights', []) if isinstance(data.get('weights'), list) else []
        employee_scores = data.get('scores', []) if isinstance(data.get('scores'), list) else []
        employee_results = data.get('results', []) if isinstance(data.get('results'), list) else []
        supervisor_scores = review_data.get('scores', []) if isinstance(review_data.get('scores'), list) else []
        supervisor_results = review_data.get('results', []) if isinstance(review_data.get('results'), list) else []

        rows: List[Dict[str, Any]] = []
        for i in range(num_rows):
            description = descriptions[i] if i < len(descriptions) else ''
            if not str(description or '').strip():
                continue
            weight = safe_float(weights[i] if i < len(weights) else '', 0.0)
            employee_score = safe_float(employee_scores[i] if i < len(employee_scores) else '', 0.0)
            employee_result = safe_float(employee_results[i] if i < len(employee_results) else '', 0.0)
            supervisor_score = safe_float(supervisor_scores[i] if i < len(supervisor_scores) else '', 0.0)
            supervisor_result = safe_float(supervisor_results[i] if i < len(supervisor_results) else '', 0.0)
            rows.append({
                'index': i,
                'description': description,
                'weight': f"{weight:.2f}" if weight > 0 else '-',
                'employee_score': f"{employee_score:.2f}" if employee_score > 0 else '-',
                'employee_result': f"{employee_result:.2f}" if employee_result > 0 else '-',
                'supervisor_score': f"{supervisor_score:.2f}" if supervisor_score > 0 else '',
                'supervisor_result': f"{supervisor_result:.2f}" if supervisor_result > 0 else '-',
            })

        if rows:
            sections.append({
                'id': form_id,
                'title': title,
                'rows': rows,
                'allow_supervisor_input': True,
            })

    return group_section, sections
    return None


def is_supervisor_review_complete(target_employee_id: Any, job_level: int, eval_year: int) -> bool:
    """Return True only when all required supervisor review scores are filled."""
    employee_id = str(target_employee_id or '').strip()
    if not employee_id:
        return False
    target_profile = get_employee_profile(employee_id) or {}
    target_division = str(target_profile.get('division', '') or '').strip()

    kpi_defs: List[Tuple[str, int]] = [
        ('bu_lob_kpi', 5),
        ('org_capability', 10),
        ('people_dev', 10),
        ('bu_obj', 15),
    ]

    for form_id, num_rows in kpi_defs:
        if form_id in ['bu_lob_kpi', 'people_dev'] and job_level < 8:
            continue
        employee_data = load_form_data_from_db(employee_id, form_id, eval_year) or {}
        if form_id == 'bu_lob_kpi' and is_fixed_bu_lob_user(job_level, target_division, target_profile.get('company')):
            employee_data = apply_fixed_bu_lob_constraints(employee_data, job_level, target_division, target_profile.get('company'))
        review_data = load_supervisor_review_from_db(employee_id, form_id, eval_year) or {}
        descriptions = employee_data.get('descriptions', []) if isinstance(employee_data.get('descriptions'), list) else []
        review_scores = review_data.get('scores', []) if isinstance(review_data.get('scores'), list) else []
        for i in range(num_rows):
            description = descriptions[i] if i < len(descriptions) else ''
            if not str(description or '').strip():
                continue
            if not str(review_scores[i] if i < len(review_scores) else '').strip():
                return False

    if job_level <= 11:
        core_review_data = load_supervisor_review_from_db(employee_id, 'core_behaviors', eval_year) or {}
        core_scores = core_review_data.get('scores', {}) if isinstance(core_review_data.get('scores'), dict) else {}
        for key in get_core_behaviors_display_map(job_level).keys():
            if not str(core_scores.get(str(key), '') or '').strip():
                return False

    if job_level >= 8:
        leadership_review_data = load_supervisor_review_from_db(employee_id, 'leadership_behaviors', eval_year) or {}
        leadership_scores = leadership_review_data.get('scores', {}) if isinstance(leadership_review_data.get('scores'), dict) else {}
        for key in get_leadership_behaviors_display_map(job_level).keys():
            if not str(leadership_scores.get(str(key), '') or '').strip():
                return False

    return True


def has_supervisor_review_activity(target_employee_id: Any, job_level: int, eval_year: int) -> bool:
    """Return whether supervisor review has any saved score/comment activity."""
    employee_id = str(target_employee_id or '').strip()
    if not employee_id:
        return False

    kpi_defs: List[str] = ['bu_lob_kpi', 'org_capability', 'people_dev', 'bu_obj']
    for form_id in kpi_defs:
        if form_id in ['bu_lob_kpi', 'people_dev'] and job_level < 8:
            continue
        review_data = load_supervisor_review_from_db(employee_id, form_id, eval_year) or {}
        review_scores = review_data.get('scores', []) if isinstance(review_data.get('scores'), list) else []
        if any(str(score or '').strip() for score in review_scores):
            return True

    if job_level <= 11:
        core_review = load_supervisor_review_from_db(employee_id, 'core_behaviors', eval_year) or {}
        core_scores = core_review.get('scores', {}) if isinstance(core_review.get('scores'), dict) else {}
        if any(str(score or '').strip() for score in core_scores.values()):
            return True

    if job_level >= 8:
        leadership_review = load_supervisor_review_from_db(employee_id, 'leadership_behaviors', eval_year) or {}
        leadership_scores = leadership_review.get('scores', {}) if isinstance(leadership_review.get('scores'), dict) else {}
        if any(str(score or '').strip() for score in leadership_scores.values()):
            return True

    comment_data = load_supervisor_review_from_db(employee_id, 'behavior_review_comment', eval_year) or {}
    if str(comment_data.get('comment', '') or '').strip():
        return True

    return False


def get_workflow_status(target_employee_id: Any, job_level: int, eval_year: int) -> Dict[str, str]:
    """Return the current PE workflow status using explicit workflow checkpoints."""
    employee_id = str(target_employee_id or '').strip()
    cache_key = (employee_id, safe_int(job_level, 0), safe_int(eval_year, get_eval_year()))
    status_cache = _get_request_cache('_workflow_status_cache')
    if cache_key in status_cache:
        return status_cache[cache_key]

    status_data = get_supervisor_review_status(employee_id, eval_year)
    if bool(status_data.get('is_finalized')):
        status = {
            'code': 'finalized',
            'label': 'Finalized',
            'bg': 'linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%)',
            'color': '#1e3a8a',
            'border': '#93c5fd',
        }
    elif bool(status_data.get('is_reviewed')):
        status = {
            'code': 'reviewed',
            'label': 'Reviewed',
            'bg': 'linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)',
            'color': '#92400e',
            'border': '#f59e0b',
        }
    elif bool(status_data.get('is_submitted')):
        status = {
            'code': 'submitted',
            'label': 'Submitted',
            'bg': 'linear-gradient(135deg, #ede9fe 0%, #ddd6fe 100%)',
            'color': '#5b21b6',
            'border': '#a78bfa',
        }
    elif is_supervisor_review_complete(employee_id, job_level, eval_year) or has_supervisor_review_activity(employee_id, job_level, eval_year):
        status = {
            'code': 'reviewed',
            'label': 'Reviewed',
            'bg': 'linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)',
            'color': '#92400e',
            'border': '#f59e0b',
        }
    else:
        status = {
            'code': 'draft',
            'label': 'Draft',
            'bg': 'linear-gradient(135deg, #e2e8f0 0%, #cbd5e1 100%)',
            'color': '#334155',
            'border': '#94a3b8',
        }

    status_cache[cache_key] = status
    return status


def get_dashboard_status_label(status_code: Any) -> str:
    code = str(status_code or '').strip().lower()
    label_map = {
        'draft': 'Draft',
        'submitted': 'Submitted',
        'reviewed': 'Reviewed',
        'finalized': 'Finalized',
    }
    return label_map.get(code, 'Draft')


PERFORMANCE_SCORE_BANDS: List[Tuple[str, float, float]] = [
    ('Below 2.50', 0.0, 2.5),
    ('2.50 - 2.99', 2.5, 3.0),
    ('3.00 - 3.24', 3.0, 3.25),
    ('3.25 - 3.49', 3.25, 3.5),
    ('3.50 - 3.74', 3.5, 3.75),
    ('3.75 - 3.99', 3.75, 4.0),
    ('4.00 and above', 4.0, 5.01),
]


def classify_performance_score_band(score: Any) -> str:
    numeric = safe_float(score, -1.0)
    if numeric < 0:
        return 'Unscored'
    for label, low, high in PERFORMANCE_SCORE_BANDS:
        if low <= numeric < high:
            return label
    return 'Unscored'


def build_performance_distribution_rows(subordinates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    counts: Dict[str, int] = {label: 0 for label, _, _ in PERFORMANCE_SCORE_BANDS}
    for row in subordinates:
        band = classify_performance_score_band(row.get('final_total_score'))
        if band in counts:
            counts[band] += 1

    max_count = max(counts.values()) if counts else 0
    distribution_rows: List[Dict[str, Any]] = []
    for label, _, _ in PERFORMANCE_SCORE_BANDS:
        count = counts.get(label, 0)
        width_pct = (count / max_count * 100.0) if max_count > 0 else 0.0
        distribution_rows.append({
            'label': label,
            'count': count,
            'width_pct': width_pct,
        })
    return distribution_rows


def build_distribution_curve_data(distribution_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    width = 820
    height = 260
    left_pad = 46
    right_pad = 42
    top_pad = 20
    bottom_pad = 56
    inner_width = max(1, width - left_pad - right_pad)
    inner_height = max(1, height - top_pad - bottom_pad)

    max_count = max((safe_int(row.get('count'), 0) for row in distribution_rows), default=0)
    label_count = max(1, len(distribution_rows))
    step_x = inner_width / max(1, label_count - 1)

    points = []
    labels = []
    for idx, row in enumerate(distribution_rows):
        count = safe_int(row.get('count'), 0)
        x = left_pad + (idx * step_x)
        if max_count > 0:
            y = top_pad + (inner_height - ((count / max_count) * inner_height))
        else:
            y = top_pad + inner_height
        points.append({
            'x': round(x, 1),
            'y': round(y, 1),
            'count': count,
            'label': str(row.get('label') or ''),
        })
        labels.append({
            'x': round(x, 1),
            'label': str(row.get('label') or ''),
        })

    polyline_points = " ".join(f"{point['x']},{point['y']}" for point in points)
    area_points = []
    if points:
        baseline_y = top_pad + inner_height
        area_points.append(f"{points[0]['x']},{baseline_y}")
        area_points.extend(f"{point['x']},{point['y']}" for point in points)
        area_points.append(f"{points[-1]['x']},{baseline_y}")
    area_polygon_points = " ".join(area_points)

    y_ticks = []
    for idx in range(5):
        tick_value = round(max_count * (idx / 4.0)) if max_count > 0 else 0
        y = top_pad + inner_height - (inner_height * (idx / 4.0))
        y_ticks.append({
            'y': round(y, 1),
            'value': int(tick_value),
        })

    return {
        'width': width,
        'height': height,
        'left_pad': left_pad,
        'right_pad': right_pad,
        'top_pad': top_pad,
        'bottom_pad': bottom_pad,
        'baseline_y': round(top_pad + inner_height, 1),
        'max_count': max_count,
        'points': points,
        'labels': labels,
        'y_ticks': y_ticks,
        'polyline_points': polyline_points,
        'area_polygon_points': area_polygon_points,
    }


def build_compare_distribution_cards(subordinates: List[Dict[str, Any]], compare_by: str, compare_units: List[str]) -> List[Dict[str, Any]]:
    cards: List[Dict[str, Any]] = []
    attribute = 'department' if compare_by == 'department' else 'division'
    for unit in compare_units[:4]:
        unit_name = str(unit or '').strip()
        if not unit_name:
            continue
        unit_rows = [
            sub for sub in subordinates
            if str(sub.get(attribute) or '').strip() == unit_name
        ]
        if not unit_rows:
            continue
        scores = [safe_float(sub.get('final_total_score'), None) for sub in unit_rows]
        scores = [score for score in scores if score is not None]
        cards.append({
            'label': unit_name,
            'headcount': len(unit_rows),
            'avg_score': (sum(scores) / len(scores)) if scores else 0.0,
            'max_score': max(scores) if scores else 0.0,
            'min_score': min(scores) if scores else 0.0,
            'curve_chart': build_distribution_curve_data(build_performance_distribution_rows(unit_rows)),
        })
    return cards


def build_super_admin_division_compare_cards(subordinates: List[Dict[str, Any]], company: str, divisions: List[str]) -> List[Dict[str, Any]]:
    cards: List[Dict[str, Any]] = []
    company_name = str(company or '').strip()
    for division in divisions[:4]:
        division_name = str(division or '').strip()
        if not division_name:
            continue
        unit_rows = [
            sub for sub in subordinates
            if str(sub.get('company') or '').strip() == company_name
            and str(sub.get('division') or '').strip() == division_name
        ]
        if not unit_rows:
            continue
        scores = [safe_float(sub.get('final_total_score'), None) for sub in unit_rows]
        scores = [score for score in scores if score is not None]
        cards.append({
            'label': division_name,
            'headcount': len(unit_rows),
            'avg_score': (sum(scores) / len(scores)) if scores else 0.0,
            'max_score': max(scores) if scores else 0.0,
            'min_score': min(scores) if scores else 0.0,
            'curve_chart': build_distribution_curve_data(build_performance_distribution_rows(unit_rows)),
        })
    return cards


def calculate_median_score(scores: List[float]) -> float:
    if not scores:
        return 0.0
    sorted_scores = sorted(scores)
    mid = len(sorted_scores) // 2
    if len(sorted_scores) % 2 == 1:
        return sorted_scores[mid]
    return (sorted_scores[mid - 1] + sorted_scores[mid]) / 2.0


def get_workflow_status_map(employee_rows: List[Dict[str, Any]], eval_year: int) -> Dict[str, Dict[str, str]]:
    """Bulk-load workflow statuses for dashboard rows to avoid per-employee DB lookups."""
    employee_ids = [str(row.get('employee_id') or '').strip() for row in employee_rows if str(row.get('employee_id') or '').strip()]
    if not employee_ids:
        return {}

    job_levels = {str(row.get('employee_id') or '').strip(): safe_int(row.get('job_level'), 0) for row in employee_rows}
    placeholders = ", ".join(["%s"] * len(employee_ids))
    status_map: Dict[str, Dict[str, str]] = {}
    review_payloads: Dict[str, Dict[str, Dict[str, Any]]] = {}
    form_payloads: Dict[str, Dict[str, Dict[str, Any]]] = {}
    connection = None
    cursor = None

    try:
        connection = get_db_connection()
        if not connection:
            return {}
        cursor = handle_cursor(connection)
        if not cursor:
            return {}

        cursor.execute(
            f"SELECT target_employee_id, form_id, data_json FROM {SUPERVISOR_REVIEW_TABLE_NAME} "
            f"WHERE eval_year = %s AND target_employee_id IN ({placeholders})",
            [safe_int(eval_year, get_eval_year()), *employee_ids]
        )
        for row in cursor.fetchall() or []:
            if not isinstance(row, dict):
                continue
            employee_id = str(row.get('target_employee_id') or '').strip()
            form_id = str(row.get('form_id') or '').strip()
            if not employee_id or not form_id:
                continue
            try:
                payload = json.loads(row.get('data_json') or '{}')
            except Exception:
                payload = {}
            if isinstance(payload, dict):
                review_payloads.setdefault(employee_id, {})[form_id] = payload

        kpi_form_ids = ['bu_lob_kpi', 'org_capability', 'people_dev', 'bu_obj']
        form_placeholders = ", ".join(["%s"] * len(kpi_form_ids))
        cursor.execute(
            f"SELECT employee_id, form_id, data_json FROM {VERSIONS_TABLE_NAME} "
            f"WHERE eval_year = %s AND employee_id IN ({placeholders}) AND form_id IN ({form_placeholders})",
            [safe_int(eval_year, get_eval_year()), *employee_ids, *kpi_form_ids]
        )
        for row in cursor.fetchall() or []:
            if not isinstance(row, dict):
                continue
            employee_id = str(row.get('employee_id') or '').strip()
            form_id = str(row.get('form_id') or '').strip()
            if not employee_id or not form_id:
                continue
            try:
                payload = json.loads(row.get('data_json') or '{}')
            except Exception:
                payload = {}
            if isinstance(payload, dict):
                form_payloads.setdefault(employee_id, {})[form_id] = payload
    except Exception as e:
        print(f"Error bulk loading workflow statuses: {e}")
        return {employee_id: get_workflow_status(employee_id, job_levels.get(employee_id, 0), eval_year) for employee_id in employee_ids}
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass

    kpi_defs: List[Tuple[str, int]] = [('bu_lob_kpi', 5), ('org_capability', 10), ('people_dev', 10), ('bu_obj', 15)]
    for employee_id in employee_ids:
        job_level = job_levels.get(employee_id, 0)
        reviews = review_payloads.get(employee_id, {})
        forms = form_payloads.get(employee_id, {})
        status_payload = reviews.get('supervisor_review_status') or {}

        if bool(status_payload.get('is_finalized')):
            status_map[employee_id] = {
                'code': 'finalized',
                'label': 'Finalized',
                'bg': 'linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%)',
                'color': '#1e3a8a',
                'border': '#93c5fd',
            }
            continue
        if bool(status_payload.get('is_reviewed')):
            status_map[employee_id] = {
                'code': 'reviewed',
                'label': 'Reviewed',
                'bg': 'linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)',
                'color': '#92400e',
                'border': '#f59e0b',
            }
            continue
        if bool(status_payload.get('is_submitted')):
            status_map[employee_id] = {
                'code': 'submitted',
                'label': 'Submitted',
                'bg': 'linear-gradient(135deg, #ede9fe 0%, #ddd6fe 100%)',
                'color': '#5b21b6',
                'border': '#a78bfa',
            }
            continue

        has_activity = False
        is_complete = True

        for form_id, num_rows in kpi_defs:
            if form_id in ['bu_lob_kpi', 'people_dev'] and job_level < 8:
                continue
            employee_data = forms.get(form_id, {})
            review_data = reviews.get(form_id, {})
            descriptions = employee_data.get('descriptions', []) if isinstance(employee_data.get('descriptions'), list) else []
            review_scores = review_data.get('scores', []) if isinstance(review_data.get('scores'), list) else []
            if any(str(score or '').strip() for score in review_scores):
                has_activity = True
            for i in range(num_rows):
                description = descriptions[i] if i < len(descriptions) else ''
                if not str(description or '').strip():
                    continue
                if not str(review_scores[i] if i < len(review_scores) else '').strip():
                    is_complete = False

        if job_level <= 11:
            core_scores = (reviews.get('core_behaviors') or {}).get('scores', {})
            if isinstance(core_scores, dict) and any(str(score or '').strip() for score in core_scores.values()):
                has_activity = True
            for key in get_core_behaviors_display_map(job_level).keys():
                if not str((core_scores or {}).get(str(key), '') or '').strip():
                    is_complete = False

        if job_level >= 8:
            leadership_scores = (reviews.get('leadership_behaviors') or {}).get('scores', {})
            if isinstance(leadership_scores, dict) and any(str(score or '').strip() for score in leadership_scores.values()):
                has_activity = True
            for key in get_leadership_behaviors_display_map(job_level).keys():
                if not str((leadership_scores or {}).get(str(key), '') or '').strip():
                    is_complete = False

        if str((reviews.get('behavior_review_comment') or {}).get('comment', '') or '').strip():
            has_activity = True

        if is_complete or has_activity:
            status_map[employee_id] = {
                'code': 'reviewed',
                'label': 'Reviewed',
                'bg': 'linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)',
                'color': '#92400e',
                'border': '#f59e0b',
            }
        else:
            status_map[employee_id] = {
                'code': 'draft',
                'label': 'Draft',
                'bg': 'linear-gradient(135deg, #e2e8f0 0%, #cbd5e1 100%)',
                'color': '#334155',
                'border': '#94a3b8',
            }

    return status_map


def list_summary_years(employee_id: str) -> List[int]:
    """Return available evaluation years for an employee."""
    years: List[int] = []
    if not employee_id:
        return years
    connection = None
    cursor = None
    try:
        connection = get_db_connection()
        if not connection:
            return years
        cursor = handle_cursor(connection)
        if not cursor:
            return years
        cursor.execute(f"SELECT eval_year FROM {SUMMARY_TABLE_NAME} WHERE employee_id=%s ORDER BY eval_year DESC",
                       (employee_id,))
        for row in cursor.fetchall() or []:
            val = row.get('eval_year') if isinstance(row, dict) else None
            if isinstance(val, int):
                years.append(val)
    except Exception as e:
        print(f"Error listing summary years: {e}")
    finally:
        if cursor:
            try:
                cursor.close()
            except Exception:
                pass
        if connection:
            try:
                connection.close()
            except Exception:
                pass
    return years


def get_current_fiscal_year(today: Optional[datetime.date] = None) -> int:
    """Return fiscal year where FY starts Oct 1 and ends Sep 30."""
    if today is None:
        today = datetime.date.today()
    return today.year + 1 if today.month >= 10 else today.year


def get_eval_year() -> int:
    """Get the selected eval year from session or default to current fiscal year (min 2026)."""
    fy = get_current_fiscal_year()
    session_year = safe_int(session.get('eval_year'), fy)
    # enforce launch year minimum (now allow FY2026)
    return max(session_year, 2026)


def resolve_eval_year_from_request() -> int:
    """Resolve eval year from query/form/session and store in session."""
    fy = get_current_fiscal_year()
    requested = request.form.get('eval_year') or request.args.get('year')
    year = safe_int(requested, safe_int(session.get('eval_year'), fy))
    year = max(year, 2026)
    session['eval_year'] = year
    return year


def get_eval_year_lock_date(eval_year: int) -> datetime.date:
    """Past evaluation years become locked on Jan 1 of the following year."""
    year = safe_int(eval_year, 0)
    if year <= 0:
        year = get_eval_year()
    return datetime.date(year + 1, 1, 1)


def is_eval_year_locked(eval_year: int, today: Optional[datetime.date] = None) -> bool:
    """Return whether the evaluation year is locked for normal editing."""
    if today is None:
        today = datetime.date.today()
    return today >= get_eval_year_lock_date(eval_year)


def can_edit_eval_year(employee_id: Any, eval_year: int) -> bool:
    """Allow admins to override the lock; normal users cannot edit locked years."""
    employee = str(employee_id or '').strip()
    if employee and is_admin_employee(employee):
        return True
    return not is_eval_year_locked(eval_year)


def get_staff_promotion_year(today: Optional[datetime.date] = None) -> int:
    """Promotion cycle follows PE fiscal year but stays open until Dec 31."""
    if today is None:
        today = datetime.date.today()
    if today.month >= 10:
        return today.year + 1
    return today.year


def get_staff_promotion_lock_date(eval_year: int) -> datetime.date:
    """Staff promotion remains editable through Dec 31 of the eval year."""
    year = safe_int(eval_year, 0)
    if year <= 0:
        year = get_staff_promotion_year()
    return datetime.date(year + 1, 1, 1)


def is_staff_promotion_year_locked(eval_year: int, today: Optional[datetime.date] = None) -> bool:
    if today is None:
        today = datetime.date.today()
    return today >= get_staff_promotion_lock_date(eval_year)


def resolve_staff_promotion_year_from_request() -> int:
    current_cycle = get_staff_promotion_year()
    requested = request.form.get('promotion_year') or request.args.get('year')
    year = safe_int(requested, current_cycle)
    return max(year, 2026)
    try:
        cursor: CursorType = connection.cursor()
        json_data = json.dumps(data, ensure_ascii=False)
        query = f"""
            INSERT INTO {TABLE_NAME} (employee_id, form_id, data_json)
            VALUES (%s, %s, %s)
            ON DUPLICATE KEY UPDATE 
                data_json = VALUES(data_json),
                updated_at = CURRENT_TIMESTAMP
        """
        cursor.execute(query, (employee_id, form_id, json_data))
        connection.commit()
        return True
    except Error as e:
        print(f"Error saving form data: {e}")
        return False
    finally:
        cursor.close()
        connection.close()


def get_employee_display_name(employee_id: Any) -> str:
    """Resolve a readable employee name for audit metadata display."""
    employee_key = str(employee_id or "").strip()
    if not employee_key:
        return "-"
    profile = get_employee_profile(employee_key)
    full_name = str(profile.get('full_name', '') or '').strip()
    return full_name if full_name and full_name != 'Unknown Employee' else employee_key


def format_review_timestamp(timestamp_value: Any) -> str:
    """Render stored review timestamps in a concise local display format."""
    raw = str(timestamp_value or "").strip()
    if not raw:
        return "-"
    try:
        dt = datetime.datetime.fromisoformat(raw)
        return dt.strftime('%d %b %Y %H:%M')
    except Exception:
        return raw


def get_disabled_buttons(job_level: Optional[int]) -> list[str]:
    """Determine which buttons are disabled based on job level with enhanced type safety"""
    # Convert job level to int with safe conversion
    level = safe_int(job_level, 0)

    # Define disabled features by level range 
    disabled_features: list[str] = []

    # Handle invalid/missing job level
    if level <= 0:
        # Block all advanced features for invalid levels
        return [
            'group_kpi_page',
            'bu_lob_kpi_page',
            'org_capability_page', 
            'people_dev_page',
            'leadership_behaviors_page'
        ]

    # Junior Level (1-3): Block most advanced features
    if level < 4:
        disabled_features.extend([
            'group_kpi_page',
            'bu_lob_kpi_page',
            'people_dev_page',
            'leadership_behaviors_page'
        ])

    # Early Career Level (4-7): Block leadership and group features
    elif 4 <= level <= 7:
        disabled_features.extend([
            'group_kpi_page',
            'bu_lob_kpi_page',
            'people_dev_page',
            'leadership_behaviors_page'
        ])

    # Mid Career Level (8-9): No disabled features
    elif 8 <= level <= 9:
        pass

    # Senior Level (12+): Block core behaviors
    elif level >= 12:
        disabled_features.append('core_behaviors_page')

    # Levels 10-11: No disabled features

    return disabled_features


def get_nav_html(current_page, job_level, full_name):
    """Generates the navigation bar HTML."""
    disabled_buttons = get_disabled_buttons(job_level)
    employee_id = session.get('employee_id')

    ALLOWED_EXPORTERS = ['10300069', '10300098', '10300040', '10300064', '10300003', '10300004', '10300006', '10300200',
                         '10300071', '10300002', '10300016', '10300476', '10300299', '10300221', '10305007']

    nav_html = '<aside class="sidebar">'

    # Sidebar Header
    nav_html += '<div class="sidebar-header">'
    nav_html += f'<img src="{url_for("static", filename="img/TCCtech Group Logo 2026.png")}" alt="TCC Technology Group" style="width: 160px; max-width: 100%; height: auto; display: block; margin: 0 auto 10px;">'
    nav_html += '<h1 class="sidebar-title">PERFORMANCE EVALUATION SYSTEM</h1>'
    nav_html += f'<div style="color:#fff;font-weight:900;margin-top:8px;letter-spacing:0.12em;text-transform:uppercase;text-align:center;">FY{get_eval_year()}</div>'
    nav_html += '<br />'
    nav_html += '<div class="sidebar-user-info">'
    nav_html += f'<strong style="font-size: 16px;">{full_name}</strong>'
    nav_html += f'<span style="font-size: 14px;">Job Level: {job_level}</span>'
    nav_html += '</div>'
    nav_html += '</div>'

    nav_html += '<nav class="sidebar-nav">'


    
    for item in NAVIGATION_ITEMS:
        item_id = item["id"]
        is_disabled = item["id"] in disabled_buttons
        is_active = current_page == item_id

        if not is_disabled:
            active_class = ' active' if is_active else ''
            nav_html += f'<a href="{url_for(item_id)}" class="nav-item{active_class}">'
            nav_html += f'<span class="nav-item-icon">{item["icon"]}</span>'
            nav_html += f'<span>{item["label"]}</span>'
            nav_html += '</a>'

    # Add Performance Evaluation Dashboard link for managers/directors (has subordinates)
    has_subordinates = bool(get_reporting_employee_ids(str(employee_id).strip()))
    if has_subordinates or str(employee_id).strip() in SPECIAL_EXPORT_ACCESS:
        is_active = current_page == 'performance_dashboard'
        active_class = ' active' if is_active else ''
        nav_html += f'<a href="{url_for("performance_dashboard")}" class="nav-item{active_class}" style="margin-top: 10px;">'
        nav_html += '<span class="nav-item-icon">📊</span>'
        nav_html += '<span>Performance Dashboard</span>'
        nav_html += '</a>'

    if can_access_staff_promotion_inbox(employee_id):
        promotion_count = count_incoming_staff_promotion_forms()
        is_active = current_page == 'staff_promotion_inbox'
        active_class = ' active' if is_active else ''
        nav_html += f'<a href="{url_for("staff_promotion_inbox")}" class="nav-item{active_class}">'
        nav_html += '<span class="nav-item-icon">📝</span>'
        nav_html += '<span>Promotion Nominations</span>'
        if promotion_count > 0:
            nav_html += f'<span style="margin-left:auto; min-width:22px; height:22px; padding:0 7px; border-radius:999px; display:inline-flex; align-items:center; justify-content:center; background:#ef4444; color:#fff; font-size:0.78em; font-weight:800;">{promotion_count}</span>'
        nav_html += '</a>'

    nav_html += '</nav>'

    # Theme toggle + Logout
    nav_html += '<div class="theme-toggle">'
    nav_html += '  <label class="theme-toggle-label"></label>'
    nav_html += '  <label class="theme-switch">'
    nav_html += '    <input type="checkbox" id="themeToggle">'
    nav_html += '    <div class="theme-switch-track">'
    nav_html += '      <div class="theme-switch-thumb">'
    nav_html += '        <span id="themeIcon">☀️</span>'
    nav_html += '      </div>'
    nav_html += '    </div>'
    nav_html += '    <span class="theme-switch-text" id="themeText">Light</span>'
    nav_html += '  </label>'
    nav_html += '</div>'

    nav_html += '<div class="sidebar-footer">'
    nav_html += f'<a href="{url_for("logout")}" class="logout-btn">Logout</a>'
    nav_html += '</div>'
    
    nav_html += '</aside>'
    return nav_html


def get_weight_limit(form_id: str, job_level: Optional[int]) -> int:
    """Determines the weight limit based on form_id and job_level with enhanced type safety.
    
    Args:
        form_id: The ID of the form (e.g. 'org_capability', 'people_dev', etc)
        job_level: The employee's job level (1-15)

    Returns:
        int: The weight limit percentage (0-100). Returns 0 for invalid combinations.
    """
    # Handle invalid/missing job level
    level = safe_int(job_level, 0)
    if level <= 0 or level > 15:
        return 0

    # Weight limit lookup table
    WEIGHT_LIMITS = {
        'org_capability': {
            (4, 7): 5,   # Early career
            (8, 9): 5,   # Mid career
            (10, 15): 10 # Senior levels
        },
        'people_dev': {
            (8, 9): 5,    # Mid career
            (10, 11): 10, # Early senior
            (12, 15): 10  # Senior
        },
        'bu_obj': {
            (4, 7): 95,   # Early career
            (8, 9): 70,   # Mid career
            (10, 11): 45, # Early senior
            (12, 15): 30  # Senior
        },
        'bu_lob_kpi': {
            (8, 9): 10,   # Mid career
            (10, 11): 20, # Early senior
            (12, 15): 30  # Senior
        },
        'group_kpi': {
            (8, 9): 10,   # Mid career
            (10, 11): 15, # Early senior
            (12, 15): 20  # Senior
        }
    }

    # Find matching level range for form type
    if form_id in WEIGHT_LIMITS:
        for (min_level, max_level), limit in WEIGHT_LIMITS[form_id].items():
            if min_level <= level <= max_level:
                return limit

    # Return 0 if no matching range found
    return 0


def _safe_float_or_none(value: Any) -> Optional[float]:
    try:
        text = str(value or '').strip()
        if not text:
            return None
        return float(text)
    except (TypeError, ValueError):
        return None


def validate_self_submission(employee_id: str, job_level: Optional[int], eval_year: int, division: Optional[str] = None, company: Optional[str] = None) -> List[str]:
    errors: List[str] = []
    level = safe_int(job_level, 0)
    is_fixed_bu = is_fixed_bu_lob_user(level, division, company)
    fixed_template = build_fixed_bu_lob_data(level, division, company) if is_fixed_bu else {}

    kpi_sections: List[Tuple[str, str, int]] = [
        ('bu_lob_kpi', 'BU/LoB Shared KPI', 2 if is_fixed_bu else 5),
        ('org_capability', 'Organizational Capability Development', 10),
        ('people_dev', 'People Development', 10),
        ('bu_obj', 'Business Unit Objectives', 15),
    ]

    for form_id, label, num_rows in kpi_sections:
        weight_limit = get_weight_limit(form_id, level)
        if weight_limit <= 0:
            continue

        payload = load_form_data_from_db(employee_id, form_id, eval_year) or {}
        if form_id == 'bu_lob_kpi' and is_fixed_bu_lob_user(level, division, company):
            payload = apply_fixed_bu_lob_constraints(payload, level, division, company)
        descriptions = payload.get('descriptions', []) if isinstance(payload.get('descriptions'), list) else []
        weights = payload.get('weights', []) if isinstance(payload.get('weights'), list) else []
        scores = payload.get('scores', []) if isinstance(payload.get('scores'), list) else []
        active_weight_total = 0.0
        active_rows = 0

        for idx in range(num_rows):
            if is_fixed_bu:
                weight_text = str((fixed_template.get('weights') or [''] * num_rows)[idx] or '').strip()
            else:
                weight_text = str(weights[idx] if idx < len(weights) else '').strip()

            row_active = bool(weight_text)
            if not row_active:
                continue

            active_rows += 1
            weight_value = _safe_float_or_none(weight_text)
            if weight_value is None:
                errors.append(f"{label}: one or more KPI rows have invalid weight.")
            elif weight_value > 0:
                active_weight_total += weight_value

        if active_rows == 0:
            errors.append(f"{label}: no KPI rows have been completed. Total weight must equal {weight_limit}%.")
        elif abs(active_weight_total - float(weight_limit)) > 0.01:
            errors.append(f"{label}: total used weight is {active_weight_total:.2f}%, but it must equal {weight_limit}%.")
        elif not str(payload.get('total_score', '') or '').strip():
            errors.append(f"{label}: result total is still missing.")

    core_behaviors_map = get_core_behaviors_display_map(level) if level <= 11 else {}
    if core_behaviors_map:
        core_payload = load_form_data_from_db(employee_id, 'core_behaviors', eval_year) or {}
        core_scores = core_payload.get('scores', {}) if isinstance(core_payload.get('scores'), dict) else {}
        for behavior_id, behavior in sorted(core_behaviors_map.items()):
            raw_value = str((core_scores or {}).get(str(behavior_id), '') or '').strip()
            if not raw_value or raw_value == '--':
                errors.append(f"Core Behaviors: '{behavior.get('title', f'Item {behavior_id}')}' is still not scored.")

    leadership_behaviors_map = get_leadership_behaviors_display_map(level) if level >= 8 else {}
    if leadership_behaviors_map:
        leadership_payload = load_form_data_from_db(employee_id, 'leadership_behaviors', eval_year) or {}
        leadership_scores = leadership_payload.get('scores', {}) if isinstance(leadership_payload.get('scores'), dict) else {}
        for behavior_id, behavior in sorted(leadership_behaviors_map.items()):
            raw_value = str((leadership_scores or {}).get(str(behavior_id), '') or '').strip()
            if not raw_value or raw_value == '--':
                errors.append(f"Leadership Behaviors: '{behavior.get('title', f'Item {behavior_id}')}' is still not scored.")

    return errors


def export_scores_to_csv(file_path, division_filter=None, employee_ids=None):
    """Export all performance scores to a CSV file with optional division filter."""
    connection = get_db_connection()
    if not connection:
        return False

    headers = [
        'Company', 'Full Name', 'Employee ID', 'Position', 'Division', 'Job Level',
        'Group KPI Score', 'BU/LoB KPI Total Score', 'Org Cap Total Score',
        'People Dev Total Score', 'BU Obj Total Score',
        'Core Behaviors Avg Score', 'Leadership Behaviors Avg Score', 'Performance KPI Score',
        'Core Behaviors Weighted Score', 'Leadership Behaviors Weighted Score',
        'Final Total Score'
    ]

    try:
        cursor = connection.cursor()
        params = []
        excluded_divisions = EXCLUDED_DIVISIONS_BY_EMPLOYEE.get(str(session.get('employee_id', '')).strip())

        query = """
                SELECT e.company,
                       e.full_name,
                       e.employee_id,
                       e.position,
                       e.division,
                       e.job_level,
                       p.group_kpi_score,
                       p.bu_lob_kpi_total_score,
                       p.org_cap_total_score,
                       p.people_dev_total_score,
                       p.bu_obj_total_score,
                       p.core_behaviors_avg_score,
                       p.leadership_behaviors_avg_score,
                       p.perf_kpi_score,
                       p.core_behaviors_total_score,
                       p.leadership_behaviors_total_score,
                       p.final_total_score
                FROM all_final_scores p
                         JOIN pe_staff e ON p.employee_id = e.employee_id
                """

        conditions = ["LOWER(TRIM(e.position)) != 'managing director'"]
        if excluded_divisions:
            placeholders = ", ".join(["%s"] * len(excluded_divisions))
            conditions.append(f"e.division NOT IN ({placeholders})")
            params.extend(excluded_divisions)
        if employee_ids:
            placeholders = ", ".join(["%s"] * len(employee_ids))
            conditions.append(f"CAST(e.employee_id AS CHAR) IN ({placeholders})")
            params.extend(employee_ids)
        elif division_filter is not None:
            if isinstance(division_filter, list):
                placeholders = ", ".join(["%s"] * len(division_filter))
                conditions.append(f"e.division IN ({placeholders})")
                params.extend(division_filter)
            else:
                conditions.append("e.division = %s")
                params.append(division_filter)

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        query += " ORDER BY e.full_name"

        cursor.execute(query, tuple(params))
        rows = cursor.fetchall()

        with open(file_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerows(rows)

        print(f"DEBUG EXPORT: [SUCCESS] Successfully wrote {len(rows)} rows to CSV.")
        return True

    except (Error, Exception) as err:
        print(f"DEBUG EXPORT: [ERROR] Failed to generate CSV: {err}")
        return False
    finally:
        if connection:
            connection.close()


def export_summary_to_csv(file_path, division_filter=None, employee_ids=None):
    """Export summary performance scores (KPI/Core/Leadership) to a CSV file."""
    connection = get_db_connection()
    if not connection:
        return False

    headers = [
        'Company', 'Full Name', 'Employee ID', 'Position', 'Job Level',
        'Perf_KPI_score', 'core_behaviors_total_score', 'leadership_behaviors_total_score'
    ]

    try:
        cursor = connection.cursor()
        params = []
        excluded_divisions = EXCLUDED_DIVISIONS_BY_EMPLOYEE.get(str(session.get('employee_id', '')).strip())

        query = """
                SELECT e.company,
                       e.full_name,
                       e.employee_id,
                       e.position,
                       e.job_level,
                       af.perf_kpi_score,
                       af.core_behaviors_total_score,
                       af.leadership_behaviors_total_score
                FROM all_final_scores af
                         JOIN pe_staff e ON af.employee_id = e.employee_id
                """

        conditions = ["LOWER(TRIM(e.position)) != 'managing director'"]
        if excluded_divisions:
            placeholders = ", ".join(["%s"] * len(excluded_divisions))
            conditions.append(f"e.division NOT IN ({placeholders})")
            params.extend(excluded_divisions)
        if employee_ids:
            placeholders = ", ".join(["%s"] * len(employee_ids))
            conditions.append(f"CAST(e.employee_id AS CHAR) IN ({placeholders})")
            params.extend(employee_ids)
        elif division_filter is not None:
            if isinstance(division_filter, list):
                placeholders = ", ".join(["%s"] * len(division_filter))
                conditions.append(f"e.division IN ({placeholders})")
                params.extend(division_filter)
            else:
                conditions.append("e.division = %s")
                params.append(division_filter)

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        query += " ORDER BY e.full_name"

        cursor.execute(query, tuple(params))
        rows = cursor.fetchall()

        with open(file_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerows(rows)

        print(f"DEBUG EXPORT SUMMARY: Successfully wrote {len(rows)} rows to CSV.")
        return True

    except (Error, Exception) as err:
        print(f"DEBUG EXPORT SUMMARY: Failed to generate summary CSV: {err}")
        return False
    finally:
        if connection:
            connection.close()


def save_all_final_scores_to_db(employee_id, scores_data):
    """Save all final performance scores to the all_final_scores table."""
    conn = get_db_connection()
    if not conn:
        print(f"DEBUG SAVE: [ERROR] No database connection for employee_id: {employee_id}")
        return False

    def clean_score(key):
        try:
            value = float(scores_data.get(key, 0) or 0)
            return float(f"{value:.2f}")
        except Exception:
            return 0.0

    data = (
        employee_id,
        get_employee_profile(employee_id).get('company', 'N/A'),
        clean_score('group_kpi_score'),
        clean_score('bu_lob_kpi_total_score'),
        clean_score('org_cap_total_score'),
        clean_score('people_dev_total_score'),
        clean_score('bu_obj_total_score'),
        clean_score('core_behaviors_avg_score'),
        clean_score('leadership_behaviors_avg_score'),
        clean_score('perf_kpi_score'),
        clean_score('core_behaviors_total_score'),
        clean_score('leadership_behaviors_total_score'),
        clean_score('final_total_score')
    )

    query = """
            INSERT INTO all_final_scores (employee_id, company, group_kpi_score, bu_lob_kpi_total_score,
                                          org_cap_total_score, people_dev_total_score, bu_obj_total_score,
                                          core_behaviors_avg_score, leadership_behaviors_avg_score,
                                          perf_kpi_score, core_behaviors_total_score,
                                          leadership_behaviors_total_score, final_total_score)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) ON DUPLICATE KEY \
            UPDATE \
                company = \
            VALUES (company), group_kpi_score = \
            VALUES (group_kpi_score), bu_lob_kpi_total_score = \
            VALUES (bu_lob_kpi_total_score), org_cap_total_score = \
            VALUES (org_cap_total_score), people_dev_total_score = \
            VALUES (people_dev_total_score), bu_obj_total_score = \
            VALUES (bu_obj_total_score), core_behaviors_avg_score = \
            VALUES (core_behaviors_avg_score), leadership_behaviors_avg_score = \
            VALUES (leadership_behaviors_avg_score), perf_kpi_score = \
            VALUES (perf_kpi_score), core_behaviors_total_score = \
            VALUES (core_behaviors_total_score), leadership_behaviors_total_score = \
            VALUES (leadership_behaviors_total_score), final_total_score = \
            VALUES (final_total_score)
            """

    try:
        cursor = conn.cursor()
        cursor.execute(query, data)
        print(f"DEBUG SAVE: [SUCCESS] Scores saved successfully. Data: {data}")
        return True
    except mysql.connector.Error as err:
        print(f"DEBUG SAVE: [ERROR] CRITICAL DB WRITE ERROR (SQL): {err}")
        print(f"DEBUG SAVE: Attempted data: {data}")
        return False
    except Exception as e:
        print(f"DEBUG SAVE: [ERROR] Unexpected Python Error during save: {e}")
        return False
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass


def calculate_summary_snapshot_for_employee(employee_id: Any, eval_year: int, use_supervisor_review: bool = False) -> Dict[str, Any]:
    """Calculate summary and persisted score payload for an employee/year."""
    target_employee_id = str(employee_id or '').strip()
    profile = get_employee_profile(target_employee_id)
    job_level = safe_int(profile.get('job_level'), 0)

    group_kpi_data = load_form_data_from_db(GLOBAL_GROUP_KPI_EMPLOYEE_ID[0], 'group_kpi', eval_year) or {}
    bu_lob_kpi_data = load_form_data_from_db(target_employee_id, 'bu_lob_kpi', eval_year) or {}
    org_cap_data = load_form_data_from_db(target_employee_id, 'org_capability', eval_year) or {}
    people_dev_data = load_form_data_from_db(target_employee_id, 'people_dev', eval_year) or {}
    bu_obj_data = load_form_data_from_db(target_employee_id, 'bu_obj', eval_year) or {}
    core_behaviors_data = load_form_data_from_db(target_employee_id, 'core_behaviors', eval_year) or {}
    leadership_behaviors_data = load_form_data_from_db(target_employee_id, 'leadership_behaviors', eval_year) or {}

    if use_supervisor_review:
        bu_lob_kpi_data = merge_kpi_review_data(bu_lob_kpi_data, load_supervisor_review_from_db(target_employee_id, 'bu_lob_kpi', eval_year), 5)
        org_cap_data = merge_kpi_review_data(org_cap_data, load_supervisor_review_from_db(target_employee_id, 'org_capability', eval_year), 10)
        if job_level >= 8:
            people_dev_data = merge_kpi_review_data(people_dev_data, load_supervisor_review_from_db(target_employee_id, 'people_dev', eval_year), 10)
        bu_obj_data = merge_kpi_review_data(bu_obj_data, load_supervisor_review_from_db(target_employee_id, 'bu_obj', eval_year), 15)
        if job_level <= 11:
            core_behaviors_data = merge_behavior_review_data(core_behaviors_data, load_supervisor_review_from_db(target_employee_id, 'core_behaviors', eval_year))
        if job_level >= 8:
            leadership_behaviors_data = merge_behavior_review_data(leadership_behaviors_data, load_supervisor_review_from_db(target_employee_id, 'leadership_behaviors', eval_year))

    def calculate_kpi_avg_score(data: Optional[Dict[str, Any]], num_rows: int) -> float:
        if not isinstance(data, dict) or 'scores' not in data:
            return 0.0
        scores = data.get('scores', [])
        if not isinstance(scores, list):
            return 0.0
        total_score = 0.0
        count = 0
        for i in range(min(num_rows, len(scores))):
            score = safe_float(scores[i], 0.0)
            if score > 0:
                total_score += score
                count += 1
        return total_score / count if count > 0 else 0.0

    def calculate_avg_score(data: Optional[Dict[str, Any]]) -> float:
        if not isinstance(data, dict):
            return 0.0
        scores_dict = data.get('scores', {})
        if not isinstance(scores_dict, dict):
            return 0.0
        values: List[float] = []
        for score in scores_dict.values():
            raw_text = str(score or '').strip()
            if not raw_text:
                continue
            score_value = safe_float(raw_text, 0.0)
            if 0 <= score_value <= 5:
                values.append(score_value)
        return sum(values) / len(values) if values else 0.0

    group_kpi_result_float = safe_float(safe_get(group_kpi_data, 'group_result'), 0.0)
    group_kpi_total_score_float = group_kpi_result_float
    bu_lob_kpi_total_score_float = safe_float(safe_get(bu_lob_kpi_data, 'total_score'), 0.0)
    org_cap_total_score_float = safe_float(safe_get(org_cap_data, 'total_score'), 0.0)
    people_dev_total_score_float = safe_float(safe_get(people_dev_data, 'total_score'), 0.0)
    bu_obj_total_score_float = safe_float(safe_get(bu_obj_data, 'total_score'), 0.0)

    total_kpi_score = 0.0
    if job_level >= 10:
        total_kpi_score += group_kpi_result_float
    if job_level >= 8:
        total_kpi_score += bu_lob_kpi_total_score_float
        total_kpi_score += people_dev_total_score_float
    total_kpi_score += org_cap_total_score_float
    total_kpi_score += bu_obj_total_score_float

    core_behaviors_avg_score = calculate_avg_score(core_behaviors_data)
    leadership_behaviors_avg_score = calculate_avg_score(leadership_behaviors_data)

    group_kpi_direct_score = safe_float(group_kpi_data.get('group_score', ''), 0.0)
    bu_lob_kpi_avg_score = safe_float(bu_lob_kpi_data.get('average_score', ''), 0.0) or calculate_kpi_avg_score(bu_lob_kpi_data, 5)
    org_cap_avg_score = calculate_kpi_avg_score(org_cap_data, 10)
    people_dev_avg_score = calculate_kpi_avg_score(people_dev_data, 10)
    bu_obj_avg_score = calculate_kpi_avg_score(bu_obj_data, 15)

    if 4 <= job_level <= 7:
        perf_kpi_weight, core_behaviors_weight, leadership_behaviors_weight = 70, 30, 0
    elif 8 <= job_level <= 9:
        perf_kpi_weight, core_behaviors_weight, leadership_behaviors_weight = 80, 15, 5
    elif 10 <= job_level <= 11:
        perf_kpi_weight, core_behaviors_weight, leadership_behaviors_weight = 90, 5, 5
    elif 12 <= job_level <= 15:
        perf_kpi_weight, core_behaviors_weight, leadership_behaviors_weight = 95, 0, 5
    else:
        perf_kpi_weight, core_behaviors_weight, leadership_behaviors_weight = 0, 0, 0

    final_perf_kpi_contribution = (total_kpi_score * perf_kpi_weight) / 100
    final_core_behaviors_contribution = (core_behaviors_avg_score * core_behaviors_weight) / 100
    final_leadership_behaviors_contribution = (leadership_behaviors_avg_score * leadership_behaviors_weight) / 100
    final_total_score = final_perf_kpi_contribution + final_core_behaviors_contribution + final_leadership_behaviors_contribution
    total_weight = perf_kpi_weight + core_behaviors_weight + leadership_behaviors_weight

    scores_to_save = {
        'group_kpi_score': group_kpi_result_float,
        'group_kpi_weight_pct': get_weight_limit(form_id='group_kpi', job_level=job_level),
        'group_kpi_total_score': group_kpi_total_score_float,
        'bu_lob_kpi_total_score': bu_lob_kpi_total_score_float,
        'org_cap_total_score': org_cap_total_score_float,
        'people_dev_total_score': people_dev_total_score_float,
        'bu_obj_total_score': bu_obj_total_score_float,
        'core_behaviors_avg_score': core_behaviors_avg_score,
        'leadership_behaviors_avg_score': leadership_behaviors_avg_score,
        'perf_kpi_score': final_perf_kpi_contribution,
        'core_behaviors_total_score': final_core_behaviors_contribution,
        'leadership_behaviors_total_score': final_leadership_behaviors_contribution,
        'final_total_score': final_total_score,
    }

    summary_data = {
        'perf_kpi_weight_pct': perf_kpi_weight,
        'core_behaviors_weight_pct': core_behaviors_weight,
        'leadership_behaviors_weight_pct': leadership_behaviors_weight,
        'perf_kpi_score': "{:.2f}".format(final_perf_kpi_contribution),
        'core_behaviors_score': "{:.2f}".format(final_core_behaviors_contribution),
        'leadership_behaviors_score': "{:.2f}".format(final_leadership_behaviors_contribution),
        'total_weight': total_weight,
        'final_total_score': "{:.2f}".format(final_total_score),
        'group_kpi_score': "{:.2f}".format(group_kpi_result_float),
        'bu_lob_kpi_score': "{:.2f}".format(bu_lob_kpi_total_score_float),
        'org_cap_score': "{:.2f}".format(org_cap_total_score_float),
        'people_dev_score': "{:.2f}".format(people_dev_total_score_float),
        'bu_obj_score': "{:.2f}".format(bu_obj_total_score_float),
        'core_behaviors_avg': "{:.2f}".format(core_behaviors_avg_score),
        'leadership_behaviors_avg': "{:.2f}".format(leadership_behaviors_avg_score),
        'total_kpi_score': "{:.2f}".format(total_kpi_score),
        'group_kpi_weight': get_weight_limit(form_id='group_kpi', job_level=job_level),
        'bu_lob_kpi_weight': get_weight_limit(form_id='bu_lob_kpi', job_level=job_level),
        'people_dev_weight': get_weight_limit(form_id='people_dev', job_level=job_level),
        'org_cap_weight': get_weight_limit(form_id='org_capability', job_level=job_level),
        'bu_obj_weight': get_weight_limit(form_id='bu_obj', job_level=job_level),
        'group_kpi_avg_score': "{:.2f}".format(group_kpi_direct_score),
        'bu_lob_kpi_avg_score': "{:.2f}".format(bu_lob_kpi_avg_score),
        'org_cap_avg_score': "{:.2f}".format(org_cap_avg_score),
        'people_dev_avg_score': "{:.2f}".format(people_dev_avg_score),
        'bu_obj_avg_score': "{:.2f}".format(bu_obj_avg_score),
        'job_level': job_level,
        'review_finalized': bool(use_supervisor_review),
    }
    return {'scores_to_save': scores_to_save, 'summary_data': summary_data}


def persist_summary_snapshot_for_employee(employee_id: Any, eval_year: int, use_supervisor_review: bool = False) -> Dict[str, Any]:
    """Recalculate and persist official summary tables for dashboard/summary views."""
    snapshot = calculate_summary_snapshot_for_employee(employee_id, eval_year, use_supervisor_review)
    save_all_final_scores_to_db(employee_id, snapshot.get('scores_to_save', {}))
    save_summary_history(str(employee_id), eval_year, snapshot.get('summary_data', {}))
    return snapshot


def get_form_data(form_id: str) -> Dict[str, Any]:
    """Helper function to retrieve and format saved form data from session or database.
    
    Args:
        form_id: The form identifier to retrieve data for

    Returns:
        Dict[str, Any]: The form data as a dictionary, empty dict if not found
    """
    employee_id = str(session.get('employee_id', '') or '')  # Normalize to string
    division = session.get('division', '')
    company = session.get('company', '')
    job_level = safe_int(session.get('job_level'), 0)
    user_data = session.get('user_data', {})
    if not isinstance(user_data, dict):
        user_data = {}

    # Prefer DB as source of truth to avoid session cookie size limits
    if form_id != 'group_kpi' or not uses_admin_managed_group_kpi(company):
        db_data = load_form_data_from_db(employee_id, form_id)
        if db_data:
            normalized = _normalize_form_data(form_id, db_data)
            if form_id == 'bu_lob_kpi':
                return apply_fixed_bu_lob_constraints(normalized, job_level, division, company)
            return normalized

    # Fallback to any cached session copy if DB has nothing
    if form_id in user_data and (form_id != 'group_kpi' or not uses_admin_managed_group_kpi(company)):
        normalized = _normalize_form_data(form_id, user_data[form_id])
        if form_id == 'bu_lob_kpi':
            return apply_fixed_bu_lob_constraints(normalized, job_level, division, company)
        return normalized

    # Return default empty data
    if form_id in ['org_capability', 'people_dev', 'bu_obj']:
        num_rows = 15 if form_id == 'bu_obj' else 10
        return _normalize_form_data(form_id, {
            'descriptions': [''] * num_rows,
            'weights': [''] * num_rows,
            'scores': [''] * num_rows,
            'results': ['0.00'] * num_rows,
            'short_descriptions': [[''] * 5 for _ in range(num_rows)],
            'total_score': '0.00'
        })
    elif form_id == 'bu_lob_kpi':
        default_data = _normalize_form_data(form_id, {
            'descriptions': [''] * 5,
            'weights': [''] * 5,
            'scores': [''] * 5,
            'results': ['0.00'] * 5,
            'short_descriptions': [[''] * 5 for _ in range(5)],
            'total_score': '0.00'
        })
        return apply_fixed_bu_lob_constraints(default_data, job_level, division, company)
    elif form_id == 'group_kpi':
        eval_year = get_eval_year()
        job_level = safe_int(session.get('job_level'), 0)
        group_weight = get_weight_limit('group_kpi', job_level)
        global_group_data = load_form_data_from_db(GLOBAL_GROUP_KPI_EMPLOYEE_ID[0], 'group_kpi', eval_year)
        group_score_value = safe_get(global_group_data, 'group_score', '') if global_group_data else ''
        group_score_num = safe_float(group_score_value, 0.0)
        group_result_value = "{:.2f}".format((group_score_num * group_weight) / 100) if group_score_value else '0.00'
        return {
            'group_score': group_score_value,
            'group_weight': str(group_weight),
            'group_result': group_result_value
        }
    elif form_id in ['core_behaviors', 'leadership_behaviors']:
        return {'scores': {}}
    elif form_id == 'comments':
        return {'employee_comments': '', 'supervisor_comments': ''}

    return {}


def _normalize_form_data(form_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Ensure critical keys exist and arrays are the right length so previously saved data (even old records
    without short_descriptions) render correctly.
    """
    if form_id in ['bu_lob_kpi', 'org_capability', 'people_dev', 'bu_obj']:
        if form_id == 'bu_lob_kpi':
            num_rows = 2 if is_fixed_bu_lob_user(session.get('job_level'), session.get('division'), session.get('company')) else 5
        elif form_id == 'bu_obj':
            num_rows = 15
        else:
            num_rows = 10
        short_descs = data.get('short_descriptions')
        if not isinstance(short_descs, list):
            short_descs = []
        normalized_rows: List[List[str]] = []
        for i in range(num_rows):
            row = short_descs[i] if i < len(short_descs) and isinstance(short_descs[i], list) else []
            # Pad or trim each row to 5 entries
            padded_row = []
            for j in range(5):
                val = row[j] if j < len(row) else ''
                padded_row.append(val if val is not None else '')
            normalized_rows.append(padded_row)
        data['short_descriptions'] = normalized_rows
    return data


@app.route('/')
def index():
    if 'employee_id' in session:
        return redirect(url_for('profile_page'))
    return redirect(url_for('login'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Show login page or initiate Azure AD login via MSAL"""
    # If user clicks the login button (POST request or 'start' query param), redirect to Azure AD
    if request.method == 'POST' or request.args.get('start') == '1':
        auth_app = _build_msal_app()
        if not auth_app:
            flash('Azure AD is not configured. Please set AAD_TENANT_ID, AAD_CLIENT_ID, and AAD_CLIENT_SECRET.', 'error')
            return render_template_string(LOGIN_TEMPLATE)
        session['state'] = os.urandom(16).hex()
        auth_url = auth_app.get_authorization_request_url(
            AAD_SCOPES, state=session['state'], redirect_uri=AAD_REDIRECT_URI)
        return redirect(auth_url)

    # Show the login page with "Login with Microsoft" button
    return render_template_string(LOGIN_TEMPLATE)


@app.route('/auth/callback')
def auth_callback():
    request_state = request.args.get("state")
    session_state = session.get("state")
    if request_state != session_state:
        return "State mismatch", 400

    # Clear one-time state to avoid stale/replay issues on refresh.
    session.pop("state", None)

    aad_error = request.args.get("error")
    if aad_error:
        aad_error_description = request.args.get("error_description", "Azure AD login failed.")
        flash(f"Login error: {aad_error_description}", "error")
        return redirect(url_for('login'))

    code = request.args.get("code")
    if not code:
        flash("Login error: Authorization code was not returned by Azure AD. Please sign in again.", "error")
        return redirect(url_for('login'))

    auth_app = _build_msal_app()
    if not auth_app:
        return "Azure AD is not configured on the server.", 500
    result = auth_app.acquire_token_by_authorization_code(
        code, scopes=AAD_SCOPES, redirect_uri=AAD_REDIRECT_URI)
    if "id_token_claims" not in result:
        flash(f"Login error: {result}", "error")
        return redirect(url_for('login'))
    claims = result["id_token_claims"]
    upn = (
        claims.get("preferred_username")
        or claims.get("email")
        or claims.get("upn")
        or claims.get("unique_name")
    )
    upn = upn.strip() if isinstance(upn, str) else None
    app.logger.info("Azure claims preferred_username=%s email=%s upn=%s unique_name=%s oid=%s",
                    claims.get("preferred_username"),
                    claims.get("email"),
                    claims.get("upn"),
                    claims.get("unique_name"),
                    claims.get("oid"))
    user = get_user_by_username(upn) if upn else None
    if not user:
        flash(f"No local account is mapped to this Azure user ({upn or 'unknown'}).", "error")
        return redirect(url_for('login'))
    profile = get_employee_profile(user['employee_id'])
    if not profile:
        flash('Employee profile not found. Please contact support.', 'error')
        return redirect(url_for('login'))
    employee_master = get_employee_master_row(user['employee_id'])
    employee_status = str(employee_master.get('employee_status', '') or '').strip().lower()
    employment_status = str(employee_master.get('employment_status', '') or '').strip().lower()
    if employee_status not in {'active', 'working'} or employment_status != 'permanent':
        if employment_status != 'permanent':
            flash('PE System is available only for permanent staff. Contract staff cannot access the system.', 'error')
        else:
            flash('PE System is available only for staff who are currently active.', 'error')
        session.clear()
        return redirect(url_for('login'))
    company_name = str(profile.get('company', '') or '').strip()
    if company_name in TEMP_BLOCKED_PE_COMPANIES:
        flash('PE System is not available yet for Argento Tech and TSpace users.', 'error')
        session.clear()
        return redirect(url_for('login'))

    session['employee_id'] = user['employee_id']
    session['username'] = user['username']
    session['full_name'] = profile['full_name']
    session['position'] = profile['position']
    session['division'] = profile['division']
    session['company'] = profile.get('company', 'N/A')
    session['section'] = profile.get('section', 'N/A')
    session['team'] = profile.get('team', 'N/A')
    session['job_level'] = profile['job_level']
    session['current_supervisor'] = profile.get('current_supervisor', 'N/A')
    session['user_data'] = {}
    session['access_token'] = result.get("access_token")
    return redirect(url_for('profile_page'))


@app.route('/user-photo-placeholder')
def user_photo_placeholder():
    display_name = request.args.get('name') or session.get('full_name', 'User')
    initials = _extract_initials(display_name)
    svg = (
        "<svg xmlns='http://www.w3.org/2000/svg' width='128' height='128' viewBox='0 0 128 128'>"
        "<rect width='128' height='128' fill='#E2E8F0'/>"
        f"<text x='50%' y='54%' text-anchor='middle' dominant-baseline='middle' "
        f"font-family='Arial, sans-serif' font-size='44' font-weight='700' fill='#334155'>{initials}</text>"
        "</svg>"
    )
    return svg, 200, {
        "Content-Type": "image/svg+xml; charset=utf-8",
        "Cache-Control": "no-store",
    }


@app.route('/user-photo')
def user_photo():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    current_employee_id = str(session.get('employee_id', '')).strip()
    target_graph_user = get_graph_user_identifier_by_employee_id(current_employee_id)
    image_bytes = None
    content_type = None

    if target_graph_user:
        image_bytes, content_type = _fetch_graph_profile_photo(session.get('access_token'), target_graph_user)
        if not image_bytes:
            app_token = _acquire_graph_app_token()
            if app_token:
                image_bytes, content_type = _fetch_graph_profile_photo(app_token, target_graph_user)
    else:
        image_bytes, content_type = _fetch_graph_profile_photo(session.get('access_token'))

    if not image_bytes:
        return redirect(url_for('user_photo_placeholder', name=session.get('full_name', 'User')))

    return image_bytes, 200, {
        "Content-Type": content_type or "image/jpeg",
        "Cache-Control": "no-store",
    }


@app.route('/user-photo/<employee_id>')
def user_photo_for_employee(employee_id):
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    viewer_id = session.get('employee_id')
    target_employee_id = str(employee_id).strip()
    if not can_view_employee_photo(viewer_id, target_employee_id):
        return "Forbidden", 403

    target_graph_user = get_graph_user_identifier_by_employee_id(target_employee_id)
    if not target_graph_user:
        app.logger.info("No Graph identifier mapped for employee_id=%s", target_employee_id)
        target_profile = get_employee_profile(target_employee_id)
        return redirect(url_for('user_photo_placeholder', name=target_profile.get('full_name', 'User')))

    image_bytes, content_type = _fetch_graph_profile_photo(session.get('access_token'), target_graph_user)
    if not image_bytes:
        # Fallback to app token in case delegated token lacks cross-user photo scope.
        app_token = _acquire_graph_app_token()
        if app_token:
            image_bytes, content_type = _fetch_graph_profile_photo(app_token, target_graph_user)

    if not image_bytes:
        target_profile = get_employee_profile(target_employee_id)
        return redirect(url_for('user_photo_placeholder', name=target_profile.get('full_name', 'User')))

    return image_bytes, 200, {
        "Content-Type": content_type or "image/jpeg",
        "Cache-Control": "no-store",
    }


def get_employee_photo_src(employee_id: Any, display_name: Any, access_token: Optional[str] = None) -> str:
    """Build a direct image source for summary pages, with placeholder fallback."""
    target_employee_id = str(employee_id or "").strip()
    placeholder_url = url_for('user_photo_placeholder', name=str(display_name or 'User'))
    if not target_employee_id:
        return placeholder_url

    target_graph_user = get_graph_user_identifier_by_employee_id(target_employee_id)
    if not target_graph_user:
        return placeholder_url

    image_bytes = None
    content_type = None

    if access_token:
        image_bytes, content_type = _fetch_graph_profile_photo(access_token, target_graph_user)

    if not image_bytes:
        app_token = _acquire_graph_app_token()
        if app_token:
            image_bytes, content_type = _fetch_graph_profile_photo(app_token, target_graph_user)

    if not image_bytes:
        return placeholder_url

    encoded = base64.b64encode(image_bytes).decode('ascii')
    return f"data:{content_type or 'image/jpeg'};base64,{encoded}"


# Base template with navigation
BASE_WITH_NAV = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}Performance Evaluation System{% endblock %}</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='css/app.css') }}">
    <style>
    [data-theme="dark"] .header-section > p {
        color: #e5e7eb !important;
    }
    {% block extra_style %}{% endblock %}
    </style>
</head>
<body>
    {{ nav_html|safe }}
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <main class="main-content">
        <div class="top-header">
            <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="Toggle menu">&#9776;</button>
            <h1 class="page-title">{{ page_title }}</h1>
        </div>

        <div class="content-card">
            {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, message in messages %}
                <div class="alert-{{ category }}">
                    <strong>{{ message }}</strong>
                </div>
                {% endfor %}
            {% endif %}
            {% endwith %}

            {% block content %}{% endblock %}
        </div>
    </main>

    {% block extra_script %}{% endblock %}
    <!-- Theme Switcher Script -->
    <script>
    (function() {
        const THEME_KEY = 'pe-app-theme';
        const themeToggle = document.getElementById('themeToggle');
        const themeText = document.getElementById('themeText');
        const themeIcon = document.getElementById('themeIcon');
        const html = document.documentElement;
        
        function loadTheme() {
            const savedTheme = localStorage.getItem(THEME_KEY) || 'light';
            applyTheme(savedTheme);
        }
        
        function applyTheme(theme) {
            html.setAttribute('data-theme', theme);
            if (themeToggle) themeToggle.checked = (theme === 'dark');
            updateThemeUI(theme);
        }
        
        function updateThemeUI(theme) {
            if (theme === 'dark') {
                if (themeText) themeText.textContent = 'Dark';
                if (themeIcon) themeIcon.textContent = '🌙';
            } else {
                if (themeText) themeText.textContent = 'Light';
                if (themeIcon) themeIcon.textContent = '☀️';
            }
        }
        
        if (themeToggle) {
            themeToggle.addEventListener('change', function() {
                const newTheme = this.checked ? 'dark' : 'light';
                applyTheme(newTheme);
                localStorage.setItem(THEME_KEY, newTheme);
                
                html.style.transition = 'background 0.3s ease, color 0.3s ease';
                setTimeout(() => {
                    html.style.transition = '';
                }, 300);
            });
            
            document.addEventListener('DOMContentLoaded', loadTheme);
        } else {
            loadTheme();
        }
        
        if (typeof window.addEventListener === 'function') {
            window.addEventListener('popstate', loadTheme);
        }
    })();
    </script>
    <script>
    (function() {
        const sidebar = document.querySelector('.sidebar');
        const menuBtn = document.getElementById('mobileMenuBtn');
        const overlay = document.getElementById('sidebarOverlay');
        if (!sidebar || !menuBtn || !overlay) return;

        const closeSidebar = () => {
            sidebar.classList.remove('open');
            overlay.classList.remove('show');
        };

        menuBtn.addEventListener('click', () => {
            const isOpen = sidebar.classList.toggle('open');
            overlay.classList.toggle('show', isOpen);
        });

        overlay.addEventListener('click', closeSidebar);
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') closeSidebar();
        });
    })();
    </script>
    <script>
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function(){ if (typeof window.recomputePage==='function') window.recomputePage(); });
      } else {
        if (typeof window.recomputePage==='function') window.recomputePage();
      }
    </script>
    <script>
    // Global, idempotent recompute to restore derived values after soft nav
    window.recomputePage = function recomputePage(){
      try {
        // KPI forms (BU/LoB, Org Cap, People Dev, BU Obj)
        const kpiForm = document.getElementById('kpiForm');
        if (kpiForm) {
          const weights = kpiForm.querySelectorAll('.weight-input');
          const scores = kpiForm.querySelectorAll('.score-input');
          const results = kpiForm.querySelectorAll('.result-display');
          const totalWeightEl = document.getElementById('totalWeight');
          const totalScoreEl = document.getElementById('totalScore');
          let tw = 0, ts = 0;
          for (let i = 0; i < weights.length; i++) {
            const w = parseFloat((weights[i].value||'').trim()) || 0;
            const s = parseFloat((scores[i].value||'').trim()) || 0;
            const r = (w * s) / 100;
            if (results[i]) results[i].value = r.toFixed(2);
            tw += w; ts += r;
          }
          if (totalWeightEl) totalWeightEl.value = tw.toFixed(2);
          if (totalScoreEl) totalScoreEl.value = ts.toFixed(2);
        }

        // Group KPI
        const groupForm = document.getElementById('groupKpiForm');
        if (groupForm) {
          const hiddenW = groupForm.querySelector('input[name="group_weight"]');
          const scoreEl = document.getElementById('group_score');
          const resultEl = document.getElementById('group_result');
          const gw = parseFloat(hiddenW && hiddenW.value) || 0;
          const s = parseFloat(scoreEl && scoreEl.value) || 0;
          const r = (gw * s) / 100;
          if (resultEl) resultEl.value = r.toFixed(2);
        }

        // Behaviors average
        const avgEl = document.getElementById('averageScore');
        const selects = document.querySelectorAll('.behavior-select');
        if (avgEl && selects.length) {
          let tot = 0, cnt = 0;
          selects.forEach(sel=>{ const v = parseInt(sel.value, 10); if (v>=1 && v<=5){ tot+=v; cnt++; } });
          avgEl.textContent = (cnt>0 ? (tot/cnt).toFixed(2) : '0.00');
        }

        // Staff Promotion textareas
        const promotionIds = ['current_job_description', 'new_job_description', 'new_job_assignment', 'reasons_for_adjustment'];
        promotionIds.forEach((id) => {
          const el = document.getElementById(id);
          if (!el) return;
          el.style.overflowY = 'hidden';
          el.style.resize = 'none';
          const doResize = () => {
            el.style.height = 'auto';
            el.style.height = `${el.scrollHeight + 2}px`;
          };
          if (!el.dataset.promotionAutoresizeBound) {
            el.addEventListener('input', doResize);
            el.addEventListener('change', doResize);
            el.addEventListener('paste', () => {
              setTimeout(doResize, 0);
              setTimeout(doResize, 50);
            });
            el.dataset.promotionAutoresizeBound = '1';
          }
          doResize();
          setTimeout(doResize, 0);
          setTimeout(doResize, 100);
        });
      } catch(e) { console.warn('recomputePage error', e); }
    };
    </script>
    <script>
    // Idempotent initializer for KPI forms (enforces weight limit + score blocking)
    window.initKpiForm = function initKpiForm(){
      const form = document.getElementById('kpiForm');
      if (!form || form.dataset.inited === '1') return;
      const weightLimit = parseFloat(form.dataset.weightLimit || '0') || 0;
      const weights = form.querySelectorAll('.weight-input');
      const scores = form.querySelectorAll('.score-input');
      const results = form.querySelectorAll('.result-display');
      const totalWeightEl = document.getElementById('totalWeight');
      const totalScoreEl = document.getElementById('totalScore');
      const warningEl = document.getElementById('weightWarning');
      const currentWeightDisplay = document.getElementById('currentWeightDisplay');

      function calc(){
        let tw = 0, ts = 0;
        weights.forEach((wEl, i)=>{
          const w = parseFloat((wEl.value||'').trim()) || 0;
          const s = parseFloat((scores[i].value||'').trim()) || 0;
          if (s > 0 && (s < 1 || s > 5)) { scores[i].value = ''; return; }
          const r = (w * s) / 100;
          if (results[i]) results[i].value = r.toFixed(2);
          tw += w; ts += r;
        });
        if (totalWeightEl) totalWeightEl.value = tw.toFixed(2);
        if (totalScoreEl) totalScoreEl.value = ts.toFixed(2);
        if (currentWeightDisplay) {
          if (tw > weightLimit) {
            warningEl.style.display = 'block';
            currentWeightDisplay.innerHTML = `Current Total: <span style="color: #dc2626;">${tw.toFixed(2)}%</span> (Exceeds limit - BLOCKED!)`;
            totalWeightEl.style.background = 'linear-gradient(135deg, #fee2e2 0%, #fecaca 100%)';
            totalWeightEl.style.color = '#dc2626';
          } else if (tw === weightLimit) {
            warningEl.style.display = 'none';
            currentWeightDisplay.innerHTML = `Current Total: <span style="color: #16a34a;">${tw.toFixed(2)}%</span> (Exact limit - Perfect!)`;
            totalWeightEl.style.background = 'linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%)';
            totalWeightEl.style.color = '#16a34a';
          } else {
            warningEl.style.display = 'none';
            const remaining = weightLimit - tw;
            currentWeightDisplay.innerHTML = `Current Total: <span style="color: #3b82f6;">${tw.toFixed(2)}%</span> (${remaining.toFixed(2)}% remaining)`;
            totalWeightEl.style.background = 'linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)';
            totalWeightEl.style.color = '#000';
          }
        }
      }

      // Attach listeners
      scores.forEach(input => {
        input.addEventListener('input', function(){
          let v = parseFloat(this.value);
          if (v === 0) { this.value = ''; alert('Score cannot be 0. Please enter a value between 1.00 and 5.00'); return; }
          if (v > 5) { this.value = '5'; alert('Score cannot exceed 5.00. Maximum score is 5.00'); calc(); return; }
          if (v < 1 && this.value !== '') { this.value = '1'; alert('Score cannot be less than 1.00. Minimum score is 1.00'); calc(); return; }
          calc();
        });
        input.addEventListener('blur', calc);
      });

      weights.forEach(input => {
        input.addEventListener('input', function(){
          calc();
          const tw = parseFloat(totalWeightEl.value) || 0;
          if (tw > weightLimit) {
            const currentValue = parseFloat(this.value) || 0;
            const excess = tw - weightLimit;
            this.value = Math.max(0, currentValue - excess).toFixed(2);
            if (warningEl) warningEl.style.display = 'block';
            alert(`Total weight cannot exceed ${weightLimit}%. The excess has been automatically removed.`);
            calc();
          }
        });
      });

      form.addEventListener('submit', function(e){
        const tw = parseFloat(totalWeightEl.value) || 0;
        if (tw > weightLimit) {
          e.preventDefault();
          alert(`BLOCKED: Total weight (${tw.toFixed(2)}%) exceeds the limit of ${weightLimit}%. Please reduce weights to ${weightLimit}% or less.`);
          if (warningEl) warningEl.style.display = 'block';
          window.scrollTo({ top: 0, behavior: 'smooth' });
          return false;
        }
        let invalid = false;
        scores.forEach(input=>{
          if (input.value) {
            const s = parseFloat(input.value);
            if (s === 0 || s < 1 || s > 5) invalid = true;
          }
        });
        if (invalid) {
          e.preventDefault();
          alert('BLOCKED: One or more scores are invalid. Scores must be between 1.00 and 5.00 (0 is not allowed).');
          return false;
        }
        return true;
      });

      // Mark initialized and compute once
      form.dataset.inited = '1';
      calc();
    };
    </script>
    <script>
    (function(){
      function setupSoftNav(){
        const sidebar = document.querySelector('.sidebar-nav');
        function isSameOrigin(href){
          try { const u = new URL(href, location.href); return u.origin === location.origin; } catch { return false; }
        }
        async function navigate(url, anchorEl=null, replace=false){
          try {
            const res = await fetch(url, { headers: { 'X-Requested-With': 'fetch' } });
            const html = await res.text();
            const doc = new DOMParser().parseFromString(html, 'text/html');
            const newMain = doc.querySelector('.main-content');
            const newTitle = doc.querySelector('title');
            if (newMain) {
              const currentMain = document.querySelector('.main-content');
              currentMain.replaceWith(newMain);
              // Execute any scripts within the swapped content
              const scripts = Array.from(newMain.querySelectorAll('script'));
              for (const old of scripts) {
                const s = document.createElement('script');
                if (old.src) s.src = old.src;
                if (old.type) s.type = old.type;
                s.textContent = old.textContent;
                document.body.appendChild(s);
                s.remove();
              }
              // After scripts run, try to trigger common page initializers
              try {
                if (typeof window.calculateTotals === 'function') {
                  window.calculateTotals();
                }
                if (typeof window.validateAndCalculate === 'function') {
                  window.validateAndCalculate();
                }
                if (typeof window.calculateAverage === 'function') {
                  window.calculateAverage();
                }
                if (typeof window.initKpiForm === 'function') {
                  window.initKpiForm();
                }
                // Fallback to global recompute if page-local initializers are unavailable
                if (typeof window.recomputePage === 'function') {
                  window.recomputePage();
                }
              } catch (e) { console.warn('Post-swap init error', e); }
            }
            if (newTitle) document.title = newTitle.textContent || document.title;
            if (anchorEl) {
              document.querySelectorAll('.sidebar-nav .nav-item').forEach(el=>el.classList.remove('active'));
              anchorEl.classList.add('active');
            }
            if (replace) history.replaceState({ url }, '', url); else history.pushState({ url }, '', url);
            window.scrollTo(0,0);
          } catch (e) {
            console.warn('Soft navigation failed, falling back', e);
            location.href = url;
          }
        }
        if (sidebar) {
          sidebar.addEventListener('click', (e)=>{
            const a = e.target && e.target.closest('a');
            if (!a) return;
            if (a.target === '_blank' || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
            const href = a.getAttribute('href');
            if (!href || !isSameOrigin(href)) return;
            e.preventDefault();
            navigate(href, a);
          });
        }
        window.addEventListener('popstate', ()=>{
          navigate(location.href, null, true);
        });
        history.replaceState({ url: location.href }, '', location.href);
      }
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setupSoftNav);
      } else {
        setupSoftNav();
      }
    })();
    </script>
</body>
</html>
"""

PROFILE_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<div class="content-container">
    <style>
        .profile-shell {
            max-width: 980px;
            margin: 0 auto;
        }
        .profile-hero {
            position: relative;
            overflow: hidden;
            margin-bottom: 22px;
            padding: 28px;
            border-radius: 22px;
            background: linear-gradient(145deg, #eff6ff 0%, #dbeafe 48%, #f8fafc 100%);
            border: 1px solid #bfdbfe;
            box-shadow: 0 18px 44px rgba(30, 64, 175, 0.12);
        }
        .profile-hero::before {
            content: "";
            position: absolute;
            top: -80px;
            right: -40px;
            width: 220px;
            height: 220px;
            border-radius: 999px;
            background: radial-gradient(circle, rgba(59, 130, 246, 0.24) 0%, rgba(59, 130, 246, 0) 72%);
        }
        .profile-hero::after {
            content: "";
            position: absolute;
            bottom: -60px;
            left: -30px;
            width: 180px;
            height: 180px;
            border-radius: 999px;
            background: radial-gradient(circle, rgba(14, 165, 233, 0.18) 0%, rgba(14, 165, 233, 0) 72%);
        }
        .profile-hero-inner {
            position: relative;
            z-index: 1;
            display: grid;
            grid-template-columns: 132px 1fr;
            gap: 22px;
            align-items: center;
        }
        .profile-photo {
            width: 132px;
            height: 132px;
            border-radius: 999px;
            object-fit: cover;
            border: 4px solid rgba(255, 255, 255, 0.95);
            background: #f8fafc;
            box-shadow: 0 16px 36px rgba(15, 23, 42, 0.16);
        }
        .profile-name {
            margin: 0;
            color: #0f172a;
            font-size: 2rem;
            line-height: 1.1;
            font-weight: 800;
        }
        .profile-role {
            margin: 8px 0 0 0;
            color: #334155;
            font-size: 1.02rem;
            font-weight: 600;
        }
        .profile-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 14px;
        }
        .profile-panel {
            padding: 18px 18px 16px 18px;
            border-radius: 18px;
            background: #ffffff;
            border: 1px solid #e2e8f0;
            box-shadow: 0 10px 28px rgba(15, 23, 42, 0.06);
        }
        .profile-panel.accent {
            background: linear-gradient(145deg, #eff6ff 0%, #ffffff 100%);
            border-color: #bfdbfe;
        }
        .profile-label {
            margin: 0 0 6px 0;
            color: #64748b;
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.05em;
            text-transform: uppercase;
        }
        .profile-value {
            margin: 0;
            color: #0f172a;
            font-size: 1rem;
            font-weight: 700;
            line-height: 1.35;
            word-break: break-word;
        }
        @media (max-width: 768px) {
            .profile-hero-inner {
                grid-template-columns: 1fr;
                text-align: center;
            }
            .profile-photo {
                margin: 0 auto;
            }
            .profile-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
    <div class="header-section">
        <h1 class="gradient-text">Employee Profile</h1>    
        <p>View your employee information</p>
    </div>

    <div class="profile-shell">
        <div class="profile-hero">
            <div class="profile-hero-inner">
                <img src="{{ url_for('user_photo') }}"
                     alt="Profile Photo"
                     class="profile-photo"
                     onerror="this.onerror=null;this.src='{{ url_for('user_photo_placeholder', name=profile.full_name) }}';">
                <div>
                    <h2 class="profile-name">{{ profile.full_name }}</h2>
                    <p class="profile-role">{{ profile.position }}</p>
                </div>
            </div>
        </div>

        <div class="profile-grid">
            <div class="profile-panel accent">
                <p class="profile-label">Employee ID</p>
                <p class="profile-value">{{ profile.employee_id }}</p>
            </div>
            <div class="profile-panel">
                <p class="profile-label">Job Level</p>
                <p class="profile-value">{{ profile.job_level }}</p>
            </div>
            <div class="profile-panel">
                <p class="profile-label">Division / Department</p>
                <p class="profile-value">{{ profile.division }}</p>
            </div>
            <div class="profile-panel accent">
                <p class="profile-label">Company</p>
                <p class="profile-value">{{ profile.get('company', 'N/A') }}</p>
            </div>
        </div>
    </div>

    <div class="button-group">
        <a href="{{ next_page_url }}" class="btn-primary">Next→</a>
    </div>
</div>
{% endblock %}
''')


@app.route('/profile_page')
def profile_page():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    employee_id = session['employee_id']
    job_level = session.get('job_level')
    division = session.get('division')
    company = session.get('company')
    full_name = session.get('full_name', 'N/A')
    profile = get_employee_profile(employee_id)

    if profile:
        next_page_url = url_for('pe_weighting_page')
        nav_html = get_nav_html('profile_page', job_level, full_name)
        return render_template_string(PROFILE_TEMPLATE, profile=profile, next_page_url=next_page_url, nav_html=nav_html,
                                      page_title='Employee Profile', is_super_admin=is_super_admin_employee(employee_id))
    else:
        flash("User profile not found. Please contact support.", 'error')
        session.pop('employee_id', None)
        return redirect(url_for('login'))


DIVISION_REVENUE_EBITDA_ADMIN_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<div class="header-section">
    <h1 class="gradient-text">Shared KPI Scores</h1>
    <p>Maintain admin-managed raw scores for shared KPI inputs.</p>
</div>

<div class="alert-info" style="margin-bottom: 18px;">
    Group Shared KPI applies to: <strong>{{ group_kpi_companies|join(', ') }}</strong>
</div>

<div class="alert-info" style="margin-bottom: 18px;">
    Applies only to Job Level 8-14 for: <strong>{{ divisions|join(', ') }}</strong>
</div>

<form method="get" action="{{ url_for('division_revenue_ebitda_admin_page') }}" style="margin-bottom: 20px;">
    <label class="modern-label" for="eval_year">Select Fiscal Year:</label>
    <select id="eval_year" name="year" class="modern-select" style="width: 200px; display: inline-block;" onchange="this.form.submit()">
        {% for y in available_years %}
        <option value="{{ y }}" {% if y == selected_year %}selected{% endif %}>{{ y }}</option>
        {% endfor %}
    </select>
</form>

<form method="post" action="{{ url_for('division_revenue_ebitda_admin_page') }}">
    <input type="hidden" name="eval_year" value="{{ selected_year }}">

    <div class="section-card" style="margin-bottom: 20px; padding: 18px; border: 1px solid #dbe4f0; border-radius: 14px; background: #ffffff;">
        <div style="display:flex; align-items:flex-start; justify-content:space-between; gap:16px; flex-wrap:wrap;">
            <div>
                <h3 style="margin:0 0 6px 0; color:#1e3a5f;">Group Shared KPI</h3>
                <p style="margin:0; color:#64748b;">Enter one shared raw score. Weighted results are calculated automatically per employee job level.</p>
            </div>
            <div style="display:flex; align-items:center; gap:10px; margin-left:auto;">
                <label class="modern-label" for="group_score_admin" style="margin:0; white-space:nowrap;">Group Score</label>
                <input type="number" id="group_score_admin" name="group_score" class="modern-input" step="0.01" min="1" max="5" value="{{ group_kpi_score }}" placeholder="1.00 - 5.00" style="display:inline-block !important; width:150px !important; max-width:150px !important; text-align:center;">
            </div>
        </div>
    </div>

    <div class="section-card" style="margin-bottom: 20px; padding: 18px; border: 1px solid #dbe4f0; border-radius: 14px; background: #ffffff;">
    <div style="margin-bottom: 14px;">
        <h3 style="margin:0 0 6px 0; color:#1e3a5f;">BU/LoB Shared KPI</h3>
        <p style="margin:0; color:#64748b;">Enter LoB-specific raw scores for Revenue and EBITDA. Eligible mapped companies inherit the linked LoB scores automatically.</p>
    </div>
    <table class="modern-table" style="table-layout: fixed; width: 100%;">
        <thead>
            <tr>
                <th style="width: 58%;">Lines of Business</th>
                <th style="width: 21%; text-align: right;">Revenue Score</th>
                <th style="width: 21%; text-align: right;">EBITDA Score</th>
            </tr>
        </thead>
        <tbody>
            {% for division in divisions %}
            {% set row = scores_by_division.get(division, {}) %}
            <tr>
                <td><strong>{{ division }}</strong></td>
                <td style="text-align: right;"><input type="number" name="revenue_score__{{ division }}" class="modern-input" step="0.01" min="1" max="5" value="{{ row.get('revenue_score', '') }}" placeholder="1.00 - 5.00" style="display: inline-block !important; width: 150px !important; max-width: 150px !important; margin: 0 0 0 auto !important; text-align: center;"></td>
                <td style="text-align: right;"><input type="number" name="ebitda_score__{{ division }}" class="modern-input" step="0.01" min="1" max="5" value="{{ row.get('ebitda_score', '') }}" placeholder="1.00 - 5.00" style="display: inline-block !important; width: 150px !important; max-width: 150px !important; margin: 0 0 0 auto !important; text-align: center;"></td>
            </tr>
            {% endfor %}
        </tbody>
    </table>
    </div>

    <div class="button-group">
        <a href="{{ url_for('performance_dashboard') }}" class="btn-secondary">Back</a>
        <button type="submit" class="btn-primary">Save Scores</button>
    </div>
</form>
{% endblock %}
''')


@app.route('/division_revenue_ebitda_admin', methods=['GET', 'POST'])
def division_revenue_ebitda_admin_page():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    employee_id = str(session.get('employee_id', '')).strip()
    if not is_super_admin_employee(employee_id):
        flash("You do not have permission to access Shared KPI Scores.", 'error')
        return redirect(url_for('profile_page'))

    selected_year = resolve_eval_year_from_request()
    if request.method == 'POST':
        selected_year = safe_int(request.form.get('eval_year'), selected_year)
        scores_by_division = _default_division_revenue_ebitda_scores()
        group_score = str(request.form.get('group_score', '') or '').strip()
        validation_errors: List[str] = []
        if group_score:
            numeric = safe_float(group_score, -1.0)
            if numeric <= 0 or numeric > 5:
                validation_errors.append("Group Shared KPI score must be between 1.00 and 5.00.")
        for division in DIVISION_REVENUE_EBITDA_TARGET_DIVISIONS:
            revenue_score = str(request.form.get(f'revenue_score__{division}', '') or '').strip()
            ebitda_score = str(request.form.get(f'ebitda_score__{division}', '') or '').strip()
            for label, raw_value in [('Revenue', revenue_score), ('EBITDA', ebitda_score)]:
                if raw_value:
                    numeric = safe_float(raw_value, -1.0)
                    if numeric <= 0 or numeric > 5:
                        validation_errors.append(f"{division}: {label} score must be between 1.00 and 5.00.")
            scores_by_division[division]['revenue_score'] = revenue_score
            scores_by_division[division]['ebitda_score'] = ebitda_score
        if validation_errors:
            for message in validation_errors:
                flash(message, 'error')
        else:
            group_saved = save_form_data_to_db_yearly(
                GLOBAL_GROUP_KPI_EMPLOYEE_ID[0],
                'group_kpi',
                selected_year,
                {
                    'group_score': group_score,
                    'group_weight': '0',
                    'group_result': '0.00',
                    'group_desc': 'Group Shared KPI',
                }
            )
            lob_saved = save_division_revenue_ebitda_scores(selected_year, scores_by_division)
            if group_saved and lob_saved:
                flash("Group Shared KPI, Revenue, and EBITDA scores saved successfully.", 'success')
            else:
                flash("Could not save one or more admin-managed scores. Please try again.", 'error')

    baseline_year = 2026
    current_year = max(get_current_fiscal_year(), baseline_year)
    available_years = [y for y in list_summary_years(employee_id) if y >= baseline_year]
    for y in (selected_year, current_year, baseline_year):
        if y not in available_years:
            available_years.insert(0, y)
    available_years = sorted(set(available_years), reverse=True)
    nav_html = get_nav_html('profile_page', session.get('job_level'), session.get('full_name', 'N/A'))
    return render_template_string(
        DIVISION_REVENUE_EBITDA_ADMIN_TEMPLATE,
        nav_html=nav_html,
        page_title='Shared KPI Scores',
        divisions=list(DIVISION_REVENUE_EBITDA_TARGET_DIVISIONS),
        scores_by_division=load_division_revenue_ebitda_scores(selected_year),
        group_kpi_companies=sorted(ADMIN_MANAGED_GROUP_KPI_COMPANIES),
        group_kpi_score=str((load_form_data_from_db(GLOBAL_GROUP_KPI_EMPLOYEE_ID[0], 'group_kpi', selected_year) or {}).get('group_score', '') or '').strip(),
        available_years=available_years,
        selected_year=selected_year
    )


# PE Score Weighting Distribution Criteria Template
PE_WEIGHTING_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<style>
    .weighting-shell {
        display: grid;
        gap: 24px;
        margin: 30px 0;
    }
    .weighting-card {
        background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);
        border: 1px solid #dbeafe;
        border-radius: 22px;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
        overflow: hidden;
    }
    .weighting-card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
        padding: 22px 24px 14px 24px;
    }
    .weighting-card-title {
        margin: 0;
        color: #0f172a;
        font-size: 1.28rem;
        font-weight: 800;
    }
    .weighting-card-caption {
        margin: 6px 0 0 0;
        color: #64748b;
        font-size: 0.96rem;
        line-height: 1.6;
    }
    .weighting-chip {
        flex-shrink: 0;
        padding: 9px 14px;
        border-radius: 999px;
        background: linear-gradient(135deg, #dbeafe 0%, #eff6ff 100%);
        color: #1d4ed8;
        font-size: 0.84rem;
        font-weight: 800;
        letter-spacing: 0.04em;
        text-transform: uppercase;
    }
    .weighting-table-wrap {
        padding: 0 18px 18px 18px;
        overflow-x: auto;
    }
    .weighting-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        min-width: 860px;
    }
    .weighting-table thead th {
        padding: 14px 12px;
        background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%);
        color: #ffffff;
        font-size: 0.86rem;
        font-weight: 800;
        letter-spacing: 0.02em;
        border-bottom: none;
    }
    .weighting-table thead th:first-child {
        border-top-left-radius: 16px;
    }
    .weighting-table thead th:last-child {
        border-top-right-radius: 16px;
    }
    .weighting-table tbody td {
        padding: 14px 12px;
        border-bottom: 1px solid #dbeafe;
        background: rgba(255, 255, 255, 0.96);
        color: #0f172a;
        font-size: 0.96rem;
    }
    .weighting-table tbody tr:nth-child(even) td {
        background: #f8fbff;
    }
    .weighting-table tbody tr:hover td {
        background: #eef6ff;
    }
    .weighting-level {
        font-weight: 800;
        color: #1e3a8a;
        white-space: nowrap;
    }
    .weighting-percent {
        display: inline-flex;
        min-width: 56px;
        justify-content: center;
        padding: 7px 10px;
        border-radius: 999px;
        background: #eff6ff;
        color: #1d4ed8;
        font-weight: 800;
    }
    .weighting-percent.muted {
        background: #f1f5f9;
        color: #64748b;
    }
    .weighting-total {
        display: inline-flex;
        min-width: 72px;
        justify-content: center;
        padding: 7px 12px;
        border-radius: 999px;
        background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
        color: #1e3a8a;
        font-weight: 900;
    }
    @media (max-width: 768px) {
        .weighting-card-header {
            flex-direction: column;
            align-items: flex-start;
        }
    }
</style>

<div class="header-section">
    <h1 class="gradient-text">PE Score Weighting Distribution Guideline</h1>
    <p>Understanding performance evaluation score distribution across job levels</p>
</div>

<div class="weighting-shell">
    <section class="weighting-card">
        <div class="weighting-card-header">
            <div>
                <h2 class="weighting-card-title">KPI Weight Distribution Matrix by Job Level</h2>
                <p class="weighting-card-caption">Reference matrix for how KPI components are distributed across each job-level group.</p>
            </div>
            <div class="weighting-chip">Fixed Allocation</div>
        </div>
        <div class="weighting-table-wrap">
            <table class="weighting-table">
                <thead>
                    <tr style="text-align: center;">
                        <th style="text-align: left;">Job Level</th>
                        <th style="text-align: center;">Group Shared KPI</th>
                        <th style="text-align: center;">BU/LoB Shared KPI</th>
                        <th style="text-align: center;">Org. Cap. Dev.</th>
                        <th style="text-align: center;">People Dev.</th>
                        <th style="text-align: center;">BU Objectives</th>
                        <th style="text-align: center;">Total Weight</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><span class="weighting-level">12 & higher</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">20%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">30%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">10%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">10%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">30%</span></td>
                        <td style="text-align: center;"><span class="weighting-total">100%</span></td>
                    </tr>
                    <tr>
                        <td><span class="weighting-level">10-11</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">15%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">20%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">10%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">10%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">45%</span></td>
                        <td style="text-align: center;"><span class="weighting-total">100%</span></td>
                    </tr>
                    <tr>
                        <td><span class="weighting-level">8-9</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">10%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">10%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">5%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">5%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">70%</span></td>
                        <td style="text-align: center;"><span class="weighting-total">100%</span></td>
                    </tr>
                    <tr>
                        <td><span class="weighting-level">4-7</span></td>
                        <td style="text-align: center;"><span class="weighting-percent muted">0%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent muted">0%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">5%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent muted">0%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">95%</span></td>
                        <td style="text-align: center;"><span class="weighting-total">100%</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </section>

    <section class="weighting-card">
        <div class="weighting-card-header">
            <div>
                <h2 class="weighting-card-title">KPI and Behavior Weight Distribution by Job Level</h2>
                <p class="weighting-card-caption">High-level split between KPI results and behavior assessment for each evaluation group.</p>
            </div>
            <div class="weighting-chip">Final Mix</div>
        </div>
        <div class="weighting-table-wrap">
            <table class="weighting-table" style="min-width: 720px;">
                <thead>
                    <tr>
                        <th>Job Level</th>
                        <th style="text-align: center;">Performance KPI</th>
                        <th style="text-align: center;">Core Behaviors</th>
                        <th style="text-align: center;">Leadership Behaviors</th>
                        <th style="text-align: center;">Total Weight</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><span class="weighting-level">12 & higher</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">95%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent muted">-</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">5%</span></td>
                        <td style="text-align: center;"><span class="weighting-total">100%</span></td>
                    </tr>
                    <tr>
                        <td><span class="weighting-level">10-11</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">90%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">5%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">5%</span></td>
                        <td style="text-align: center;"><span class="weighting-total">100%</span></td>
                    </tr>
                    <tr>
                        <td><span class="weighting-level">8-9</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">80%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">15%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">5%</span></td>
                        <td style="text-align: center;"><span class="weighting-total">100%</span></td>
                    </tr>
                    <tr>
                        <td><span class="weighting-level">4-7</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">70%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent">30%</span></td>
                        <td style="text-align: center;"><span class="weighting-percent muted">-</span></td>
                        <td style="text-align: center;"><span class="weighting-total">100%</span></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </section>
</div>

<div class="info-box">
    <div class="info-box-title">Important Notes</div>
    <div class="info-box-text" style="line-height: 2;">
        - <strong>Performance KPI</strong> includes all KPI components: Group Shared KPI, BU/LoB Shared KPI, Organizational Capability Development, People Development, and BU Objectives.<br>
        - <strong>Total weight</strong> across all categories must equal 100%.<br>
        - Weight distribution is <strong>fixed per job level</strong> and cannot be changed.<br>
        - Higher job levels place more emphasis on strategic KPIs and leadership behaviors.
    </div>
</div>

<div class="button-group">
    <a href="{{ next_page_url }}" class="btn-primary">Next -></a>
</div>
{% endblock %}
''')


@app.route('/pe_weighting_page')
def pe_weighting_page():
    """PE Score Weighting Distribution Criteria page."""
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    job_level = session.get('job_level')
    full_name = session.get('full_name', 'N/A')
    nav_html = get_nav_html('pe_weighting_page', job_level, full_name)
    next_page_url = url_for('kpi_measurement_criteria')

    return render_template_string(
        PE_WEIGHTING_TEMPLATE,
        nav_html=nav_html,
        next_page_url=next_page_url,
        page_title="PE Score Weighting Distribution Guideline"
    )


KPI_CRITERIA_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<style>
    .criteria-card {
        background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);
        border: 1px solid #dbeafe;
        border-radius: 22px;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.08);
        overflow: hidden;
        margin: 30px 0;
    }
    .criteria-card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 16px;
        padding: 22px 24px 14px 24px;
    }
    .criteria-card-title {
        margin: 0;
        color: #0f172a;
        font-size: 1.28rem;
        font-weight: 800;
    }
    .criteria-card-caption {
        margin: 6px 0 0 0;
        color: #64748b;
        font-size: 0.96rem;
        line-height: 1.6;
    }
    .criteria-chip {
        flex-shrink: 0;
        padding: 9px 14px;
        border-radius: 999px;
        background: linear-gradient(135deg, #dbeafe 0%, #eff6ff 100%);
        color: #1d4ed8;
        font-size: 0.84rem;
        font-weight: 800;
        letter-spacing: 0.04em;
        text-transform: uppercase;
    }
    .criteria-table-wrap {
        padding: 0 18px 18px 18px;
        overflow-x: auto;
    }
    .criteria-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        min-width: 760px;
    }
    .criteria-table thead th {
        padding: 14px 12px;
        background: linear-gradient(135deg, #1e3a8a 0%, #2563eb 100%);
        color: #ffffff;
        font-size: 0.86rem;
        font-weight: 800;
        letter-spacing: 0.02em;
        border-bottom: none;
    }
    .criteria-table thead th:first-child {
        border-top-left-radius: 16px;
    }
    .criteria-table thead th:last-child {
        border-top-right-radius: 16px;
    }
    .criteria-table tbody td {
        padding: 14px 12px;
        border-bottom: 1px solid #dbeafe;
        background: rgba(255, 255, 255, 0.96);
        color: #0f172a;
        font-size: 0.96rem;
        vertical-align: top;
    }
    .criteria-table tbody tr:not(.criteria-subrow) td {
        background: #ffffff;
        border-top: 12px solid #f1f7ff;
    }
    .criteria-table tbody tr:first-child td {
        border-top: none;
    }
    .criteria-table tbody tr:hover td {
        background: #eef6ff;
    }
    .criteria-rating {
        display: inline-flex;
        padding: 8px 12px;
        border-radius: 999px;
        background: #eff6ff;
        color: #1d4ed8;
        font-weight: 900;
        white-space: nowrap;
    }
    .criteria-achievement {
        display: inline-flex;
        min-width: 76px;
        justify-content: center;
        padding: 8px 12px;
        border-radius: 999px;
        background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
        color: #1e3a8a;
        font-weight: 900;
    }
    .criteria-subrow td {
        color: #475569;
        font-size: 0.92rem;
        background: #eef6ff !important;
    }
    @media (max-width: 768px) {
        .criteria-card-header {
            flex-direction: column;
            align-items: flex-start;
        }
    }
</style>

<div class="header-section">
    <h1 class="gradient-text">KPI Measurement Criteria</h1>
    <p>Understanding KPI scoring and evaluation standards</p>
</div>

<section class="criteria-card">
    <div class="criteria-card-header">
        <div>
            <h2 class="criteria-card-title">Performance KPI Rating Scale (1-5)</h2>
            <p class="criteria-card-caption">Use this table as the common KPI scoring reference before entering KPI scores on the evaluation forms.</p>
        </div>
        <div class="criteria-chip">Standard Scale</div>
    </div>
    <div class="criteria-table-wrap">
        <table class="criteria-table">
            <thead>
                <tr>
                    <th>Rating</th>
                    <th>Description</th>
                    <th>% of Task Achievement</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><span class="criteria-rating">5 = Outstanding</span></td>
                    <td>Deliver excellent performance outputs outstandingly</td>
                    <td style="text-align:center;"><span class="criteria-achievement">&gt;120%</span></td>
                </tr>
                <tr class="criteria-subrow">
                    <td>Excellent level</td>
                    <td>Performance exceeds required standards significantly and consistently.</td>
                    <td style="text-align:center;">More than 120%</td>
                </tr>
                <tr class="criteria-subrow">
                    <td>ระดับดีเยี่ยม</td>
                    <td>ปฏิบัติงานได้ผลดีเกินมาตรฐานที่กำหนดอย่างมาก</td>
                    <td style="text-align:center;">มากกว่าร้อยละ 120</td>
                </tr>
                <tr>
                    <td><span class="criteria-rating">4 = Very Good</span></td>
                    <td>Deliver superior performance outputs mostly</td>
                    <td style="text-align:center;"><span class="criteria-achievement">101-120%</span></td>
                </tr>
                <tr class="criteria-subrow">
                    <td>Very good level</td>
                    <td>Performance is above the required standard in most situations.</td>
                    <td style="text-align:center;">101-120%</td>
                </tr>
                <tr class="criteria-subrow">
                    <td>ระดับดีมาก</td>
                    <td>ปฏิบัติงานได้ผลดีและส่วนใหญ่สูงกว่ามาตรฐานที่กำหนด</td>
                    <td style="text-align:center;">ร้อยละ 101-120</td>
                </tr>
                <tr>
                    <td><span class="criteria-rating">3 = Good</span></td>
                    <td>Deliver good performance outputs satisfactorily</td>
                    <td style="text-align:center;"><span class="criteria-achievement">86-100%</span></td>
                </tr>
                <tr class="criteria-subrow">
                    <td>Good level</td>
                    <td>Performance meets the expected standard and delivers satisfactory results.</td>
                    <td style="text-align:center;">86-100%</td>
                </tr>
                <tr class="criteria-subrow">
                    <td>ระดับดี</td>
                    <td>ปฏิบัติงานได้ผลตรงตามมาตรฐาน เป็นที่น่าพอใจ</td>
                    <td style="text-align:center;">ร้อยละ 86-100</td>
                </tr>
                <tr>
                    <td><span class="criteria-rating">2 = Fair</span></td>
                    <td>Deliver incomplete performance outputs occasionally</td>
                    <td style="text-align:center;"><span class="criteria-achievement">70-85%</span></td>
                </tr>
                <tr class="criteria-subrow">
                    <td>Fair level</td>
                    <td>Performance is below the expected standard in some areas and needs improvement.</td>
                    <td style="text-align:center;">70-85%</td>
                </tr>
                <tr class="criteria-subrow">
                    <td>ระดับพอใช้</td>
                    <td>ปฏิบัติงานได้ผลน้อยกว่ามาตรฐานที่กำหนด</td>
                    <td style="text-align:center;">ร้อยละ 70-85</td>
                </tr>
                <tr>
                    <td><span class="criteria-rating">1 = Need Improvement</span></td>
                    <td>Deliver defective performance outputs regularly</td>
                    <td style="text-align:center;"><span class="criteria-achievement">&lt;70%</span></td>
                </tr>
                <tr class="criteria-subrow">
                    <td>Needs improvement</td>
                    <td>Performance does not meet the required standard and requires corrective action.</td>
                    <td style="text-align:center;">Less than 70%</td>
                </tr>
                <tr class="criteria-subrow">
                    <td>ควรปรับปรุง</td>
                    <td>ปฏิบัติงานไม่ได้ตามมาตรฐานที่กำหนด ต้องปรับปรุงแก้ไข</td>
                    <td style="text-align:center;">ต่ำกว่าร้อยละ 70</td>
                </tr>
            </tbody>
        </table>
    </div>
</section>

<div class="info-box">
    <div class="info-box-title">Evaluation Guidelines</div>
    <div class="info-box-text" style="line-height: 2;">
        - <strong>All KPI objectives</strong> should be specific, measurable, achievable, relevant, and time-bound (SMART).<br>
        - <strong>Total weight</strong> across all KPI categories must match the assigned percentage for the employee's job level.<br>
        - <strong>Evidence and documentation</strong> should support all KPI ratings.<br>
        - <strong>Feedback should be continuous</strong> throughout the evaluation period, not only at year end.
    </div>
</div>

<div class="button-group">
    <a href="{{ next_page_url }}" class="btn-primary">
        <span style="position: relative; z-index: 1;">Next -></span>
    </a>
</div>
{% endblock %}
''')


@app.route('/kpi_measurement_criteria')
def kpi_measurement_criteria():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    job_level = session.get('job_level')
    full_name = session.get('full_name', 'N/A')
    nav_html = get_nav_html('kpi_measurement_criteria', job_level, full_name)

    # Determine next page based on job level
    disabled_buttons = get_disabled_buttons(job_level)
    if 'group_kpi_page' not in disabled_buttons:
        next_page_url = url_for('group_kpi_page')
    elif 'bu_lob_kpi_page' not in disabled_buttons:
        next_page_url = url_for('bu_lob_kpi_page')
    else:
        next_page_url = url_for('org_capability_page')

    return render_template_string(KPI_CRITERIA_TEMPLATE, nav_html=nav_html, next_page_url=next_page_url,
                                  page_title="KPI Measurement Criteria")


RATING_CRITERIA_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<div class="header-section">
    <h1 class="gradient-text">Behavior Rating Criteria</h1>
    <p>Behavioral competency rating guidelines</p>
</div>

<div style="margin: 30px 0;">
    <h2 class="gradient-text" style="font-size: 1.5em; margin-bottom: 15px;">Behavior Assessment Framework</h2>
    <div class="info-box">
        <div class="info-box-title">How Behavior Rating Works Now</div>
        <div class="info-box-text" style="line-height: 1.9;">
            Behavior criteria are no longer based on one universal rating table. Each employee is assigned a behavior set by
            <strong>job level group</strong>, and each group has its own <strong>behavior dimensions</strong> and
            <strong>rating scale definitions</strong>. Users should always read the rating guideline shown under each behavior
            on the form before selecting a score.
        </div>
    </div>
</div>

<div style="margin: 30px 0;">
    <h2 class="gradient-text" style="font-size: 1.5em; margin-bottom: 15px;">Job Level Group Mapping</h2>
    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px;">
        <div class="content-card" style="margin:0; border:1px solid #dbeafe; background: linear-gradient(135deg, #eff6ff 0%, #ffffff 100%);">
            <h3 style="margin:0 0 10px 0; color:#1e3a8a; font-size:1.1em;">Job Level 4-7</h3>
            <p style="margin:0; color:#334155; line-height:1.8;">
                Core Behaviors are assigned from the level 4-7 behavior set. Ratings must follow the definition shown under
                each individual behavior.
            </p>
        </div>
        <div class="content-card" style="margin:0; border:1px solid #dbeafe; background: linear-gradient(135deg, #eff6ff 0%, #ffffff 100%);">
            <h3 style="margin:0 0 10px 0; color:#1e3a8a; font-size:1.1em;">Job Level 8 and Higher</h3>
            <p style="margin:0; color:#334155; line-height:1.8;">
                Core Behaviors and Leadership Behaviors are assigned according to the employee's job level group. Both sections
                use group-specific dimensions and group-specific rating definitions, so users must read the guidance shown under
                each behavior before selecting a score.
            </p>
        </div>
    </div>
</div>

<div class="info-box">
    <div class="info-box-title">Rating Guidelines</div>
    <div class="info-box-text" style="line-height: 2;">
        - <strong>Use the behavior-specific guideline</strong> shown under each dimension on the form<br>
        - <strong>Rate based on evidence</strong> from actual performance during the evaluation year<br>
        - <strong>Consider consistency and impact</strong>, not isolated incidents only<br>
        - <strong>Apply the definition that best matches observed behavior</strong> for that specific job level group<br>
        - <strong>Do not rely on one universal 1-5 meaning</strong>, because each group now has its own criteria<br>
        - <strong>Missing scores mean the form is incomplete</strong> and should be reviewed before final submission
    </div>
</div>

<div style="background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); color: white; padding: 30px; border-radius: 12px; margin: 30px 0;">
    <h3 style="color: white; margin: 0 0 14px 0; font-size: 1.4em;">Assessment Reminder</h3>
    <p style="font-size: 1.05em; margin: 0; line-height: 1.9;">
        Employees may not see the same behavior set. Core Behaviors and Leadership Behaviors are assigned according to job
        level group, and the score should always follow the detailed rating guidance shown on each form item.
    </p>
</div>

<div class="button-group">
    <a href="{{ next_page_url }}" class="btn-primary">
        <span style="position: relative; z-index: 1;">Next -></span>
    </a>
</div>
{% endblock %}
''')


@app.route('/rating_criteria')
def rating_criteria():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    job_level = session.get('job_level')
    full_name = session.get('full_name', 'N/A')
    nav_html = get_nav_html('rating_criteria', job_level, full_name)

    # Determine next page based on job level
    disabled_buttons = get_disabled_buttons(job_level)
    if 'core_behaviors_page' not in disabled_buttons:
        next_page_url = url_for('core_behaviors_page')
    elif 'leadership_behaviors_page' not in disabled_buttons:
        next_page_url = url_for('leadership_behaviors_page')
    else:
        next_page_url = url_for('comments_page')

    return render_template_string(RATING_CRITERIA_TEMPLATE, nav_html=nav_html, next_page_url=next_page_url,
                                  page_title="Behavior Rating Criteria")


# KPI Form Template with STRICT Weight Blocking and Score Validation
KPI_FORM_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<div class="header-section">
    <h1 class="gradient-text">{{ page_title }}</h1>
    <p>{{ page_description }}</p>
</div>
{% if eval_year %}
<div class="alert-info" style="margin-bottom: 15px;">
    Fiscal Year: <strong>{{ eval_year }}</strong>
</div>
{% endif %}
{% if is_locked %}
<div class="alert-warning" style="margin-bottom: 15px;">
    This fiscal year is locked for editing. You can review the saved details, but changes are no longer allowed after {{ lock_date_text }}.
</div>
{% endif %}
{% if is_fixed_bu_lob_mode %}
<div class="alert-info" style="margin-bottom: 15px;">
    Revenue and EBITDA raw scores on this page are managed by super admin and are read-only for employees.
</div>
{% endif %}
{% if is_locked %}
<div class="alert-warning" style="margin-bottom: 15px;">
    This fiscal year is locked for editing. You can review the saved details, but changes are no longer allowed after {{ lock_date_text }}.
</div>
{% endif %}

<form method="POST" action="{{ url_for('save_form_data') }}" id="kpiForm" data-weight-limit="{{ weight_limit }}">
    <input type="hidden" name="form_id" value="{{ form_id }}">
    <input type="hidden" name="next_page" value="{{ next_page }}">
    <input type="hidden" name="eval_year" value="{{ eval_year if eval_year is defined else session.eval_year }}">
    <fieldset {% if is_locked %}disabled{% endif %} style="border: 0; padding: 0; margin: 0; min-width: 0;">

    <div class="alert-warning" id="weightLimitInfo">
        <strong>Weight Limit:</strong> Maximum total weight for this section is <strong>{{ weight_limit }}%</strong> for your job level ({{ session.job_level }}).
        <br><span id="currentWeightDisplay" style="font-weight: bold; font-size: 1.1em;"></span>
    </div>

    <div class="alert-warning" style="margin-top: 15px;">
        <strong>📝 Score Requirements:</strong><br>
        • Scores must be between 1.00 and 5.00 only.<br>
        • Zero (0) is NOT allowed.<br>
        • Values greater than 5 are NOT allowed.
    </div>
    <table class="modern-table">
        <thead>
            <tr>
                <th style="width: {{ '20%' if is_fixed_bu_lob_mode else '33%' }};">Description</th>
                <th style="width: {{ '11%' if is_fixed_bu_lob_mode else '9%' }};text-align: center;">1</th>
                <th style="width: {{ '11%' if is_fixed_bu_lob_mode else '9%' }};text-align: center;">2</th>
                <th style="width: {{ '11%' if is_fixed_bu_lob_mode else '9%' }};text-align: center;">3</th>
                <th style="width: {{ '11%' if is_fixed_bu_lob_mode else '9%' }};text-align: center;">4</th>
                <th style="width: {{ '11%' if is_fixed_bu_lob_mode else '9%' }};text-align: center;">5</th>
                <th style="width: 7%;text-align: center;">Weight (%)</th>
                <th style="width: 7%;text-align: center;">Score (1-5)</th>
                <th style="width: 7%;text-align: center;">Result</th>
            </tr>
        </thead>
        <tbody id="kpiTableBody">
            {% for i in range(num_rows) %}
            <tr>
                <td>
                    <textarea name="desc_{{ i }}" class="modern-textarea" rows="1" placeholder="Enter description" style="width: 100%; resize: vertical; {% if is_fixed_bu_lob_mode %}background: #f8fafc;{% endif %}" {% if is_fixed_bu_lob_mode %}readonly{% endif %}>{{ saved_data.descriptions[i] if saved_data and i < saved_data.descriptions|length else '' }}</textarea>
                </td>

                {% set row_short_descs = short_desc_data[i] if short_desc_data and i < short_desc_data|length else [] %}
                {% for j in range(5) %}
                <td>
                    <textarea name="short_desc_{{ i }}_{{ j }}"
                              class="modern-textarea short-desc-input"
                              placeholder="{{ j + 1 }}"
                              rows="1"
                              style="{% if is_fixed_bu_lob_mode %}background: #f8fafc; white-space: nowrap; overflow-x: auto; font-size: 0.95rem;{% endif %}"
                              {% if is_fixed_bu_lob_mode %}wrap="off"{% endif %}
                              {% if is_fixed_bu_lob_mode %}readonly{% endif %}>{{ row_short_descs[j] if row_short_descs and j < row_short_descs|length else '' }}</textarea>
                </td>
                {% endfor %}

                <td>
                    <input type="number" name="weight_{{ i }}" class="modern-input weight-input" step="0.01" min="0" max="{{ weight_limit }}" value="{{ saved_data.weights[i] if saved_data and i < saved_data.weights|length else '' }}" placeholder="0.00" {% if is_fixed_bu_lob_mode %}readonly style="background: #f8fafc;"{% endif %}>
                </td>

                <td>
                    <input type="number" name="score_{{ i }}" class="modern-input score-input" step="0.01" min="1" max="5" value="{{ saved_data.scores[i] if saved_data and i < saved_data.scores|length else '' }}" placeholder="1.00" {% if is_fixed_bu_lob_mode %}readonly style="background: #f8fafc;"{% endif %}>
                </td>

                <td>
                    <input type="text" class="modern-input result-display" readonly value="{{ saved_data.results[i] if saved_data and i < saved_data.results|length else '0.00' }}" style="background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);">
                </td>
            </tr>
            {% endfor %}
        </tbody>
        <tfoot>
            <tr style="background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%);">
                <td colspan="9" style="text-align: right;">
                    <strong>Total Weight:</strong>
                    <input type="text" id="totalWeight" class="modern-input" readonly value="0.00" style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%); font-weight: bold; width: 100px; display: inline-block; margin: 0 10px;">
                    <strong>Total Score:</strong>
                    <input type="text" id="totalScore" class="modern-input" readonly value="{{ saved_data.total_score if saved_data else '0.00' }}" style="background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%); font-weight: bold; width: 100px; display: inline-block; margin: 0 10px;">
                </td>
            </tr>
        </tfoot>
    </table>

    <div id="weightWarning" class="alert-error" style="display: none; margin-top: 20px;">
        <strong>⚠️ BLOCKED:</strong> Total weight exceeds the limit! Weights over {{ weight_limit }}% have been removed. Please adjust to exactly {{ weight_limit }}% or less to save.
    </div>

    <div class="button-group">
        {% if not is_locked and not is_fixed_bu_lob_mode %}
        <button type="submit" name="action" value="save" class="btn-primary" id="saveBtn">Save Progress</button>
        <button type="submit" name="action" value="save_next" class="btn-success" id="saveNextBtn">
            <span style="position: relative; z-index: 1;">Save & Next →</span>
        </a>
        {% else %}
        <a href="{{ url_for('summary_page') }}" class="btn-primary">
            <span style="position: relative; z-index: 1;">Next -></span>
        </a>
        {% endif %}
    </div>
    </fieldset>
</form>

<script>
const weightLimit = {{ weight_limit }};
const weightInputs = document.querySelectorAll('.weight-input');
const scoreInputs = document.querySelectorAll('.score-input');
const resultDisplays = document.querySelectorAll('.result-display');
const totalWeightDisplay = document.getElementById('totalWeight');
const totalScoreDisplay = document.getElementById('totalScore');
const weightWarning = document.getElementById('weightWarning');
const currentWeightDisplay = document.getElementById('currentWeightDisplay');
const form = document.getElementById('kpiForm');
function autoResize(textarea) {
    if (!textarea) return;
    textarea.style.height = 'auto';
    textarea.style.height = `${textarea.scrollHeight}px`;
}

function initAutoResizers() {
    const textareas = document.querySelectorAll('.modern-textarea');
    textareas.forEach(textarea => {
        if (!textarea.dataset.autoresizeBound) {
            textarea.addEventListener('input', () => autoResize(textarea));
            textarea.dataset.autoresizeBound = '1';
        }
        autoResize(textarea);
    });
}

// Helper to run multiple times in case layout finishes later
function scheduleAutoResizers() {
    initAutoResizers();
    setTimeout(initAutoResizers, 50);
    setTimeout(initAutoResizers, 150);
    setTimeout(initAutoResizers, 400);
}

// Keep textareas expanded on any navigation/back/resize loads
window.addEventListener('DOMContentLoaded', scheduleAutoResizers);
window.addEventListener('pageshow', scheduleAutoResizers);
window.addEventListener('load', () => {
    scheduleAutoResizers();
    setTimeout(scheduleAutoResizers, 800);
});
window.addEventListener('resize', () => requestAnimationFrame(scheduleAutoResizers));

// Observe soft-nav content swaps to re-run autoresize when DOM changes
const mainContentEl = document.querySelector('.main-content');
if (mainContentEl) {
    const resizeObserver = new MutationObserver(() => scheduleAutoResizers());
    resizeObserver.observe(mainContentEl, { childList: true, subtree: true });
    window.addEventListener('unload', () => resizeObserver.disconnect(), { once: true });
}

// Expose recompute hook for soft navigation swaps
window.recomputePage = scheduleAutoResizers;

// Validate score input - BLOCK 0 and >5
scoreInputs.forEach(scoreInput => {
    scoreInput.addEventListener('input', function() {
        let value = parseFloat(this.value);

        // Block 0 immediately
        if (value === 0) {
            this.value = '';
            alert('Score cannot be 0. Please enter a value between 1.00 and 5.00');
            return;
        }

        // Block values > 5
        if (value > 5) {
            this.value = '5';
            alert('Score cannot exceed 5.00. Maximum score is 5.00');
            calculateTotals();
            return;
        }

        // Block values < 1 (but allow empty)
        if (value < 1 && this.value !== '') {
            this.value = '1';
            alert('Score cannot be less than 1.00. Minimum score is 1.00');
            calculateTotals();
            return;
        }

        calculateTotals();
    });

    // Also validate on blur
    scoreInput.addEventListener('blur', function() {
        if (this.value && parseFloat(this.value) < 1) {
            this.value = '1';
            calculateTotals();
        }
    });
});

// Validate weight input - BLOCK exceeding limit
weightInputs.forEach(weightInput => {
    weightInput.addEventListener('input', function() {
        calculateTotals();

        // Check if total exceeds limit and block
        const totalWeight = parseFloat(totalWeightDisplay.value) || 0;
        if (totalWeight > weightLimit) {
            // Remove the excess from this input
            const currentValue = parseFloat(this.value) || 0;
            const excess = totalWeight - weightLimit;
            const newValue = Math.max(0, currentValue - excess);
            this.value = newValue.toFixed(2);

            weightWarning.style.display = 'block';
            alert(`Total weight cannot exceed ${weightLimit}%. The excess has been automatically removed.`);

            calculateTotals();
        }
    });
});

function calculateTotals() {
    let totalWeight = 0;
    let totalScore = 0;

    weightInputs.forEach((weightInput, index) => {
        const weight = parseFloat(weightInput.value) || 0;
        const score = parseFloat(scoreInputs[index].value) || 0;

        // Validate score is in range 1-5 (0 not allowed)
        if (score > 0 && (score < 1 || score > 5)) {
            scoreInputs[index].value = '';
            return;
        }

        const result = (weight * score) / 100;

        resultDisplays[index].value = result.toFixed(2);
        totalWeight += weight;
        totalScore += result;
    });

    totalWeightDisplay.value = totalWeight.toFixed(2);
    totalScoreDisplay.value = totalScore.toFixed(2);

    // Show warning/status
    if (totalWeight > weightLimit) {
        weightWarning.style.display = 'block';
        currentWeightDisplay.innerHTML = `Current Total: <span style="color: #dc2626;">${totalWeight.toFixed(2)}%</span> (Exceeds limit - BLOCKED!)`;
        totalWeightDisplay.style.background = 'linear-gradient(135deg, #fee2e2 0%, #fecaca 100%)';
        totalWeightDisplay.style.color = '#dc2626';
    } else if (totalWeight === weightLimit) {
        weightWarning.style.display = 'none';
        currentWeightDisplay.innerHTML = `Current Total: <span style="color: #16a34a;">${totalWeight.toFixed(2)}%</span> (Exact limit - Perfect!)`;
        totalWeightDisplay.style.background = 'linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%)';
        totalWeightDisplay.style.color = '#16a34a';
    } else {
        weightWarning.style.display = 'none';
        const remaining = weightLimit - totalWeight;
        currentWeightDisplay.innerHTML = `Current Total: <span style="color: #3b82f6;">${totalWeight.toFixed(2)}%</span> (${remaining.toFixed(2)}% remaining)`;
        totalWeightDisplay.style.background = 'linear-gradient(135deg, #fef3c7 0%, #fde68a 100%)';
        totalWeightDisplay.style.color = '#000';
    }
}

// BLOCK form submission if weight exceeds limit OR invalid scores
form.addEventListener('submit', function(e) {
    const totalWeight = parseFloat(totalWeightDisplay.value) || 0;

    // Check weight limit
    if (totalWeight > weightLimit) {
        e.preventDefault();
        alert(`BLOCKED: Total weight (${totalWeight.toFixed(2)}%) exceeds the limit of ${weightLimit}%. Please reduce weights to ${weightLimit}% or less.`);
        weightWarning.style.display = 'block';
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return false;
    }

    // Check all scores are valid (1-5, no 0, no >5)
    let invalidScore = false;
    scoreInputs.forEach(input => {
        if (input.value) {
            const score = parseFloat(input.value);
            if (score === 0 || score < 1 || score > 5) {
                invalidScore = true;
            }
        }
    });

    if (invalidScore) {
        e.preventDefault();
        alert('BLOCKED: One or more scores are invalid. Scores must be between 1.00 and 5.00 (0 is not allowed).');
        return false;
    }

    return true;
});

// Calculate on page load
calculateTotals();
</script>
{% endblock %}
''')


@app.route('/group_kpi_page')
def group_kpi_page():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    eval_year = resolve_eval_year_from_request()
    employee_id = session.get('employee_id', '')  # Default to empty string
    job_level = safe_int(session.get('job_level'), 0)  # Use safe_int for type safety
    full_name = session.get('full_name', 'N/A')

    # Redirect if job level cannot access this page
    if job_level <= 7:
        return redirect(url_for('org_capability_page'))

    # FIXED weight by job level - NOT user input
    # job_level is already safely converted to int above
    if job_level <= 0:  # Invalid or unset job level
        group_weight = 0
    elif 8 <= job_level <= 9:
        group_weight = 10
    elif 10 <= job_level <= 11:
        group_weight = 15
    elif 12 <= job_level <= 15:
        group_weight = 20
    else:
        group_weight = 0

    saved_data = get_form_data('group_kpi')
    nav_html = get_nav_html('group_kpi_page', job_level, full_name)

    # Determine next page
    next_page = 'bu_lob_kpi_page'

    return render_template_string(GROUP_KPI_TEMPLATE,
                                  saved_data=saved_data,
                                  group_weight=group_weight,
                                  nav_html=nav_html,
                                  eval_year=eval_year,
                                  next_page=next_page,
                                  page_title="Group Shared KPI")


# Use simple group KPI template with FIXED weight
GROUP_KPI_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<div class="header-section">
    <h1 class="gradient-text">Group Shared KPI</h1>
    <p>Company-wide key performance indicators</p>
</div>

{% if eval_year %}
<div class="alert-info" style="margin-bottom: 15px;">
    Fiscal Year: <strong>{{ eval_year }}</strong>
</div>
{% endif %}                                           

<form method="POST" action="{{ url_for('save_form_data') }}" id="groupKpiForm">
    <input type="hidden" name="form_id" value="group_kpi">
    <input type="hidden" name="next_page" value="{{ next_page }}">
    <input type="hidden" name="eval_year" value="{{ eval_year if eval_year is defined else session.eval_year }}">
    <input type="hidden" name="group_weight" value="{{ group_weight }}">

    <div class="info-box">
        <div class="info-box-title">📊 Fixed Weight Assignment</div>
        <div class="info-box-text">
            Group Shared KPI has a <strong>fixed weight of {{ group_weight }}%</strong> for your job level ({{ session.job_level }}). This cannot be changed.
        </div>
    </div>

    <div class="alert-info" style="margin-top: 10px;">
        Scores on this page are maintained from <strong>Shared KPI Scores</strong>. The assigned score below is read-only.
    </div>

    <div class="alert-warning" style="margin-top: 15px;">
        <strong>📝 Score Requirements:</strong><br>
        • Scores must be between 1.00 and 5.00 only.<br>
        • Zero (0) is NOT allowed.<br>
        • Values greater than 5 are NOT allowed.
    </div>

    <table class="modern-table">
        <thead>
            <tr>
                <th style="width: 75%;">Description</th>
                <th style="width: 8%;text-align: center;">Weight (%)</th>
                <th style="width: 9%;text-align: center;">Score (1-5)</th>
                <th style="width: 8%;text-align: center;">Result</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><strong>Group Shared KPI</strong></td>
                <td>
                    <input type="text" readonly value="{{ group_weight }}" class="modern-input group-weight-display" style="background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); text-align: center; font-weight: bold;">
                </td>
                <td>
                    <input type="text" id="group_score" class="modern-input" value="{{ saved_data.group_score if saved_data else '' }}" readonly style="background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); text-align: center; font-weight: bold;">
                </td>
                <td>
                    <input type="text" id="group_result" class="modern-input" readonly value="{{ saved_data.group_result if saved_data else '0.00' }}" style="background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%); font-weight: bold;">
                </td>
            </tr>
        </tbody>
    </table>

    <div class="button-group">
        <a href="{{ url_for('profile_page') }}" class="btn-secondary">Back</a>
        <a href="{{ url_for(next_page) }}" class="btn-primary">
            <span style="position: relative; z-index: 1;">Next -></span>
        </a>
    </div>
</form>

{% endblock %}
''')







@app.route('/bu_lob_kpi_page')
def bu_lob_kpi_page():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    eval_year = resolve_eval_year_from_request()
    job_level = session.get('job_level')
    division = session.get('division', '')
    company = session.get('company', '')
    full_name = session.get('full_name', 'N/A')
    weight_limit = get_weight_limit('bu_lob_kpi', job_level)
    saved_data = get_form_data('bu_lob_kpi')
    nav_html = get_nav_html('bu_lob_kpi_page', job_level, full_name)
    is_fixed_bu_lob_mode = is_fixed_bu_lob_user(job_level, division, company)
    
    # Extract short_descriptions for template
    short_desc_data = saved_data.get('short_descriptions', []) if saved_data else []

    return render_template_string(KPI_FORM_TEMPLATE,
                                  page_title="BU/LoB Shared KPI",
                                  page_description="Business Unit / Line of Business key performance indicators",
                                  form_id='bu_lob_kpi',
                                  num_rows=2 if is_fixed_bu_lob_mode else 5,
                                  is_fixed_bu_lob_mode=is_fixed_bu_lob_mode,
                                  eval_year=eval_year,
                                  saved_data=saved_data,
                                  short_desc_data=short_desc_data,
                                  weight_limit=weight_limit,
                                  nav_html=nav_html,
                                  next_page='org_capability_page')


@app.route('/org_capability_page')
def org_capability_page():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    eval_year = resolve_eval_year_from_request()
    job_level = session.get('job_level')
    full_name = session.get('full_name', 'N/A')
    weight_limit = get_weight_limit('org_capability', job_level)
    saved_data = get_form_data('org_capability')
    nav_html = get_nav_html('org_capability_page', job_level, full_name)
    
    # Extract short_descriptions for template
    short_desc_data = saved_data.get('short_descriptions', []) if saved_data else []

    # Determine next page
    disabled_buttons = get_disabled_buttons(job_level)
    if 'people_dev_page' not in disabled_buttons:
        next_page = 'people_dev_page'
    else:
        next_page = 'bu_objectives_page'

    return render_template_string(KPI_FORM_TEMPLATE,
                                  page_title="Organizational Capability Development",
                                  page_description="Skills and capabilities development initiatives",
                                  form_id='org_capability',
                                  num_rows=10,
                                  eval_year=eval_year,
                                  saved_data=saved_data,
                                  short_desc_data=short_desc_data,
                                  weight_limit=weight_limit,
                                  nav_html=nav_html,
                                  next_page=next_page)

@app.route('/people_dev_page')
def people_dev_page():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    eval_year = resolve_eval_year_from_request()
    job_level = session.get('job_level')
    full_name = session.get('full_name', 'N/A')
    weight_limit = get_weight_limit('people_dev', job_level)
    saved_data = get_form_data('people_dev')
    nav_html = get_nav_html('people_dev_page', job_level, full_name)
    
    # Extract short_descriptions for template
    short_desc_data = saved_data.get('short_descriptions', []) if saved_data else []

    return render_template_string(KPI_FORM_TEMPLATE,
                                  page_title="People Development",
                                  page_description="Team member development and mentoring activities",
                                  form_id='people_dev',
                                  num_rows=10,
                                  eval_year=eval_year,
                                  saved_data=saved_data,
                                  short_desc_data=short_desc_data,
                                  weight_limit=weight_limit,
                                  nav_html=nav_html,
                                  next_page='bu_objectives_page')

@app.route('/bu_objectives_page')
def bu_objectives_page():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    eval_year = resolve_eval_year_from_request()
    job_level = session.get('job_level')
    full_name = session.get('full_name', 'N/A')
    weight_limit = get_weight_limit('bu_obj', job_level)
    saved_data = get_form_data('bu_obj')
    nav_html = get_nav_html('bu_objectives_page', job_level, full_name)
    
    # Extract short_descriptions for template
    short_desc_data = saved_data.get('short_descriptions', []) if saved_data else []

    return render_template_string(KPI_FORM_TEMPLATE,
                                  page_title="Business Unit Objectives",
                                  page_description="Individual and team business objectives",
                                  form_id='bu_obj',
                                  num_rows=15,
                                  eval_year=eval_year,
                                  saved_data=saved_data,
                                  short_desc_data=short_desc_data,
                                  weight_limit=weight_limit,
                                  nav_html=nav_html,
                                  next_page='rating_criteria')


# Behavior Templates with Score Validation (1-5 only, no 0, no >5)
BEHAVIORS_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<div class="header-section">
    <h1 class="gradient-text">{{ page_title }}</h1>
    <p>{{ page_description }}</p>
</div>

{% if eval_year %}
<div class="alert-info" style="margin-bottom: 15px;">
    Fiscal Year: <strong>{{ eval_year }}</strong>
</div>
{% endif %}
{% if is_locked %}
<div class="alert-warning" style="margin-bottom: 15px;">
    This fiscal year is locked for editing. You can review the saved details, but changes are no longer allowed after {{ lock_date_text }}.
</div>
{% endif %}

<form method="POST" action="{{ url_for('save_form_data') }}" id="behaviorsForm">
    <input type="hidden" name="form_id" value="{{ form_id }}">
    <input type="hidden" name="next_page" value="{{ next_page }}">
    <input type="hidden" name="eval_year" value="{{ eval_year if eval_year is defined else session.eval_year }}">
    <fieldset {% if is_locked %}disabled{% endif %} style="border: 0; padding: 0; margin: 0; min-width: 0;">

    <div class="alert-warning">
        <strong>Instruction:</strong> Select the score that best reflects the actual behavior on a scale of 0 to 5. If the behavior has not been observed at all, select 0. All ratings are required - don't leave any blank.
    </div>

    <style>
        [data-theme="dark"] .track-meaning-live,
        [data-theme="dark"] .track-meaning-live strong {
            color: #111827 !important;
        }
    </style>

    {% for key, behavior in behaviors_data.items() %}
    <div class="behavior-card">
        <div style="margin-bottom: 15px;">
            <h3 class="gradient-text" style="font-size: 1.2em; margin-bottom: 10px; font-weight: 700;">{{ behavior.title }}</h3>
            {% if behavior.behavior_text %}
            <div class="behavior-desc" style="margin-bottom: 10px; white-space: pre-line;">{{ '\n'.join(behavior.behavior_text.split('\n')[1:]).strip() }}</div>
            {% else %}
            <p class="behavior-desc" style="margin-bottom: 8px;"><strong>English:</strong> {{ behavior.description_en }}</p>
            <p class="behavior-desc"><strong>ภาษาไทย:</strong> {{ behavior.description_th }}</p>
            {% endif %}
        </div>

        {% if behavior.tracks %}
        <div style="display: grid; gap: 12px; margin: 12px 0 16px 0;">
            {% for track in behavior.tracks %}
            <div style="padding: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px;">
                <div style="font-weight: 700; margin-bottom: 8px; color: #1d4ed8;">{{ track.label }}</div>
                {% if track.meaning_text %}
                <div class="behavior-desc track-meaning-live" style="margin-bottom: 10px; white-space: pre-line;"><strong>Meaning:</strong><br>{{ track.meaning_text }}</div>
                {% endif %}
                <div style="font-weight: 600; margin-bottom: 8px; color: #0f172a;">Rating Scale Guidelines</div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 10px;">
                    {% for level_text in track.rating_levels %}
                    <div style="padding: 10px; border: 1px solid #e2e8f0; border-radius: 8px; background: #ffffff;">
                        <div style="font-weight: 600; margin-bottom: 6px; color: #1e3a8a;">Rating {{ loop.index }}</div>
                        <div style="white-space: pre-line; color: #0f172a;">{{ level_text }}</div>
                    </div>
                    {% endfor %}
                </div>
            </div>
            {% endfor %}
        </div>
        {% elif behavior.rating_levels %}
        <div style="margin: 12px 0 16px 0; padding: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px;">
            <div style="font-weight: 600; margin-bottom: 8px; color: #0f172a;">Rating Scale Guidelines</div>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 10px;">
                {% for level_text in behavior.rating_levels %}
                <div style="padding: 10px; border: 1px solid #e2e8f0; border-radius: 8px; background: #ffffff;">
                    <div style="font-weight: 600; margin-bottom: 6px; color: #1e3a8a;">Rating {{ loop.index }}</div>
                    <div style="white-space: pre-line; color: #0f172a;">{{ level_text }}</div>
                </div>
                {% endfor %}
            </div>
        </div>
        {% endif %}

        <div style="display: flex; align-items: center; gap: 15px;">
            <label for="score_{{ key }}" class="modern-label" style="margin: 0;">Rating:</label>
            <select name="score_{{ key }}" id="score_{{ key }}" class="modern-select behavior-select" style="max-width: 100px;">
                <option value="">--</option>
                {% for i in range(0, 6) %}
                <option value="{{ i }}" {% if saved_data and saved_data.scores.get(key|string) == i|string %}selected{% endif %}>{{ i }}</option>
                {% endfor %}
            </select>
        </div>
    </div>
    {% endfor %}

    <div style="background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%); border-left: 4px solid #3b82f6; padding: 20px; border-radius: 12px; margin: 30px 0;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <span style="font-size: 1.1em; font-weight: 600; color: #1e3a8a;">Average Score:</span>
            <span id="averageScore" style="font-size: 1.5em; font-weight: bold; color: #1e3a8a;">0.00</span>
        </div>
    </div>

    <div class="button-group">
        {% if not is_locked %}
        <button type="submit" name="action" value="save" class="btn-primary">Save Progress</button>
        <button type="submit" name="action" value="save_next" class="btn-success">
            <span style="position: relative; z-index: 1;">Save & Next →</span>
        </a>
        {% else %}
        <a href="{{ url_for(next_page) }}" class="btn-primary">
            <span style="position: relative; z-index: 1;">Next -></span>
        </a>
        {% endif %}
    </div>
    </fieldset>
</form>

<script>
// Calculate and display average score
function calculateAverage() {
    const selects = document.querySelectorAll('.behavior-select');
    let total = 0;
    let count = 0;

    selects.forEach(select => {
        const value = parseInt(select.value);
        if (!isNaN(value) && value >= 0 && value <= 5) {
            total += value;
            count++;
        }
    });

    const average = count > 0 ? (total / count).toFixed(2) : '0.00';
    document.getElementById('averageScore').textContent = average;
}

// Update average when any rating changes
document.querySelectorAll('.behavior-select').forEach(select => {
    select.addEventListener('change', function() {
        calculateAverage();
        const value = parseInt(this.value);
        if (!isNaN(value) && value >= 0 && value <= 5) {
            this.style.borderColor = '#e5e7eb';
        }
    });
});

// Calculate on page load
calculateAverage();

// Validate provided ratings are between 0-5 (empty allowed to save progress)
document.getElementById('behaviorsForm').addEventListener('submit', function(e) {
    const selects = document.querySelectorAll('.behavior-select');
    let allValid = true;

    selects.forEach(select => {
        if (!select.value) {
            select.style.borderColor = '#e5e7eb';
            return;
        }

        const value = parseInt(select.value, 10);
        if (isNaN(value) || value < 0 || value > 5) {
            allValid = false;
            select.style.borderColor = '#dc2626';
            alert('Invalid rating detected. All ratings must be between 0 and 5. Blank (--) is allowed and will be excluded from the average.');
        } else {
            select.style.borderColor = '#e5e7eb';
        }
    });

    if (!allValid) {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return false;
    }

    return true;
});
</script>
{% endblock %}
''')


@app.route('/core_behaviors_page')
def core_behaviors_page():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    eval_year = resolve_eval_year_from_request()
    employee_id = session.get('employee_id', '')  # Default to empty string
    job_level = safe_int(session.get('job_level'), 0)  # Safe conversion to int
    full_name = session.get('full_name', 'N/A')

    # Redirect if job level 12+ should see leadership behaviors instead
    if job_level >= 12:
        return redirect(url_for('leadership_behaviors_page'))

    behaviors_to_display = get_core_behaviors_display_map(job_level)

    saved_data = get_form_data('core_behaviors')
    nav_html = get_nav_html('core_behaviors_page', job_level, full_name)
    is_locked = (not can_edit_eval_year(employee_id, eval_year)) or is_employee_self_edit_locked(employee_id, eval_year)

    # Determine next page
    if job_level >= 8:
        next_page = 'leadership_behaviors_page'
    else:
        next_page = 'comments_page'

    return render_template_string(BEHAVIORS_TEMPLATE,
                                  page_title="Core Behaviors",
                                  page_description="Evaluate core competencies and behaviors (Rating: 0-5)",
                                  form_id='core_behaviors',
                                  behaviors_data=behaviors_to_display,
                                  saved_data=saved_data,
                                  eval_year=eval_year,
                                  nav_html=nav_html,
                                  next_page=next_page,
                                  is_locked=is_locked,
                                  lock_date_text=get_eval_year_lock_date(eval_year).strftime('%B %d, %Y'))


@app.route('/leadership_behaviors_page')
def leadership_behaviors_page():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    eval_year = resolve_eval_year_from_request()
    employee_id = str(session.get('employee_id', ''))  # Default to empty string
    if not employee_id:
        return redirect(url_for('login'))
        
    job_level = safe_int(session.get('job_level'), 0)  # Safe conversion 
    full_name = session.get('full_name', 'N/A')
    
    behaviors_to_display = get_leadership_behaviors_display_map(job_level)

    # Pass validated string params to db function
    saved_data = load_form_data_from_db(employee_id, 'leadership_behaviors')
    nav_html = get_nav_html('leadership_behaviors_page', job_level, full_name)
    is_locked = (not can_edit_eval_year(employee_id, eval_year)) or is_employee_self_edit_locked(employee_id, eval_year)

    return render_template_string(BEHAVIORS_TEMPLATE,
                                  page_title="Leadership Behaviors",
                                  page_description="Evaluate leadership competencies (Rating: 0-5)",
                                  form_id='leadership_behaviors',
                                  behaviors_data=behaviors_to_display,
                                  saved_data=saved_data,
                                  eval_year=eval_year,
                                  nav_html=nav_html,
                                  next_page='comments_page',
                                  is_locked=is_locked,
                                  lock_date_text=get_eval_year_lock_date(eval_year).strftime('%B %d, %Y'))


COMMENTS_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<style>
[data-theme="dark"] .comments-helper-text {
    color: #e5e7eb !important;
}
</style>
<div class="header-section">
    <h1 class="gradient-text">Comments</h1>
    <p>Reflect on your performance, achievements, and development areas</p>
</div>

{% if eval_year %}
<div class="alert-info" style="margin-bottom: 15px;">
    Fiscal Year: <strong>{{ eval_year }}</strong>
</div>
{% endif %}
{% if is_locked %}
<div class="alert-warning" style="margin-bottom: 15px;">
    This fiscal year is locked for editing. You can review the saved details, but changes are no longer allowed after {{ lock_date_text }}.
</div>
{% endif %}
                                           
<form method="POST" action="{{ url_for('save_form_data') }}">
    <input type="hidden" name="form_id" value="comments">
    <input type="hidden" name="next_page" value="summary_page">
    <input type="hidden" name="eval_year" value="{{ session.eval_year }}">
    <fieldset {% if is_locked %}disabled{% endif %} style="border: 0; padding: 0; margin: 0; min-width: 0;">

    <div style="margin-bottom: 30px;">
        <label for="employee_comments" class="modern-label">Employee's Self-Assessment Comments</label>
        <textarea id="employee_comments" name="employee_comments" class="modern-textarea" rows="8" placeholder="Enter your self-assessment, achievements, challenges, and development areas..." style="width: 100%;">{{ saved_data.employee_comments if saved_data else '' }}</textarea>
        <small class="comments-helper-text" style="color: #64748b; display: block; margin-top: 8px;">
            Reflect on your performance, accomplishments, and areas for improvement during this evaluation period.
        </small>
    </div>

    <div class="button-group">
        {% if not is_locked %}
        <button type="submit" name="action" value="save" class="btn-primary">Save Comments</button>
        <a href="{{ url_for(next_page) }}" class="btn-primary">
            <span style="position: relative; z-index: 1;">Save & Next →</span>
        </a>
        {% else %}
        <a href="{{ url_for('summary_page') }}" class="btn-primary">
            <span style="position: relative; z-index: 1;">Go to Summary</span>
        </a>
        {% endif %}
    </div>
    </fieldset>
</form>
{% endblock %}
''')


@app.route('/comments_page')
def comments_page():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    eval_year = resolve_eval_year_from_request()
    employee_id = session.get('employee_id')
    job_level = session.get('job_level')
    full_name = session.get('full_name', 'N/A')
    saved_data = load_form_data_from_db(employee_id, 'comments')
    nav_html = get_nav_html('comments_page', job_level, full_name)
    is_locked = (not can_edit_eval_year(employee_id, eval_year)) or is_employee_self_edit_locked(employee_id, eval_year)

    return render_template_string(COMMENTS_TEMPLATE, saved_data=saved_data, nav_html=nav_html, eval_year=eval_year, page_title="Comments", is_locked=is_locked, lock_date_text=get_eval_year_lock_date(eval_year).strftime('%B %d, %Y'), next_page='summary_page')


SUPERVISOR_BEHAVIOR_REVIEW_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<div class="header-section">
    <h1 class="gradient-text">Supervisor Review</h1>
    <p>Review full behavior definitions and record supervisor scores separately from employee self-ratings.</p>
</div>

<div style="background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%); padding: 20px; border-radius: 12px; margin-bottom: 20px;">
    <div style="display: flex; flex-wrap: wrap; gap: 12px 24px; align-items: center;">
        <div><strong>Employee:</strong> {{ profile.full_name }}</div>
        <div><strong>Employee ID:</strong> {{ profile.employee_id }}</div>
        <div><strong>Position:</strong> {{ profile.position }}</div>
        <div><strong>Job Level:</strong> {{ profile.job_level }}</div>
        <div><strong>Evaluation Year:</strong> {{ eval_year }}</div>
        <div><strong>Evaluation Status:</strong>
            <span style="display:inline-flex; align-items:center; padding:4px 10px; border-radius:999px; font-weight:700; background: {{ workflow_status.bg }}; color: {{ workflow_status.color }}; border: 1px solid {{ workflow_status.border }};">
                {{ workflow_status.label }}
            </span>
        </div>
    </div>
    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 10px; margin-top: 14px;">
        <div style="padding: 12px 14px; border-radius: 10px; background: rgba(255,255,255,0.78); border: 1px solid #bfdbfe;">
            <div style="font-size: 0.8em; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: #475569; margin-bottom: 6px;">Last Reviewed By</div>
            <div style="font-weight: 700; color: #0f172a;">{{ review_status.last_reviewed_by_name or '-' }}</div>
            <div style="font-size: 0.92em; color: #475569; margin-top: 4px;">{{ review_status.last_reviewed_at_text or '-' }}</div>
        </div>
        <div style="padding: 12px 14px; border-radius: 10px; background: rgba(255,255,255,0.78); border: 1px solid #bfdbfe;">
            <div style="font-size: 0.8em; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: #475569; margin-bottom: 6px;">Finalized By</div>
            <div style="font-weight: 700; color: #0f172a;">{{ review_status.finalized_by_name or '-' }}</div>
            <div style="font-size: 0.92em; color: #475569; margin-top: 4px;">{{ review_status.finalized_at_text or '-' }}</div>
        </div>
    </div>
</div>

<form method="POST" action="{{ url_for('save_supervisor_behavior_review', employee_id=profile.employee_id) }}">
    <input type="hidden" name="eval_year" value="{{ eval_year }}">

    {% if group_kpi_review %}
    <div class="content-card" style="margin-top: 20px;">
        <h2 class="gradient-text" style="margin-bottom: 10px;">Group Shared KPI</h2>
        <table class="modern-table" style="table-layout: fixed; width: 100%;">
            <thead>
                <tr>
                    <th style="width: 64%;">Description</th>
                    <th style="text-align:right; width: 12%;">Weight (%)</th>
                    <th style="text-align:right; width: 12%;">Final Score</th>
                    <th style="text-align:right; width: 12%;">Weighted Score</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{ group_kpi_review.description }}</td>
                    <td style="text-align:right;">{{ group_kpi_review.weight }}</td>
                    <td style="text-align:right;">{{ group_kpi_review.admin_score }}</td>
                    <td style="text-align:right;">{{ group_kpi_review.admin_result }}</td>
                </tr>
            </tbody>
        </table>
    </div>
    {% endif %}

    {% for section in kpi_review_sections %}
    <div class="content-card" style="margin-top: 20px;">
        <h2 class="gradient-text" style="margin-bottom: 10px;">{{ section.title }}</h2>
        <table class="modern-table" style="table-layout: fixed; width: 100%;">
            <thead>
                <tr>
                    <th style="width: 42%;">Description</th>
                    <th style="text-align:right; width: 9%;">Weight (%)</th>
                    <th style="text-align:right; width: 11%;">Employee Score</th>
                    <th style="text-align:right; width: 11%;">Employee Result</th>
                    <th style="text-align:right; width: 14%;">Supervisor Score</th>
                    <th style="text-align:right; width: 13%;">Supervisor Result</th>
                </tr>
            </thead>
            <tbody>
                {% for row in section.rows %}
                <tr>
                    <td>{{ row.description }}</td>
                    <td style="text-align:right;">{{ row.weight }}</td>
                    <td style="text-align:right;">{{ row.employee_score }}</td>
                    <td style="text-align:right;">{{ row.employee_result }}</td>
                    <td style="text-align:right; width: 140px;">
                        <input type="number" name="{{ section.id }}_score_{{ row.index }}" step="0.01" min="1" max="5" class="modern-input supervisor-kpi-score" value="{{ row.supervisor_score }}" placeholder="1.00 - 5.00" data-self-score="{{ '' if row.employee_score == '-' else row.employee_score }}">
                    </td>
                    <td style="text-align:right;">{{ row.supervisor_result }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
    </div>
    {% endfor %}

    {% if core_behaviors %}
    <div class="content-card" style="margin-top: 20px;">
        <h2 class="gradient-text" style="margin-bottom: 10px;">Core Behaviors</h2>
        <p style="color: #64748b; margin-bottom: 18px;">Supervisor review scores are stored separately and do not overwrite employee self-scores.</p>
        {% for key, behavior in core_behaviors.items() %}
        <div class="behavior-card">
            <div style="margin-bottom: 15px;">
                <h3 class="gradient-text" style="font-size: 1.15em; margin-bottom: 10px; font-weight: 700;">{{ behavior.title }}</h3>
                <p class="behavior-desc" style="margin-bottom: 8px;"><strong>English:</strong> {{ behavior.description_en }}</p>
                <p class="behavior-desc"><strong>ภาษาไทย:</strong> {{ behavior.description_th }}</p>
            </div>

            <div style="margin: 12px 0 16px 0; padding: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px;">
                <div style="font-weight: 600; margin-bottom: 8px; color: #0f172a;">Rating Scale Guidelines</div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 10px;">
                    {% for level_text in behavior.rating_levels %}
                    <div style="padding: 10px; border: 1px solid #e2e8f0; border-radius: 8px; background: #ffffff;">
                        <div style="font-weight: 600; margin-bottom: 6px; color: #1e3a8a;">Rating {{ loop.index }}</div>
                        <div style="white-space: pre-line; color: #0f172a;">{{ level_text }}</div>
                    </div>
                    {% endfor %}
                </div>
            </div>

            <div style="display:flex; align-items:center; gap:15px; flex-wrap:wrap;">
                <div><strong>Employee Self Score:</strong> {{ core_self_scores.get(key|string, '-') }}</div>
                <label for="core_score_{{ key }}" class="modern-label" style="margin: 0; font-size: 1em; font-weight: 700;">Supervisor Score:</label>
                <select name="core_score_{{ key }}" id="core_score_{{ key }}" class="modern-select behavior-select" style="max-width: 110px;" data-self-score="{{ '' if core_self_scores.get(key|string, '-') == '-' else core_self_scores.get(key|string, '') }}">
                    <option value="">--</option>
                    {% for i in range(0, 6) %}
                    <option value="{{ i }}" {% if core_review_scores.get(key|string) == i|string %}selected{% endif %}>{{ i }}</option>
                    {% endfor %}
                </select>
            </div>
        </div>
        {% endfor %}
        <div style="display:flex; justify-content:flex-end; margin-top: 10px; padding: 12px 14px; background: #dbeafe; border-radius: 10px;">
            <span style="font-size: 1.05em; font-weight: 700; color: #1e3a8a;">Average Score: <span id="coreReviewAverage">{{ core_review_avg }}</span></span>
        </div>
    </div>
    {% endif %}

    {% if leadership_behaviors %}
    <div class="content-card" style="margin-top: 20px;">
        <h2 class="gradient-text" style="margin-bottom: 10px;">Leadership Behaviors</h2>
        <p style="color: #64748b; margin-bottom: 18px;">Track meaning and rating guidance are displayed in full for supervisor assessment.</p>
        {% for key, behavior in leadership_behaviors.items() %}
        <div class="behavior-card">
            <div style="margin-bottom: 15px;">
                <h3 class="gradient-text" style="font-size: 1.15em; margin-bottom: 10px; font-weight: 700;">{{ behavior.title }}</h3>
                {% if behavior.behavior_text %}
                <div class="behavior-desc" style="margin-bottom: 10px; white-space: pre-line;">{{ '\n'.join(behavior.behavior_text.split('\n')[1:]).strip() }}</div>
                {% endif %}
            </div>

            {% for track in behavior.tracks %}
            <div style="padding: 12px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; margin-bottom: 12px;">
                <div style="font-weight: 700; margin-bottom: 8px; color: #1d4ed8;">{{ track.label }}</div>
                {% if track.meaning_text %}
                <div class="behavior-desc" style="margin-bottom: 10px; white-space: pre-line;"><strong>Meaning:</strong><br>{{ track.meaning_text }}</div>
                {% endif %}
                <div style="font-weight: 600; margin-bottom: 8px; color: #0f172a;">Rating Scale Guidelines</div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 10px;">
                    {% for level_text in track.rating_levels %}
                    <div style="padding: 10px; border: 1px solid #e2e8f0; border-radius: 8px; background: #ffffff;">
                        <div style="font-weight: 600; margin-bottom: 6px; color: #1e3a8a;">Rating {{ loop.index }}</div>
                        <div style="white-space: pre-line; color: #0f172a;">{{ level_text }}</div>
                    </div>
                    {% endfor %}
                </div>
            </div>
            {% endfor %}

            <div style="display:flex; align-items:center; gap:15px; flex-wrap:wrap;">
                <div><strong>Employee Self Score:</strong> {{ leadership_self_scores.get(key|string, '-') }}</div>
                <label for="leadership_score_{{ key }}" class="modern-label" style="margin: 0; font-size: 1em; font-weight: 700;">Supervisor Score:</label>
                <select name="leadership_score_{{ key }}" id="leadership_score_{{ key }}" class="modern-select behavior-select" style="max-width: 110px;" data-self-score="{{ '' if leadership_self_scores.get(key|string, '-') == '-' else leadership_self_scores.get(key|string, '') }}">
                    <option value="">--</option>
                    {% for i in range(0, 6) %}
                    <option value="{{ i }}" {% if leadership_review_scores.get(key|string) == i|string %}selected{% endif %}>{{ i }}</option>
                    {% endfor %}
                </select>
            </div>
        </div>
        {% endfor %}
        <div style="display:flex; justify-content:flex-end; margin-top: 10px; padding: 12px 14px; background: #dbeafe; border-radius: 10px;">
            <span style="font-size: 1.05em; font-weight: 700; color: #1e3a8a;">Average Score: <span id="leadershipReviewAverage">{{ leadership_review_avg }}</span></span>
        </div>
    </div>
    {% endif %}

    <div class="content-card" style="margin-top: 20px;">
        <h2 class="gradient-text" style="margin-bottom: 10px;">Supervisor Review Comment</h2>
        <textarea name="review_comment" class="modern-textarea" rows="6" placeholder="Enter supervisor review comments..." style="width: 100%;">{{ review_comment }}</textarea>
    </div>

    <div class="button-group" style="margin-top: 24px;">
        <a href="{{ url_for('director_subordinate_summary', employee_id=profile.employee_id, year=eval_year) }}" class="btn-secondary">Back</a>
        {% if not is_director_reviewer %}
        <button type="button" id="copySubmittedScoresBtn" class="btn-secondary">Use Submitted Scores</button>
        {% endif %}
        <button type="submit" name="action" value="save" class="btn-secondary">{{ save_review_label }}</button>
        <button type="submit" name="action" value="{{ primary_review_action }}" class="btn-primary" id="primaryReviewActionBtn">{{ primary_review_label }}</button>
    </div>
</form>
<script>
(function() {
    function recalcAverage(prefix, outputId) {
        const nodes = document.querySelectorAll(`select[id^="${prefix}_"]`);
        const output = document.getElementById(outputId);
        if (!output || !nodes.length) return;

        let total = 0;
        let count = 0;
        nodes.forEach((node) => {
            const value = parseFloat(node.value);
            if (!isNaN(value) && value >= 0 && value <= 5) {
                total += value;
                count += 1;
            }
        });
        output.textContent = count ? (total / count).toFixed(2) : '-';
    }

    function attach(prefix, outputId) {
        const nodes = document.querySelectorAll(`select[id^="${prefix}_"]`);
        nodes.forEach((node) => node.addEventListener('change', () => recalcAverage(prefix, outputId)));
        recalcAverage(prefix, outputId);
    }

    function copySubmittedScores() {
        document.querySelectorAll('.supervisor-kpi-score').forEach((node) => {
            const selfScore = (node.dataset.selfScore || '').trim();
            if (selfScore) {
                node.value = selfScore;
            }
        });

        document.querySelectorAll('select.behavior-select[data-self-score]').forEach((node) => {
            const selfScore = (node.dataset.selfScore || '').trim();
            if (!selfScore) return;
            const numeric = parseFloat(selfScore);
            if (isNaN(numeric)) return;
            const normalized = Number.isInteger(numeric) ? String(parseInt(String(numeric), 10)) : String(numeric);
            const matchingOption = Array.from(node.options).find((option) => option.value === normalized);
            node.value = matchingOption ? matchingOption.value : '';
        });

        recalcAverage('core_score', 'coreReviewAverage');
        recalcAverage('leadership_score', 'leadershipReviewAverage');
    }

    attach('core_score', 'coreReviewAverage');
    attach('leadership_score', 'leadershipReviewAverage');

    const copyButton = document.getElementById('copySubmittedScoresBtn');
    if (copyButton) {
        copyButton.addEventListener('click', copySubmittedScores);
    }

    function getMissingSupervisorScores() {
        const missing = [];

        document.querySelectorAll('.supervisor-kpi-score').forEach((node) => {
            if (!(node.value || '').trim()) {
                const row = node.closest('tr');
                const descriptionCell = row ? row.querySelector('td') : null;
                const label = descriptionCell ? descriptionCell.textContent.trim() : 'KPI score';
                missing.push(label);
            }
        });

        document.querySelectorAll('select.behavior-select').forEach((node) => {
            if (!(node.value || '').trim()) {
                const card = node.closest('.behavior-card');
                const title = card ? (card.querySelector('h3') || {}).textContent : '';
                missing.push((title || 'Behavior score').trim());
            }
        });

        return missing;
    }

    const reviewForm = document.querySelector('form[action*="save_supervisor_behavior_review"]');
    if (reviewForm) {
        reviewForm.addEventListener('submit', (event) => {
            const submitter = event.submitter;
            const action = submitter ? (submitter.value || '').trim().toLowerCase() : '';
            if (action !== 'reviewed' && action !== 'finalize') {
                return;
            }

            const missing = getMissingSupervisorScores();
            if (!missing.length) {
                return;
            }

            event.preventDefault();
            alert(`Please complete all supervisor scores before ${action === 'finalize' ? 'finalizing' : 'submitting'} the review.`);
        });
    }
})();
</script>
{% endblock %}
''')


@app.route('/supervisor_behavior_review/<employee_id>')
def supervisor_behavior_review(employee_id):
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    reviewer_id = str(session.get('employee_id', '')).strip()
    target_employee_id = str(employee_id).strip()
    if not can_review_subordinate(reviewer_id, target_employee_id):
        flash("You do not have permission to review this employee.", "error")
        return redirect(url_for('performance_dashboard'))

    profile = get_employee_profile(target_employee_id)
    eval_year = resolve_eval_year_from_request()
    target_job_level = safe_int(profile.get('job_level'), 0)

    core_behaviors = get_core_behaviors_display_map(target_job_level) if target_job_level <= 11 else {}
    leadership_behaviors = get_leadership_behaviors_display_map(target_job_level) if target_job_level >= 8 else {}
    group_kpi_review, kpi_review_sections = build_supervisor_kpi_review_sections(target_employee_id, target_job_level, eval_year)

    core_self_data = load_form_data_from_db(target_employee_id, 'core_behaviors', eval_year) or {}
    leadership_self_data = load_form_data_from_db(target_employee_id, 'leadership_behaviors', eval_year) or {}
    core_review_data = load_supervisor_review_from_db(target_employee_id, 'core_behaviors', eval_year) or {}
    leadership_review_data = load_supervisor_review_from_db(target_employee_id, 'leadership_behaviors', eval_year) or {}
    comment_review_data = load_supervisor_review_from_db(target_employee_id, 'behavior_review_comment', eval_year) or {}
    review_status = get_supervisor_review_status(target_employee_id, eval_year)
    workflow_status = get_workflow_status(target_employee_id, target_job_level, eval_year)
    _, core_review_avg = summarize_review_scores(core_review_data)
    _, leadership_review_avg = summarize_review_scores(leadership_review_data)
    is_director_reviewer = is_director_level_reviewer(reviewer_id)

    nav_html = get_nav_html('performance_dashboard', session.get('job_level'), session.get('full_name', 'N/A'))
    return render_template_string(
        SUPERVISOR_BEHAVIOR_REVIEW_TEMPLATE,
        nav_html=nav_html,
        page_title=f"Supervisor Review - {profile.get('full_name', 'Employee')}",
        profile=profile,
        eval_year=eval_year,
        group_kpi_review=group_kpi_review,
        kpi_review_sections=kpi_review_sections,
        core_behaviors=core_behaviors,
        leadership_behaviors=leadership_behaviors,
        core_self_scores=format_behavior_scores(core_self_data),
        leadership_self_scores=format_behavior_scores(leadership_self_data),
        core_review_scores=core_review_data.get('scores', {}) if isinstance(core_review_data.get('scores', {}), dict) else {},
        leadership_review_scores=leadership_review_data.get('scores', {}) if isinstance(leadership_review_data.get('scores', {}), dict) else {},
        review_comment=comment_review_data.get('comment', ''),
        review_status=review_status,
        workflow_status=workflow_status,
        core_review_avg=core_review_avg,
        leadership_review_avg=leadership_review_avg,
        is_director_reviewer=is_director_reviewer,
        save_review_label='Save Final Review Draft' if is_director_reviewer else 'Save Review Draft',
        primary_review_action='finalize' if is_director_reviewer else 'reviewed',
        primary_review_label='Finalize Review' if is_director_reviewer else 'Submit Review'
    )


@app.route('/save_supervisor_behavior_review/<employee_id>', methods=['POST'])
def save_supervisor_behavior_review(employee_id):
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    reviewer_id = str(session.get('employee_id', '')).strip()
    target_employee_id = str(employee_id).strip()
    if not can_review_subordinate(reviewer_id, target_employee_id):
        flash("You do not have permission to review this employee.", "error")
        return redirect(url_for('performance_dashboard'))

    eval_year = resolve_eval_year_from_request()
    if not can_edit_eval_year(reviewer_id, eval_year):
        flash(f"FY{eval_year} is locked for editing.", "error")
        return redirect(url_for('supervisor_behavior_review', employee_id=target_employee_id, year=eval_year))
    action = str(request.form.get('action', 'save') or 'save').strip().lower()
    target_profile = get_employee_profile(target_employee_id)
    target_job_level = safe_int(target_profile.get('job_level'), 0)

    kpi_defs: List[Tuple[str, int]] = [
        ('org_capability', 10),
        ('people_dev', 10),
        ('bu_obj', 15),
    ]
    for form_id, num_rows in kpi_defs:
        if form_id == 'people_dev' and target_job_level < 8:
            continue

        employee_data = load_form_data_from_db(target_employee_id, form_id, eval_year) or {}
        if form_id == 'bu_lob_kpi' and is_fixed_bu_lob_user(target_job_level, target_profile.get('division'), target_profile.get('company')):
            employee_data = apply_fixed_bu_lob_constraints(employee_data, target_job_level, target_profile.get('division'), target_profile.get('company'))
        descriptions = employee_data.get('descriptions', []) if isinstance(employee_data.get('descriptions'), list) else []
        weights = employee_data.get('weights', []) if isinstance(employee_data.get('weights'), list) else []
        scores_payload: List[str] = [''] * num_rows
        results_payload: List[str] = [''] * num_rows

        has_any_score = False
        for i in range(num_rows):
            description = descriptions[i] if i < len(descriptions) else ''
            if not str(description or '').strip():
                continue
            raw_score = str(request.form.get(f'{form_id}_score_{i}', '') or '').strip()
            if not raw_score:
                continue
            score_value = safe_float(raw_score, 0.0)
            weight_value = safe_float(weights[i] if i < len(weights) else '', 0.0)
            scores_payload[i] = f"{score_value:.2f}"
            results_payload[i] = f"{(score_value * weight_value / 100):.2f}"
            has_any_score = True

        if has_any_score:
            save_supervisor_review_to_db(
                target_employee_id,
                reviewer_id,
                form_id,
                eval_year,
                {'scores': scores_payload, 'results': results_payload}
            )

    if target_job_level <= 11:
        core_scores: Dict[str, Any] = {}
        for key in get_core_behaviors_display_map(target_job_level).keys():
            value = str(request.form.get(f'core_score_{key}', '') or '').strip()
            if value:
                core_scores[str(key)] = value
        save_supervisor_review_to_db(
            target_employee_id,
            reviewer_id,
            'core_behaviors',
            eval_year,
            {'scores': core_scores}
        )

    if target_job_level >= 8:
        leadership_scores: Dict[str, Any] = {}
        for key in get_leadership_behaviors_display_map(target_job_level).keys():
            value = str(request.form.get(f'leadership_score_{key}', '') or '').strip()
            if value:
                leadership_scores[str(key)] = value
        save_supervisor_review_to_db(
            target_employee_id,
            reviewer_id,
            'leadership_behaviors',
            eval_year,
            {'scores': leadership_scores}
        )

    review_comment = str(request.form.get('review_comment', '') or '').strip()
    save_supervisor_review_to_db(
        target_employee_id,
        reviewer_id,
        'behavior_review_comment',
        eval_year,
        {'comment': review_comment}
    )

    review_was_finalized = is_supervisor_review_finalized(target_employee_id, eval_year)
    review_is_complete = is_supervisor_review_complete(target_employee_id, target_job_level, eval_year)
    review_status_payload = get_supervisor_review_status(target_employee_id, eval_year)
    status_update = dict(review_status_payload) if isinstance(review_status_payload, dict) else {}
    status_update['last_reviewed_by'] = reviewer_id
    status_update['last_reviewed_at'] = datetime.datetime.now().isoformat(timespec='seconds')
    status_update.setdefault('is_submitted', True)

    if action == 'reviewed':
        if not review_is_complete:
            flash("Cannot submit review until all required supervisor scores are completed.", "error")
            return redirect(url_for('supervisor_behavior_review', employee_id=target_employee_id, year=eval_year))
        status_update['is_reviewed'] = True
        status_update['reviewed_by'] = reviewer_id
        status_update['reviewed_at'] = datetime.datetime.now().isoformat(timespec='seconds')
        save_supervisor_review_to_db(
            target_employee_id,
            reviewer_id,
            'supervisor_review_status',
            eval_year,
            status_update
        )
        flash("Supervisor review submitted successfully!", "success")
    elif action == 'finalize':
        if not is_director_level_reviewer(reviewer_id):
            flash("Only director-level reviewers can finalize this evaluation.", "error")
            return redirect(url_for('supervisor_behavior_review', employee_id=target_employee_id, year=eval_year))
        if not review_is_complete:
            flash("Cannot finalize supervisor review until all required supervisor scores are completed.", "error")
            return redirect(url_for('supervisor_behavior_review', employee_id=target_employee_id, year=eval_year))
        if not bool(status_update.get('is_reviewed')):
            flash("Cannot finalize until the evaluation status is Reviewed.", "error")
            return redirect(url_for('supervisor_behavior_review', employee_id=target_employee_id, year=eval_year))
        status_update['is_finalized'] = True
        status_update['finalized_by'] = reviewer_id
        status_update['finalized_at'] = datetime.datetime.now().isoformat(timespec='seconds')
        save_supervisor_review_to_db(
            target_employee_id,
            reviewer_id,
            'supervisor_review_status',
            eval_year,
            status_update
        )
        persist_summary_snapshot_for_employee(target_employee_id, eval_year, use_supervisor_review=True)
        flash("Evaluation finalized successfully!", "success")
    else:
        save_supervisor_review_to_db(
            target_employee_id,
            reviewer_id,
            'supervisor_review_status',
            eval_year,
            status_update
        )
        if review_was_finalized:
            persist_summary_snapshot_for_employee(target_employee_id, eval_year, use_supervisor_review=True)
        flash("Supervisor review saved successfully!", "success")

    return redirect(url_for('supervisor_behavior_review', employee_id=target_employee_id, year=eval_year))


SUMMARY_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<div style="display:flex; justify-content:center; margin-bottom: 14px;">
    <img src="{{ photo_src }}"
         alt="Staff Photo"
         style="width: 108px; height: 108px; border-radius: 999px; object-fit: cover; border: 3px solid #e5e7eb; background: #f8fafc;"
         onerror="this.onerror=null;this.src='{{ url_for('user_photo_placeholder', name=profile.full_name) }}';">
</div>
<div class="header-section">
    <h1 class="gradient-text">Score Summary</h1>
    <p>Your complete performance evaluation overview</p>
</div>
{% if selected_year %}
<div class="alert-info" style="margin-bottom: 15px;">
    Fiscal Year: <strong>{{ selected_year }}</strong>
    {% if selected_year != current_year %}<span style="margin-left:8px;color:#1e3a8a;"></span>{% endif %}
</div>
{% endif %}

{% if available_years %}
<form method="get" action="{{ url_for('summary_page') }}" style="margin-bottom: 20px;">
    <label class="modern-label" for="eval_year">Select Fiscal Year:</label>
    <select id="eval_year" name="year" class="modern-select" style="width: 200px; display: inline-block;" onchange="this.form.submit()">
        {% for y in available_years %}
        <option value="{{ y }}" {% if y == selected_year %}selected{% endif %}>{{ y }}</option>
        {% endfor %}
    </select>
    {% if selected_year != current_year %}
    <span class="summary-accent-text" style="margin-left: 10px;"></span>
    {% endif %}
</form>
{% endif %}

{% if summary %}
<div style="display:flex; justify-content:flex-end; margin-bottom: 14px;">
    <span style="display:inline-flex; align-items:center; padding:8px 14px; border-radius:999px; font-size:0.92em; font-weight:700; background: {{ workflow_status.bg }}; color: {{ workflow_status.color }}; border: 1px solid {{ workflow_status.border }};">
        Status: {{ workflow_status.label }}
    </span>
</div>
{% if summary.review_finalized %}
<div class="alert-info" style="margin-bottom: 18px;">
    Official score is currently based on <strong>finalized supervisor review</strong>.
</div>
{% endif %}
{% if workflow_status.code == 'draft' %}
<div class="alert-info" style="margin-bottom: 18px;">
    Your self-evaluation is still in <strong>Draft</strong>. When you are ready for supervisor scoring, click <strong>Submit Evaluation</strong>.
</div>
{% elif workflow_status.code == 'submitted' %}
<div class="alert-info" style="margin-bottom: 18px;">
    Your self-evaluation has been <strong>Submitted</strong>. You may still update your forms and click <strong>Resubmit Evaluation</strong> until the supervisor marks it <strong>Reviewed</strong>.
</div>
{% elif workflow_status.code == 'reviewed' %}
<div class="alert-info" style="margin-bottom: 18px;">
    Your evaluation has been <strong>Reviewed</strong> by supervisor and is waiting for director finalization.
</div>
{% endif %}
<div style="display:grid; grid-template-columns: minmax(260px, 360px); gap: 18px; margin: 30px 0;">
    <div style="background: {% if finalized_summary %}linear-gradient(135deg, #166534 0%, #16a34a 100%){% else %}linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%){% endif %}; color: white; padding: 28px 24px; border-radius: 16px; text-align: center;">
        <div style="font-size: 0.88em; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase; opacity: 0.88; margin-bottom: 10px;">{% if finalized_summary %}Finalized Score{% else %}Self Score{% endif %}</div>
        <h2 style="color: white; font-size: 3em; margin-bottom: 10px; margin-top: 0;">
            {% if finalized_summary %}{{ finalized_summary.summary_data.final_total_score }}{% else %}{{ self_summary.summary_data.final_total_score }}{% endif %} / 5.00
        </h2>
        <p style="font-size: 1.05em; opacity: 0.95; margin-bottom: 0;">{% if finalized_summary %}Official Final Score{% else %}Employee Self-Evaluation Score{% endif %}</p>
    </div>
</div>

<div style="margin: 40px 0;">
    <h2 class="gradient-text" style="font-size: 1.8em; margin-bottom: 20px;">Score Components Breakdown</h2>

    <table class="modern-table" style="table-layout: {% if finalized_summary %}auto{% else %}fixed{% endif %}; width: 100%;">
        <thead>
            <tr>
                <th style="width: {% if finalized_summary %}46%{% else %}64%{% endif %};">Component</th>
                <th style="text-align: center; width: {% if finalized_summary %}10%{% else %}10%{% endif %};">Weight (%)</th>
                {% if finalized_summary %}
                <th style="text-align: right; width: 11%;">Self Score</th>
                <th style="text-align: right; width: 11%;">Self Weighted</th>
                <th style="text-align: right; width: 11%; background: #ecfdf5;">Finalized Score</th>
                <th style="text-align: right; width: 11%; background: #dcfce7;">Finalized Weighted</th>
                {% else %}
                <th style="text-align: right; width: 13%;">Score</th>
                <th style="text-align: right; width: 13%;">Weighted Score</th>
                {% endif %}
            </tr>
        </thead>
        <tbody>
            <tr>
                <td colspan="{% if finalized_summary %}6{% else %}4{% endif %}" style="background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%); font-weight: bold;">
                    <span class="summary-accent-text">Performance KPI Components ({{ summary.perf_kpi_weight_pct }}%)</span>
                </td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">Group Shared KPI</td>
                <td style="text-align: center;">{{ self_summary.summary_data.group_kpi_weight }}</td>
                {% if finalized_summary %}
                <td style="text-align: right;">{{ self_summary.summary_data.group_kpi_avg_score }}</td>
                <td style="text-align: right;">{{ self_summary.summary_data.group_kpi_score }}</td>
                <td style="text-align: right; background: #ecfdf5;">{{ finalized_summary.summary_data.group_kpi_avg_score }}</td>
                <td style="text-align: right; background: #dcfce7;">{{ finalized_summary.summary_data.group_kpi_score }}</td>
                {% else %}
                <td style="text-align: right;">{{ self_summary.summary_data.group_kpi_avg_score }}</td>
                <td style="text-align: right;">{{ self_summary.summary_data.group_kpi_score }}</td>
                {% endif %}
            </tr>
            <tr>
                <td style="padding-left: 30px;">BU/LoB Shared KPI</td>
                <td style="text-align: center;">{{ self_summary.summary_data.bu_lob_kpi_weight }}</td>
                {% if finalized_summary %}
                <td style="text-align: right;">{{ self_summary.summary_data.bu_lob_kpi_avg_score }}</td>
                <td style="text-align: right;">{{ self_summary.summary_data.bu_lob_kpi_score }}</td>
                <td style="text-align: right; background: #ecfdf5;">{{ finalized_summary.summary_data.bu_lob_kpi_avg_score }}</td>
                <td style="text-align: right; background: #dcfce7;">{{ finalized_summary.summary_data.bu_lob_kpi_score }}</td>
                {% else %}
                <td style="text-align: right;">{{ self_summary.summary_data.bu_lob_kpi_avg_score }}</td>
                <td style="text-align: right;">{{ self_summary.summary_data.bu_lob_kpi_score }}</td>
                {% endif %}
            </tr>
            <tr>
                <td style="padding-left: 30px;">Organizational Capability Development</td>
                <td style="text-align: center;">{{ self_summary.summary_data.org_cap_weight }}</td>
                {% if finalized_summary %}
                <td style="text-align: right;">{{ self_summary.summary_data.org_cap_avg_score }}</td>
                <td style="text-align: right;">{{ self_summary.summary_data.org_cap_score }}</td>
                <td style="text-align: right; background: #ecfdf5;">{{ finalized_summary.summary_data.org_cap_avg_score }}</td>
                <td style="text-align: right; background: #dcfce7;">{{ finalized_summary.summary_data.org_cap_score }}</td>
                {% else %}
                <td style="text-align: right;">{{ self_summary.summary_data.org_cap_avg_score }}</td>
                <td style="text-align: right;">{{ self_summary.summary_data.org_cap_score }}</td>
                {% endif %}
            </tr>
            <tr>
                <td style="padding-left: 30px;">People Development</td>
                <td style="text-align: center;">{{ self_summary.summary_data.people_dev_weight }}</td>
                {% if finalized_summary %}
                <td style="text-align: right;">{{ self_summary.summary_data.people_dev_avg_score }}</td>
                <td style="text-align: right;">{{ self_summary.summary_data.people_dev_score }}</td>
                <td style="text-align: right; background: #ecfdf5;">{{ finalized_summary.summary_data.people_dev_avg_score }}</td>
                <td style="text-align: right; background: #dcfce7;">{{ finalized_summary.summary_data.people_dev_score }}</td>
                {% else %}
                <td style="text-align: right;">{{ self_summary.summary_data.people_dev_avg_score }}</td>
                <td style="text-align: right;">{{ self_summary.summary_data.people_dev_score }}</td>
                {% endif %}
            </tr>
            <tr>
                <td style="padding-left: 30px;">Business Unit Objectives</td>
                <td style="text-align: center;">{{ self_summary.summary_data.bu_obj_weight }}</td>
                {% if finalized_summary %}
                <td style="text-align: right;">{{ self_summary.summary_data.bu_obj_avg_score }}</td>
                <td style="text-align: right;">{{ self_summary.summary_data.bu_obj_score }}</td>
                <td style="text-align: right; background: #ecfdf5;">{{ finalized_summary.summary_data.bu_obj_avg_score }}</td>
                <td style="text-align: right; background: #dcfce7;">{{ finalized_summary.summary_data.bu_obj_score }}</td>
                {% else %}
                <td style="text-align: right;">{{ self_summary.summary_data.bu_obj_avg_score }}</td>
                <td style="text-align: right;">{{ self_summary.summary_data.bu_obj_score }}</td>
                {% endif %}
            </tr>

            <tr style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);">
                <td><strong>Performance KPI</strong></td>
                <td style="text-align: center;"><strong>{{ self_summary.summary_data.perf_kpi_weight_pct }}%</strong></td>
                {% if finalized_summary %}
                <td style="text-align: right;"><strong>{{ self_summary.summary_data.total_kpi_score }}</strong></td>
                <td style="text-align: right;"><strong>{{ self_summary.summary_data.perf_kpi_score }}</strong></td>
                <td style="text-align: right; background: #ecfdf5;"><strong>{{ finalized_summary.summary_data.total_kpi_score }}</strong></td>
                <td style="text-align: right; background: #dcfce7;"><strong>{{ finalized_summary.summary_data.perf_kpi_score }}</strong></td>
                {% else %}
                <td style="text-align: right;"><strong>{{ self_summary.summary_data.total_kpi_score }}</strong></td>
                <td style="text-align: right;"><strong>{{ self_summary.summary_data.perf_kpi_score }}</strong></td>
                {% endif %}
            </tr>

            {% if self_summary.summary_data.core_behaviors_weight_pct > 0 %}
            <tr>
                <td><strong>Core Behaviors</strong></td>
                <td style="text-align: center;"><strong>{{ self_summary.summary_data.core_behaviors_weight_pct }}%</strong></td>
                {% if finalized_summary %}
                <td style="text-align: right;"><strong>{{ self_summary.summary_data.core_behaviors_avg }}</strong></td>
                <td style="text-align: right;"><strong>{{ self_summary.summary_data.core_behaviors_score }}</strong></td>
                <td style="text-align: right; background: #ecfdf5;"><strong>{{ finalized_summary.summary_data.core_behaviors_avg }}</strong></td>
                <td style="text-align: right; background: #dcfce7;"><strong>{{ finalized_summary.summary_data.core_behaviors_score }}</strong></td>
                {% else %}
                <td style="text-align: right;"><strong>{{ self_summary.summary_data.core_behaviors_avg }}</strong></td>
                <td style="text-align: right;"><strong>{{ self_summary.summary_data.core_behaviors_score }}</strong></td>
                {% endif %}
            </tr>
            {% endif %}

            {% if self_summary.summary_data.leadership_behaviors_weight_pct > 0 %}
            <tr>
                <td><strong>Leadership Behaviors</strong></td>
                <td style="text-align: center;"><strong>{{ self_summary.summary_data.leadership_behaviors_weight_pct }}%</strong></td>
                {% if finalized_summary %}
                <td style="text-align: right;"><strong>{{ self_summary.summary_data.leadership_behaviors_avg }}</strong></td>
                <td style="text-align: right;"><strong>{{ self_summary.summary_data.leadership_behaviors_score }}</strong></td>
                <td style="text-align: right; background: #ecfdf5;"><strong>{{ finalized_summary.summary_data.leadership_behaviors_avg }}</strong></td>
                <td style="text-align: right; background: #dcfce7;"><strong>{{ finalized_summary.summary_data.leadership_behaviors_score }}</strong></td>
                {% else %}
                <td style="text-align: right;"><strong>{{ self_summary.summary_data.leadership_behaviors_avg }}</strong></td>
                <td style="text-align: right;"><strong>{{ self_summary.summary_data.leadership_behaviors_score }}</strong></td>
                {% endif %}
            </tr>
            {% endif %}

            <tr style="background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);">
                <td><strong class="summary-accent-text">Total Weight/Final Score</strong></td>
                <td style="text-align: center;"><strong>{{ self_summary.summary_data.total_weight }}%</strong></td>
                {% if finalized_summary %}
                <td style="text-align: right;"><strong>-</strong></td>
                <td style="text-align: right;"><strong>{{ self_summary.summary_data.final_total_score }}</strong></td>
                <td style="text-align: right; background: #ecfdf5;"><strong>-</strong></td>
                <td style="text-align: right; background: #dcfce7;"><strong style="font-size: 1.3em; color: #16a34a;">{{ finalized_summary.summary_data.final_total_score }}</strong></td>
                {% else %}
                <td style="text-align: right;"><strong>-</strong></td>
                <td style="text-align: right;"><strong style="font-size: 1.3em; color: #16a34a;">{{ self_summary.summary_data.final_total_score }}</strong></td>
                {% endif %}
            </tr>
        </tbody>
    </table>
</div>

{% else %}
<div class="alert-warning">
    <strong>No scores available yet.</strong> Please complete your performance evaluation forms to view your summary.
</div>
{% endif %}

{% if workflow_status.code in ['draft', 'submitted'] %}
<form method="post" action="{{ url_for('submit_self_evaluation') }}" style="margin-bottom: 18px;">
    <input type="hidden" name="eval_year" value="{{ selected_year }}">
    <div class="button-group" style="justify-content: flex-end; margin-top: 0;">
        <button type="submit" class="btn-primary" style="font-size: 15px; line-height: 1.2; background: linear-gradient(135deg, #0f234f 0%, #1e3a73 100%); border-color: #0f234f; box-shadow: 0 10px 24px rgba(15, 35, 79, 0.24);">{% if workflow_status.code == 'submitted' %}Resubmit Evaluation{% else %}Submit Evaluation{% endif %}</button>
    </div>
</form>
{% endif %}

<div class="button-group">
    <a href="{{ url_for('print_summary') }}" class="btn-success" target="_blank">Print Summary</a>
    {% if can_export %}
    <a href="{{ url_for('export_scores') }}" class="btn-success">Export CSV</a>
    <a href="{{ url_for('export_summary_csv') }}" class="btn-success">Export Summary CSV</a>
    {% endif %}
    <a href="{{ url_for('profile_page') }}" class="btn-primary profile-link">Back to Profile</a>
</div>

<div class="button-group">
    <a href="{{ url_for('email_summary') }}" class="btn-success">Download PDF</a>
    <a href="mailto:?subject=Performance Evaluation {{ selected_year }} Summary for {{ session.full_name }}&body=Please find the attached performance evaluation summary." class="btn-primary">
        Open Email
    </a>
</div>


{% endblock %}
''')

@app.route('/summary_page')
def summary_page():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    employee_id = session.get('employee_id')
    job_level = safe_int(session.get('job_level', 0), 0)
    full_name = session.get('full_name', 'N/A')
    profile = get_employee_profile(str(employee_id))
    baseline_year = 2026
    current_year = max(get_current_fiscal_year(), baseline_year)  # allow FY2026+
    requested_year = max(safe_int(request.args.get('year'), session.get('eval_year', current_year)), baseline_year)
    available_years = [y for y in list_summary_years(str(employee_id)) if y >= baseline_year]
    # Always include baseline/current so every user can pick FY2026+ without prior data
    for y in (requested_year, current_year, baseline_year):
        if y not in available_years:
            available_years.insert(0, y)
    available_years = sorted(set(available_years), reverse=True)
    session['eval_year'] = requested_year
    self_summary_box = calculate_summary_snapshot_for_employee(employee_id, requested_year, use_supervisor_review=False)
    review_finalized = is_supervisor_review_finalized(employee_id, requested_year)
    finalized_summary_box = calculate_summary_snapshot_for_employee(employee_id, requested_year, use_supervisor_review=True) if review_finalized else None

    summary_data = dict(self_summary_box.get('summary_data', {})) if isinstance(self_summary_box, dict) else {}
    summary_data['review_finalized'] = review_finalized

    should_persist_snapshot = requested_year == current_year
    if should_persist_snapshot and isinstance(self_summary_box, dict):
        existing_summary_history = load_summary_history(str(employee_id), requested_year) or {}
        if existing_summary_history != summary_data:
            save_all_final_scores_to_db(employee_id, self_summary_box.get('scores_to_save', {}))
            save_summary_history(str(employee_id), requested_year, summary_data)
    if requested_year not in available_years:
        available_years.insert(0, requested_year)

    workflow_status = get_workflow_status(employee_id, safe_int(job_level, 0), requested_year)

    user_data = session.get('user_data', {})
    user_data['summary_data'] = summary_data
    session['user_data'] = user_data

    nav_html = get_nav_html('summary_page', job_level, full_name)

    can_export = str(employee_id).strip() in set(list(SPECIAL_EXPORT_ACCESS.keys()) + [AUTHORIZED_EXPORTER_ID])

    return render_template_string(SUMMARY_TEMPLATE,
                                  nav_html=nav_html,
                                  summary=summary_data,
                                  self_summary=self_summary_box,
                                  finalized_summary=finalized_summary_box,
                                  workflow_status=workflow_status,
                                  profile=profile,
                                  photo_src=url_for('user_photo'),
                                  can_export=can_export, page_title="Score Summary",
                                  available_years=available_years,
                                  selected_year=requested_year,
                                  current_year=current_year)

@app.route('/print_summary')
def print_summary():
    if 'employee_id' in session:
        employee_id = session['employee_id']
        profile = get_employee_profile(employee_id)
        user_data = session.get('user_data', {})
        baseline_year = 2026
        current_year = max(get_current_fiscal_year(), baseline_year)
        requested_year = max(safe_int(request.args.get('year'), session.get('eval_year', current_year)), baseline_year)
        session['eval_year'] = requested_year

        if not profile:
            return "Profile not found.", 404

        job_level = profile['job_level']

        def filter_table_data(data, num_rows):
            if not data:
                return []
            filtered_rows = []
            for i in range(num_rows):
                desc_val = data['descriptions'][i].strip() if i < len(data.get('descriptions', [])) and \
                                                              data['descriptions'][i] else ''
                score_val = data['scores'][i].strip() if i < len(data.get('scores', [])) and data['scores'][i] else ''
                if desc_val:
                    filtered_rows.append({'description': desc_val, 'score': score_val})
            return filtered_rows

        bu_lob_kpi_data = get_form_data('bu_lob_kpi')
        org_cap_data = get_form_data('org_capability')
        people_dev_data = get_form_data('people_dev')
        bu_obj_data = get_form_data('bu_obj')
        comments_data = get_form_data('comments')
        core_behaviors_data = get_form_data('core_behaviors')
        leadership_behaviors_data = get_form_data('leadership_behaviors')
        group_kpi_data = get_form_data('group_kpi')

        bu_lob_kpi_filtered = filter_table_data(bu_lob_kpi_data, 5)
        org_cap_filtered = filter_table_data(org_cap_data, 10)
        people_dev_filtered = filter_table_data(people_dev_data, 10)
        bu_obj_filtered = filter_table_data(bu_obj_data, 15)

        group_score_str = group_kpi_data.get('group_score', '')
        group_score_val = float(group_score_str) if group_score_str.replace('.', '', 1).isdigit() else 0
        has_group_kpi_data = (job_level >= 8 and group_score_val > 0)

        return render_template_string(
            PRINT_SUMMARY_HTML,
            profile=profile,
            group_kpi_data=group_kpi_data,
            bu_lob_kpi_data=bu_lob_kpi_data,
            org_cap_data=org_cap_data,
            people_dev_data=people_dev_data,
            bu_obj_data=bu_obj_data,
            comments_data=comments_data,
            core_behaviors_data=core_behaviors_data,
            leadership_behaviors_data=leadership_behaviors_data,
            core_behaviors_map=get_core_behaviors_display_map(job_level),
            leadership_behaviors_map=get_leadership_behaviors_display_map(job_level),
            summary_data=user_data.get('summary_data', {}),
            job_level=job_level,
            bu_lob_kpi_filtered=bu_lob_kpi_filtered,
            org_cap_filtered=org_cap_filtered,
            people_dev_filtered=people_dev_filtered,
            bu_obj_filtered=bu_obj_filtered,
            has_group_kpi_data=has_group_kpi_data,
            selected_year=requested_year,
        )
    return redirect(url_for('login'))


@app.route('/save_progress', methods=['POST'])
def save_progress():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    employee_id = session['employee_id']
    job_level = session.get('job_level')
    division = session.get('division')
    company = session.get('company')
    eval_year = resolve_eval_year_from_request()
    form_id = request.form.get('form_id')
    saved_data = {}

    if form_id == 'group_kpi':
        saved_data['group_score'] = request.form.get('group_score', '')
        saved_data['group_weight'] = request.form.get('group_weight', '')
        group_weight = float(saved_data['group_weight']) / 100 if saved_data['group_weight'] else 0
        group_score = float(saved_data['group_score']) if saved_data['group_score'] else 0
        saved_data['group_result'] = "{:.2f}".format(group_score * group_weight)

    elif form_id in ['bu_lob_kpi', 'org_capability', 'people_dev', 'bu_obj']:
        is_fixed_mode = form_id == 'bu_lob_kpi' and is_fixed_bu_lob_user(job_level, division, company)
        if form_id == 'bu_lob_kpi':
            num_rows = 2 if is_fixed_mode else 5
        elif form_id == 'bu_obj':
            num_rows = 15
        else:
            num_rows = 10
        if is_fixed_mode:
            fixed_weight = safe_float(get_fixed_bu_lob_weight(job_level), 0.0)
            total_weight_submitted = fixed_weight * 2
        else:
            total_weight_submitted = sum(float(request.form.get(f'weight_{i}', 0) or 0) for i in range(num_rows))
        weight_limit = get_weight_limit(form_id, job_level)
        if total_weight_submitted > weight_limit:
            flash(
                f"Warning: The total weight ({total_weight_submitted}%) exceeds the allowed limit of ({weight_limit}%). Please adjust your weights and try again.")
            page_map = {
                'bu_lob_kpi': 'bu_lob_kpi_page',
                'org_capability': 'org_capability_page',
                'people_dev': 'people_dev_page',
                'bu_obj': 'bu_objectives_page'
            }
            return redirect(url_for(page_map.get(form_id, 'profile_page')))

        # Initialize type-safe data structures
        saved_data = {
            'descriptions': [],    # List[str]
            'weights': [],        # List[str]
            'scores': [],         # List[str]
            'results': [],        # List[str]
            'short_descriptions': [],  # List[List[str]]
            'total_score': "0.00" # str
        }
        total_score = 0.0
        fixed_template = build_fixed_bu_lob_data(job_level, division, company) if is_fixed_mode else {}

        for i in range(num_rows):
            # Get form data with safe string defaults
            if is_fixed_mode:
                desc = str(fixed_template['descriptions'][i])
                weight_str = str(fixed_template['weights'][i])
                score_str = str(fixed_template['scores'][i])
                row_short_descs = [str(x) for x in fixed_template['short_descriptions'][i]]
            else:
                desc = str(request.form.get(f'desc_{i}', ''))
                weight_str = str(request.form.get(f'weight_{i}', ''))
                score_str = str(request.form.get(f'score_{i}', ''))
                row_short_descs = []
                for j in range(5):
                    row_short_descs.append(str(request.form.get(f'short_desc_{i}_{j}', '')))
            
            # Add to saved data lists
            saved_data['descriptions'].append(desc)
            saved_data['weights'].append(weight_str)
            saved_data['scores'].append(score_str)
            saved_data['short_descriptions'].append(row_short_descs)

            # Safe numeric conversions
            weight = safe_float(weight_str, 0.0)
            score = safe_float(score_str, 0.0)
            
            # Calculate result
            result = (weight * score) / 100
            saved_data['results'].append("{:.2f}".format(result))
            total_score += result

        # Store total as formatted string
        saved_data['total_score'] = "{:.2f}".format(total_score)

    elif form_id in ['core_behaviors', 'leadership_behaviors']:
        saved_data['scores'] = {}
        for key, value in request.form.items():
            if key.startswith('score_') and value:
                saved_data['scores'][key.replace('score_', '')] = value

    elif form_id == 'comments':
        existing_comments = load_form_data_from_db(employee_id, 'comments', eval_year) or {}
        saved_data['employee_comments'] = request.form.get('employee_comments', '')
        saved_data['supervisor_comments'] = existing_comments.get('supervisor_comments', '')

    if save_form_data_to_db_yearly(employee_id, form_id, eval_year, saved_data):
        flash("Progress saved successfully!")
    else:
        flash("Error: Could not save data to the database. Please contact support.")

    next_page = request.args.get('next_page')
    if next_page:
        return redirect(url_for(next_page))
    else:
        return redirect(url_for('profile_page'))


@app.route('/save_form_data', methods=['POST'])
def save_form_data():
    """Save form data with proper type safety"""
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    # Get session data with type-safe defaults
    employee_id = str(session.get('employee_id', ''))
    if not employee_id:
        return redirect(url_for('login'))

    job_level = safe_int(session.get('job_level'), 0)
    division = session.get('division')
    company = session.get('company')
    eval_year = resolve_eval_year_from_request()
    if not can_edit_eval_year(employee_id, eval_year):
        flash(f"FY{eval_year} is locked for editing.", 'error')
        return redirect(url_for('summary_page', year=eval_year))
    if is_employee_self_edit_locked(employee_id, eval_year):
        flash("This evaluation is already reviewed and can no longer be edited by the employee.", 'error')
        return redirect(url_for('summary_page', year=eval_year))
    
    form_id = str(request.form.get('form_id', ''))
    if not form_id:
        flash('Missing form ID', 'error')
        return redirect(url_for('profile_page'))
        
    next_page = str(request.form.get('next_page', ''))
    action = str(request.form.get('action', 'save'))
    
    saved_data: Dict[str, Any] = {}
    target_employee_id = employee_id

    if form_id == 'group_kpi':
        flash("Group Shared KPI is now maintained only from Shared KPI Scores.", "info")
        if is_super_admin_employee(employee_id):
            return redirect(url_for('division_revenue_ebitda_admin_page', year=eval_year))
        return redirect(url_for('group_kpi_page', year=eval_year))

    elif form_id in ['bu_lob_kpi', 'org_capability', 'people_dev', 'bu_obj']:
        is_fixed_mode = form_id == 'bu_lob_kpi' and is_fixed_bu_lob_user(job_level, division, company)
        if form_id == 'bu_lob_kpi':
            num_rows = 2 if is_fixed_mode else 5
        elif form_id == 'bu_obj':
            num_rows = 15
        else:
            num_rows = 10
        if is_fixed_mode:
            fixed_weight = safe_float(get_fixed_bu_lob_weight(job_level), 0.0)
            total_weight_submitted = fixed_weight * 2
        else:
            total_weight_submitted = sum(float(request.form.get(f'weight_{i}', 0) or 0) for i in range(num_rows))
        weight_limit = get_weight_limit(form_id, job_level)

        if total_weight_submitted > weight_limit:
            flash(
                f"Warning: The total weight ({total_weight_submitted}%) exceeds the allowed limit of ({weight_limit}%). Please adjust your weights and try again.",
                'warning')
            page_map = {
                'bu_lob_kpi': 'bu_lob_kpi_page',
                'org_capability': 'org_capability_page',
                'people_dev': 'people_dev_page',
                'bu_obj': 'bu_objectives_page'
            }
            return redirect(url_for(page_map.get(form_id, 'profile_page')))

        saved_data = {'descriptions': [], 'weights': [], 'scores': [], 'results': [], 'short_descriptions': []}
        total_score = 0.0
        fixed_template = build_fixed_bu_lob_data(job_level, division, company) if is_fixed_mode else {}

        for i in range(num_rows):
            if is_fixed_mode:
                desc = str(fixed_template['descriptions'][i])
                weight = str(fixed_template['weights'][i])
                score = str(fixed_template['scores'][i])
                short_descs = [str(x) for x in fixed_template['short_descriptions'][i]]
            else:
                desc = request.form.get(f'desc_{i}', '')
                weight = request.form.get(f'weight_{i}', '')
                score = request.form.get(f'score_{i}', '')
                short_descs = []
                for j in range(5):
                    short_descs.append(request.form.get(f'short_desc_{i}_{j}', ''))
            saved_data['descriptions'].append(desc)
            saved_data['weights'].append(weight)
            saved_data['scores'].append(score)
            saved_data['short_descriptions'].append(short_descs)
            w = float(weight) if weight and weight.replace('.', '', 1).replace('-', '', 1).isdigit() else 0
            s = float(score) if score and score.replace('.', '', 1).replace('-', '', 1).isdigit() else 0
            result = w * s / 100
            saved_data['results'].append("{:.2f}".format(result))
            total_score += result
        saved_data['total_score'] = "{:.2f}".format(total_score)

    elif form_id in ['core_behaviors', 'leadership_behaviors']:
        saved_data['scores'] = {}
        for key, value in request.form.items():
            if key.startswith('score_') and value:
                saved_data['scores'][key.replace('score_', '')] = value

    elif form_id == 'comments':
        existing_comments = load_form_data_from_db(target_employee_id, 'comments', eval_year) or {}
        saved_data['employee_comments'] = request.form.get('employee_comments', '')
        saved_data['supervisor_comments'] = existing_comments.get('supervisor_comments', '')

    if save_form_data_to_db_yearly(target_employee_id, form_id, eval_year, saved_data):
        flash("Progress saved successfully!", 'success')
    else:
        flash("Error: Could not save data to the database. Please contact support.", 'error')

    if action == 'save_next' and next_page:
        return redirect(url_for(next_page))
    else:
        # Redirect back to the same page
        page_map = {
            'group_kpi': 'group_kpi_page',
            'bu_lob_kpi': 'bu_lob_kpi_page',
            'org_capability': 'org_capability_page',
            'people_dev': 'people_dev_page',
            'bu_obj': 'bu_objectives_page',
            'core_behaviors': 'core_behaviors_page',
            'leadership_behaviors': 'leadership_behaviors_page',
            'comments': 'comments_page'
        }
        return redirect(url_for(page_map.get(form_id, 'profile_page')))


@app.route('/submit_self_evaluation', methods=['POST'])
def submit_self_evaluation():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    employee_id = str(session.get('employee_id', '')).strip()
    if not employee_id:
        return redirect(url_for('login'))

    eval_year = resolve_eval_year_from_request()
    if not can_edit_eval_year(employee_id, eval_year):
        flash(f"FY{eval_year} is locked for editing.", 'error')
        return redirect(url_for('summary_page', year=eval_year))

    status_payload = get_supervisor_review_status(employee_id, eval_year)
    status_update = dict(status_payload) if isinstance(status_payload, dict) else {}

    if bool(status_update.get('is_finalized')):
        flash("This evaluation has already been finalized.", 'info')
        return redirect(url_for('summary_page', year=eval_year))

    if bool(status_update.get('is_reviewed')):
        flash("This evaluation has already been reviewed and is pending finalization.", 'info')
        return redirect(url_for('summary_page', year=eval_year))

    validation_errors = validate_self_submission(
        employee_id,
        session.get('job_level'),
        eval_year,
        session.get('division'),
        session.get('company')
    )
    if validation_errors:
        flash("Submit for Review was blocked because the evaluation is still incomplete.", 'error')
        for message in validation_errors[:12]:
            flash(message, 'error')
        if len(validation_errors) > 12:
            flash(f"{len(validation_errors) - 12} more validation issue(s) still need to be fixed.", 'error')
        return redirect(url_for('summary_page', year=eval_year))

    status_update['is_submitted'] = True
    status_update['submitted_by'] = employee_id
    status_update['submitted_at'] = datetime.datetime.now().isoformat(timespec='seconds')

    save_supervisor_review_to_db(
        employee_id,
        employee_id,
        'supervisor_review_status',
        eval_year,
        status_update
    )
    if bool(status_payload.get('is_submitted')):
        flash("Self-evaluation resubmitted successfully. Your supervisor can now review the latest version.", 'success')
    else:
        flash("Self-evaluation submitted successfully. Your supervisor can now review it.", 'success')
    return redirect(url_for('summary_page', year=eval_year))


@app.route('/export_scores')
def export_scores():
    """Handles the CSV export, scheduling deletion after the file is sent."""

    ALLOWED_EXPORTERS = ['10300069', '10300098', '10300040', '10300064', '10300003', '10300004', '10300006', '10300200',
                         '10300071', '10300002', '10300016', '10300476', '10300299', '10300221', '10305007']
    employee_id = str(session.get('employee_id')).strip()
    reporting_employee_ids = get_reporting_employee_ids(employee_id)

    all_allowed_exporters = set(ALLOWED_EXPORTERS)
    for exporter_id in AUTHORIZED_EXPORTER_ID:
        all_allowed_exporters.add(exporter_id)

    if employee_id not in all_allowed_exporters:
        flash("You do not have permission to export scores. Access is restricted to administrators.", "error")
        return redirect(url_for('summary_page'))

    division_filter = SPECIAL_EXPORT_ACCESS.get(employee_id)

    temp_csv_file_name = f'performance_export_{employee_id}_{int(time.time())}.csv'
    temp_fd, temp_file_path = tempfile.mkstemp(suffix='.csv', prefix='score_export_')
    os.close(temp_fd)

    if export_scores_to_csv(temp_file_path, division_filter, employee_ids=reporting_employee_ids if reporting_employee_ids else None):

        @after_this_request
        def remove_file(response):
            try:
                if os.path.exists(temp_file_path):
                    os.remove(temp_file_path)
            except Exception as error:
                app.logger.error("Error cleaning up temporary file %s: %s", temp_file_path, error)
            return response

        try:
            response = send_file(
                temp_file_path,
                as_attachment=True,
                mimetype='text/csv',
                download_name=temp_csv_file_name
            )
            return response
        except Exception as e:
            if os.path.exists(temp_file_path):
                os.remove(temp_file_path)
            flash("Error processing the CSV file for download. Please try again.", "error")
            return redirect(url_for('summary_page'))
    else:
        if os.path.exists(temp_file_path):
            os.remove(temp_file_path)
        flash("Failed to generate scores CSV. Check database connection.", "error")
        return redirect(url_for('summary_page'))


@app.route('/export_summary_csv')
def export_summary_csv():
    """Handles summary CSV export for performance scores."""

    ALLOWED_EXPORTERS = ['10300069', '10300098', '10300040', '10300064', '10300003', '10300004', '10300006', '10300200',
                         '10300071', '10300002', '10300016', '10300476', '10300299', '10300221', '10305007']
    employee_id = str(session.get('employee_id')).strip()
    reporting_employee_ids = get_reporting_employee_ids(employee_id)

    all_allowed_exporters = set(ALLOWED_EXPORTERS)
    all_allowed_exporters.update(AUTHORIZED_EXPORTER_ID)

    if employee_id not in all_allowed_exporters:
        flash("You do not have permission to export scores. Access is restricted to administrators.", "error")
        return redirect(url_for('summary_page'))

    division_filter = SPECIAL_EXPORT_ACCESS.get(employee_id)

    temp_csv_file_name = f'performance_summary_export_{employee_id}_{int(time.time())}.csv'
    temp_fd, temp_file_path = tempfile.mkstemp(suffix='.csv', prefix='summary_export_')
    os.close(temp_fd)

    if export_summary_to_csv(temp_file_path, division_filter, employee_ids=reporting_employee_ids if reporting_employee_ids else None):

        @after_this_request
        def remove_file(response):
            try:
                if os.path.exists(temp_file_path):
                    os.remove(temp_file_path)
            except Exception as error:
                app.logger.error("Error cleaning up temporary file %s: %s", temp_file_path, error)
            return response

        try:
            response = send_file(
                temp_file_path,
                as_attachment=True,
                mimetype='text/csv',
                download_name=temp_csv_file_name
            )
            return response
        except Exception as e:
            if os.path.exists(temp_file_path):
                os.remove(temp_file_path)
            flash("Error processing the CSV file for download. Please try again.", "error")
            return redirect(url_for('summary_page'))
    else:
        if os.path.exists(temp_file_path):
            os.remove(temp_file_path)
        flash("Failed to generate summary CSV. Check database connection.", "error")
        return redirect(url_for('summary_page'))


@app.route('/email_summary')
def email_summary():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    employee_id = session['employee_id']
    profile = get_employee_profile(employee_id)
    user_data = session.get('user_data', {})

    if not profile:
        return "Profile not found.", 404

    job_level = profile['job_level']

    # Load all the data needed by the template
    bu_lob_kpi_data = get_form_data('bu_lob_kpi')
    org_cap_data = get_form_data('org_capability')
    people_dev_data = get_form_data('people_dev')
    bu_obj_data = get_form_data('bu_obj')
    comments_data = get_form_data('comments')
    core_behaviors_data = get_form_data('core_behaviors')
    leadership_behaviors_data = get_form_data('leadership_behaviors')
    group_kpi_data = get_form_data('group_kpi')

    # Helper function
    def filter_table_data(data, num_rows):
        if not data:
            return []
        filtered_rows = []
        for i in range(num_rows):
            desc_val = data['descriptions'][i].strip() if i < len(data.get('descriptions', [])) and \
                                                          data['descriptions'][i] else ''
            score_val = data['scores'][i].strip() if i < len(data.get('scores', [])) and data['scores'][i] else ''
            if desc_val:
                filtered_rows.append({'description': desc_val, 'score': score_val})
        return filtered_rows

    # Filtering logic
    bu_lob_kpi_filtered = filter_table_data(bu_lob_kpi_data, 5)
    org_cap_filtered = filter_table_data(org_cap_data, 10)
    people_dev_filtered = filter_table_data(people_dev_data, 10)
    bu_obj_filtered = filter_table_data(bu_obj_data, 15)
    group_score_str = group_kpi_data.get('group_score', '')
    group_score_val = float(group_score_str) if group_score_str.replace('.', '', 1).isdigit() else 0
    has_group_kpi_data = (job_level >= 8 and group_score_val > 0)

    # Render the print HTML as a string
    html_string = render_template_string(
        PRINT_SUMMARY_HTML,
        profile=profile,
        group_kpi_data=group_kpi_data,
        bu_lob_kpi_data=bu_lob_kpi_data,
        org_cap_data=org_cap_data,
        people_dev_data=people_dev_data,
        bu_obj_data=bu_obj_data,
        comments_data=comments_data,
        core_behaviors_data=core_behaviors_data,
        leadership_behaviors_data=leadership_behaviors_data,
        core_behaviors_map=get_core_behaviors_display_map(job_level),
        leadership_behaviors_map=get_leadership_behaviors_display_map(job_level),
        summary_data=user_data.get('summary_data', {}),
        job_level=job_level,
        bu_lob_kpi_filtered=bu_lob_kpi_filtered,
        org_cap_filtered=org_cap_filtered,
        people_dev_filtered=people_dev_filtered,
        bu_obj_filtered=bu_obj_filtered,
        has_group_kpi_data=has_group_kpi_data,
    )

    # Convert the HTML string to a PDF in memory
    tailwind_css = CSS('https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css')
    pdf = HTML(string=html_string).write_pdf(stylesheets=[tailwind_css])

    # Create a response to send the PDF as a file
    response = make_response(pdf)
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = f'attachment; filename=PE_Summary_{session["full_name"]}_{employee_id}.pdf'

    return response

def add_theme_switcher(input_file, output_file=None):
    """Add theme switcher to the Flask app file"""
    
    if not os.path.exists(input_file):
        print(f"❌ Error: File '{input_file}' not found!")
        return False
    
    # Read the original file
    with open(input_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check if already installed
    if 'theme-toggle' in content and 'themeToggle' in content:
        print("⚠️  Theme switcher already appears to be installed!")
        response = input("Do you want to reinstall? (y/n): ")
        if response.lower() != 'y':
            return False
    
    # Backup original file
    backup_file = input_file + '.backup'
    with open(backup_file, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"✅ Backup created: {backup_file}")
    
    # 1. Add CSS after .logout-btn:hover
    css_pattern = r'(\.logout-btn:hover \{[^}]+\})'
    if re.search(css_pattern, content):
        content = re.sub(
            css_pattern,
            r'\1\n' + THEME_CSS,
            content,
            count=1
        )
        print("✅ CSS added successfully")
    else:
        print("⚠️  Warning: Could not find .logout-btn:hover to add CSS")
    
    # 2. Add HTML in sidebar before </aside>
    sidebar_pattern = r'(<div class="sidebar-footer">.*?</div>\s*)(</aside>)'
    if re.search(sidebar_pattern, content, re.DOTALL):
        content = re.sub(
            sidebar_pattern,
            r'\1' + THEME_HTML + r'\2',
            content,
            count=1,
            flags=re.DOTALL
        )
        print("✅ HTML added successfully")
    else:
        print("⚠️  Warning: Could not find sidebar-footer to add HTML")
    
    # 3. Add JavaScript before </body>
    js_pattern = r'(</script>\s*)(</body>)'
    if re.search(js_pattern, content):
        content = re.sub(
            js_pattern,
            r'\1' + THEME_JS + r'\n\2',
            content,
            count=1
        )
        print("✅ JavaScript added successfully")
    else:
        print("⚠️  Warning: Could not find </body> to add JavaScript")
    
    # Write the modified content
    output_path = output_file if output_file else input_file
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"\n✅ Theme switcher installed successfully!")
    print(f"📄 Modified file: {output_path}")
    print(f"💾 Backup saved as: {backup_file}")
    print(f"\n🎉 Next steps:")
    print(f"   1. Restart your Flask application")
    print(f"   2. Login and check the sidebar")
    print(f"   3. Look for the theme toggle at the bottom")
    print(f"   4. Test switching between light and dark modes")
    
    return True

def main():
    """Main function"""
    print("=" * 60)
    print("Theme Switcher Auto-Installer")
    print("Performance Evaluation System")
    print("=" * 60)
    print()
    
    if len(sys.argv) < 2:
        print("Usage: python add_theme_switcher.py <path_to_app.py> [output_file]")
        print()
        print("Examples:")
        print("  python add_theme_switcher.py app.py")
        print("  python add_theme_switcher.py app.py app_with_theme.py")
        return
    
    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None
    
    success = add_theme_switcher(input_file, output_file)
    
    if success:
        print("\n✨ Installation complete!")
    else:
        print("\n❌ Installation failed or cancelled")


# =====================================================================
# Performance Evaluation Dashboard - View subordinates' PE scores by division/department
# =====================================================================

performance_dashboard_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<style>
[data-theme="dark"] .dashboard-subtitle,
[data-theme="dark"] .promotion-nominations-subtitle,
[data-theme="dark"] .promotion-nomination-name {
    color: #e5e7eb !important;
}
</style>
<div class="header-section">
    <h1 class="gradient-text">Performance Evaluation Dashboard</h1>
    <p class="dashboard-subtitle">View and export employees' performance evaluation scores</p>
</div>

<div class="alert-info" style="margin-bottom: 20px;">
    {% if is_super_director %}
    <div><strong>Company:</strong> {{ selected_company if selected_company and selected_company != 'ALL' else 'All Companies' }}</div>
    <div><strong>Division:</strong> {{ divisions|join(', ') if divisions else 'All Divisions' }}</div>
    <div><strong>Department:</strong> {{ selected_department if selected_department and selected_department != 'ALL' else 'All Departments' }}</div>
    {% else %}
    <div><strong>Division:</strong> {{ divisions|join(', ') if divisions else 'All Divisions' }}</div>
    {% if show_dept_filters %}
    <div><strong>Department:</strong> {{ selected_department if selected_department and selected_department != 'ALL' else 'All Departments' }}</div>
    {% endif %}
    {% endif %}
</div>

{% if selected_year %}
<form method="get" action="{{ url_for('performance_dashboard') }}" style="margin-bottom: 20px;">
    <label class="modern-label" for="eval_year">Select Fiscal Year:</label>
    <select id="eval_year" name="year" class="modern-select" style="width: 200px; display: inline-block;" onchange="this.form.submit()">
        {% for y in available_years %}
        <option value="{{ y }}" {% if y == selected_year %}selected{% endif %}>{{ y }}</option>
        {% endfor %}
    </select>
</form>
{% endif %}

{% if is_super_director %}
<form method="get" action="{{ url_for('performance_dashboard') }}" style="margin-bottom: 20px;">
    <input type="hidden" name="year" value="{{ selected_year }}">
    <div style="display: flex; flex-wrap: wrap; gap: 12px 24px; align-items: center;">
        <div style="display: inline-flex; align-items: center; gap: 6px;">
            <label class="modern-label" for="company_filter" style="margin-bottom: 0;">Company:</label>
            <select id="company_filter" name="company" class="modern-select" style="width: 320px; display: inline-block;" onchange="this.form.submit()">
                <option value="ALL" {% if not selected_company or selected_company == "ALL" %}selected{% endif %}>All Companies</option>
                {% for c in available_companies %}
                <option value="{{ c }}" {% if c == selected_company %}selected{% endif %}>{{ c }}</option>
                {% endfor %}
            </select>
        </div>
        <div style="display: inline-flex; align-items: center; gap: 6px;">
            <label class="modern-label" for="division_filter" style="margin-bottom: 0;">Division:</label>
            <select id="division_filter" name="division" class="modern-select" style="width: 360px; display: inline-block;" onchange="this.form.submit()">
                <option value="ALL" {% if not selected_division or selected_division == "ALL" %}selected{% endif %}>All Divisions</option>
                {% for d in available_divisions %}
                <option value="{{ d }}" {% if d == selected_division %}selected{% endif %}>{{ d }}</option>
                {% endfor %}
            </select>
        </div>
        <div style="display: inline-flex; align-items: center; gap: 6px;">
            <label class="modern-label" for="department_filter" style="margin-bottom: 0;">Department:</label>
            <select id="department_filter" name="department" class="modern-select" style="width: 480px; display: inline-block;" onchange="this.form.submit()">
                <option value="ALL" {% if not selected_department or selected_department == "ALL" %}selected{% endif %}>All Departments</option>
                {% for d in available_departments %}
                <option value="{{ d }}" {% if d == selected_department %}selected{% endif %}>{{ d }}</option>
                {% endfor %}
            </select>
        </div>
        <a href="{{ url_for('performance_dashboard', year=selected_year) }}" class="btn-secondary">Clear Filters</a>
    </div>
</form>
{% endif %}

{% if show_dept_filters %}
<form method="get" action="{{ url_for('performance_dashboard') }}" style="margin-bottom: 20px;">
    <input type="hidden" name="year" value="{{ selected_year }}">
    <div style="display: flex; flex-wrap: wrap; gap: 12px 24px; align-items: center;">
        <div style="display: inline-flex; align-items: center; gap: 6px;">
            <label class="modern-label" for="division_filter_mgr" style="margin-bottom: 0;">Division:</label>
            <select id="division_filter_mgr" name="division" class="modern-select" style="width: 360px; display: inline-block;" onchange="this.form.submit()">
                <option value="ALL" {% if not selected_division or selected_division == "ALL" %}selected{% endif %}>All Divisions</option>
                {% for d in available_divisions %}
                <option value="{{ d }}" {% if d == selected_division %}selected{% endif %}>{{ d }}</option>
                {% endfor %}
            </select>
        </div>
        <div style="display: inline-flex; align-items: center; gap: 6px;">
            <label class="modern-label" for="department_filter_mgr" style="margin-bottom: 0;">Department:</label>
            <select id="department_filter_mgr" name="department" class="modern-select" style="width: 480px; display: inline-block;" onchange="this.form.submit()">
                <option value="ALL" {% if not selected_department or selected_department == "ALL" %}selected{% endif %}>All Departments</option>
                {% for d in available_departments %}
                <option value="{{ d }}" {% if d == selected_department %}selected{% endif %}>{{ d }}</option>
                {% endfor %}
            </select>
        </div>
        <a href="{{ url_for('performance_dashboard', year=selected_year) }}" class="btn-secondary">Clear Filters</a>
    </div>
</form>
{% endif %}

<form method="get" action="{{ url_for('performance_dashboard') }}" style="margin-bottom: 20px;">
    <input type="hidden" name="year" value="{{ selected_year }}">
    {% if division_param %}
    <input type="hidden" name="division" value="{{ division_param }}">
    {% endif %}
    {% if department_param %}
    <input type="hidden" name="department" value="{{ department_param }}">
    {% endif %}
    {% if company_param %}
    <input type="hidden" name="company" value="{{ company_param }}">
    {% endif %}
    <label class="modern-label" for="name_search">Search by Employee Name:</label>
    <input id="name_search" name="q" class="modern-input" style="width: 360px; display: inline-block;" placeholder="Type a name..." value="{{ search_query }}">
    <button type="submit" class="btn-secondary" style="margin-left: 10px;">Search</button>
</form>

<!-- Summary Statistics -->
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
    <div style="background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); color: white; padding: 20px; border-radius: 12px; text-align: center;">
    <div style="font-size: 2em; font-weight: bold;">{{ total_staff }}</div>
    <div style="opacity: 0.9;">Total Permanent Employee</div>
    </div>
    <div style="background: linear-gradient(135deg, #059669 0%, #10b981 100%); color: white; padding: 20px; border-radius: 12px; text-align: center;">
        <div style="font-size: 2em; font-weight: bold;">{{ "%.2f"|format(avg_score) }}</div>
        <div style="opacity: 0.9;">Average Score</div>
    </div>
    <div style="background: linear-gradient(135deg, #f97316 0%, #fbbf24 100%); color: white; padding: 20px; border-radius: 12px; text-align: center;">
        <div style="font-size: 2em; font-weight: bold;">{{ "%.2f"|format(max_score) }}</div>
        <div style="opacity: 0.9;">Max Score</div>
    </div>
    <div style="background: linear-gradient(135deg, #0ea5e9 0%, #38bdf8 100%); color: white; padding: 20px; border-radius: 12px; text-align: center;">
        <div style="font-size: 2em; font-weight: bold;">{{ "%.2f"|format(min_score) }}</div>
        <div style="opacity: 0.9;">Min Score</div>
    </div>
    <div style="background: linear-gradient(135deg, #7c3aed 0%, #a855f7 100%); color: white; padding: 20px; border-radius: 12px; text-align: center;">
        <div style="font-size: 2em; font-weight: bold;">{{ proposed_staff_count }}</div>
        <div style="opacity: 0.9;">Proposed for Promotion</div>
    </div>
</div>

<!-- Export Buttons -->
<style>
.shared-kpi-btn {
    background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%) !important;
    color: #ffffff !important;
    border: 1px solid #1e40af !important;
}
.shared-kpi-btn:hover {
    background: linear-gradient(135deg, #1e40af 0%, #1d4ed8 100%) !important;
    color: #ffffff !important;
}
.shared-kpi-btn:active,
.shared-kpi-btn:focus,
.shared-kpi-btn:focus-visible {
    background: #ffffff !important;
    color: #1e3a5f !important;
    border: 1px solid #1e3a5f !important;
}
.score-analysis-btn {
    background: linear-gradient(135deg, #0f234f 0%, #1e3a73 100%) !important;
    color: #ffffff !important;
    border: 1px solid #0f234f !important;
}
.score-analysis-btn:hover {
    background: #ffffff !important;
    color: #0f234f !important;
    border: 1px solid #0f234f !important;
}
.score-analysis-btn:active,
.score-analysis-btn:focus,
.score-analysis-btn:focus-visible {
    background: #ffffff !important;
    color: #0f234f !important;
    border: 1px solid #0f234f !important;
}
</style>
<div class="button-group" style="margin-bottom: 20px;">
    <a href="{{ url_for('director_export_csv', year=selected_year) }}" class="btn-success">Export CSV</a>
    <a href="{{ url_for('director_export_summary_csv', year=selected_year) }}" class="btn-success">Export Summary CSV</a>
    {% if can_access_distribution %}
    <a href="{{ url_for('performance_distribution', year=selected_year, division=division_param, department=department_param, company=company_param) }}" class="btn-secondary score-analysis-btn">Performance Score Analysis</a>
    {% endif %}
    {% if is_super_admin %}
    <a href="{{ url_for('division_revenue_ebitda_admin_page', year=selected_year) }}" class="btn-secondary shared-kpi-btn">Shared KPI Scores</a>
    {% endif %}
</div>

<!-- Subordinates Table -->
<div id="performance-scores-summary" style="display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 15px; flex-wrap: wrap;">
    <h2 class="gradient-text" style="margin: 0;">Performance Scores Summary</h2>
    <form method="get" action="{{ url_for('performance_dashboard') }}#performance-scores-summary" style="display: inline-flex; align-items: center; gap: 10px;">
        <input type="hidden" name="year" value="{{ selected_year }}">
        {% if division_param %}
        <input type="hidden" name="division" value="{{ division_param }}">
        {% endif %}
        {% if department_param %}
        <input type="hidden" name="department" value="{{ department_param }}">
        {% endif %}
        {% if company_param %}
        <input type="hidden" name="company" value="{{ company_param }}">
        {% endif %}
        {% if search_query %}
        <input type="hidden" name="q" value="{{ search_query }}">
        {% endif %}
        <input type="hidden" name="sort_by" value="final_score">
        <button type="submit" name="sort_dir" value="asc" class="btn-secondary">Ascending Score</button>
        <button type="submit" name="sort_dir" value="desc" class="btn-secondary">Descending Score</button>
        <a href="{{ url_for('performance_dashboard', year=selected_year, division=division_param, department=department_param, company=company_param, q=search_query) }}#performance-scores-summary" class="btn-secondary">Reset</a>
    </form>
</div>

{% if subordinates %}
<div style="overflow-x: auto;">
    <table class="modern-table">
        <thead>
            <tr>
                <th>Emp. ID</th>
                <th>Full Name</th>
                <th>Position</th>
                <th>Job Level</th>
                <th>Status</th>
                <th>Promotion Status</th>
                <th style="text-align: right;">Group KPI</th>
                <th style="text-align: right;">BU/LoB KPI</th>
                <th style="text-align: right;">Org Cap</th>
                <th style="text-align: right;">People Dev</th>
                <th style="text-align: right;">BU Obj</th>
                <th class="score-col-emphasis" style="text-align: right;">Perf KPI</th>
                <th class="score-col-emphasis" style="text-align: right;">Core Bhv</th>
                <th class="score-col-emphasis" style="text-align: right;">Lead Bhv</th>
                <th style="text-align: right; background: linear-gradient(135deg, #166534 0%, #15803d 100%); color: #ffffff;">Final Score</th>
                <th style="text-align:center;">Action</th>
            </tr>
        </thead>
        <tbody>
            {% for sub in subordinates %}
            <tr>
                <td><code>{{ sub.employee_id }}</code></td>
                <td>{{ sub.full_name }}</td>
                <td>{{ sub.position or '-' }}</td>
                <td>{{ sub.job_level or '-' }}</td>
                <td>
                    <span style="display:inline-flex; align-items:center; padding:5px 10px; border-radius:999px; font-size:0.82em; font-weight:700; white-space:nowrap; background: {{ sub.workflow_status.bg }}; color: {{ sub.workflow_status.color }}; border: 1px solid {{ sub.workflow_status.border }};">
                        {{ sub.workflow_status.label }}
                    </span>
                </td>
                <td>
                    <span style="display:inline-flex; align-items:center; padding:5px 10px; border-radius:999px; font-size:0.82em; font-weight:700; white-space:nowrap; background: {{ sub.promotion_status.bg }}; color: {{ sub.promotion_status.color }}; border: 1px solid {{ sub.promotion_status.border }};">
                        {{ sub.promotion_status.label }}
                    </span>
                </td>
                <td style="text-align: right;">{{ "%.2f"|format(sub.group_kpi_score|float) if sub.group_kpi_score else '-' }}</td>
                <td style="text-align: right;">{{ "%.2f"|format(sub.bu_lob_kpi_total_score|float) if sub.bu_lob_kpi_total_score else '-' }}</td>
                <td style="text-align: right;">{{ "%.2f"|format(sub.org_cap_total_score|float) if sub.org_cap_total_score else '-' }}</td>
                <td style="text-align: right;">{{ "%.2f"|format(sub.people_dev_total_score|float) if sub.people_dev_total_score else '-' }}</td>
                <td style="text-align: right;">{{ "%.2f"|format(sub.bu_obj_total_score|float) if sub.bu_obj_total_score else '-' }}</td>
                <td class="score-col-emphasis" style="text-align: right;">{{ "%.2f"|format(sub.perf_kpi_score|float) if sub.perf_kpi_score else '-' }}</td>
                <td class="score-col-emphasis" style="text-align: right;">{{ "%.2f"|format(sub.core_behaviors_total_score|float) if sub.core_behaviors_total_score else '-' }}</td>
                <td class="score-col-emphasis" style="text-align: right;">{{ "%.2f"|format(sub.leadership_behaviors_total_score|float) if sub.leadership_behaviors_total_score else '-' }}</td>
                <td style="text-align: right; font-weight: bold; color: #ffffff; background: linear-gradient(135deg, #166534 0%, #15803d 100%);">
                    {{ "%.2f"|format(sub.final_total_score|float) if sub.final_total_score else '-' }}
                </td>
                <td>
                    <div style="display: inline-flex; align-items: center; gap: 6px;">
                        <div style="display:flex; gap:8px; justify-content:flex-end;">
                            <a href="{{ url_for('director_view_subordinate', employee_id=sub.employee_id, year=selected_year) }}" class="btn-primary" style="padding: 5px 10px; font-size: 0.85em;">View</a>
                            {% if sub.can_submit_promotion %}
                            <a href="{{ url_for('staff_promotion_form', employee_id=sub.employee_id, year=selected_year) }}" class="btn-secondary" style="padding: 5px 10px; font-size: 0.85em;">Promotion</a>
                            {% endif %}
                        </div>
                    </div>
                </td>
            </tr>
            {% endfor %}
        </tbody>
    </table>
</div>
{% if total_pages > 1 %}
<div class="button-group" style="margin-top: 20px;">
    {% if current_page > 1 %}
    <a href="{{ url_for('performance_dashboard', year=selected_year, division=division_param, department=department_param, company=company_param, q=search_query, sort_by=sort_by, sort_dir=sort_dir, page=current_page - 1) }}#performance-scores-summary" class="btn-secondary">Previous</a>
    {% endif %}
    <div class="page-count" style="align-self: center; font-weight: 600;">Page {{ current_page }} of {{ total_pages }}</div>
    {% if current_page < total_pages %}
    <a href="{{ url_for('performance_dashboard', year=selected_year, division=division_param, department=department_param, company=company_param, q=search_query, sort_by=sort_by, sort_dir=sort_dir, page=current_page + 1) }}#performance-scores-summary" class="btn-secondary">Next</a>
    {% endif %}
</div>
{% endif %}
{% else %}
<div class="alert-warning">
    <strong>No subordinates found.</strong> There are no employees in your assigned division(s) with completed evaluations.
</div>
{% endif %}

<div class="button-group" style="margin-top: 30px;">
    <a href="{{ url_for('performance_dashboard') }}" class="btn-secondary">Back</a>\r\n    <a href="{{ url_for('profile_page') }}" class="btn-primary">Back to Profile</a>
</div>
{% endblock %}
''')


PERFORMANCE_DISTRIBUTION_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<style>
@media print {
    .sidebar,
    .button-group,
    form,
    .btn-primary,
    .btn-secondary,
    .btn-success {
        display: none !important;
    }

    body {
        background: #ffffff !important;
    }

    .main-content,
    .content-card,
    .header-section,
    .alert-info,
    .alert-warning {
        box-shadow: none !important;
        background: #ffffff !important;
    }

    .content-card,
    .alert-info,
    .alert-warning,
    table,
    svg {
        break-inside: avoid;
        page-break-inside: avoid;
    }

    .modern-table {
        font-size: 11px !important;
    }

    .modern-table th,
    .modern-table td {
        padding: 7px 8px !important;
    }

    .distribution-print-header {
        display: block !important;
        margin-bottom: 18px !important;
        padding: 0 0 14px 0 !important;
        border-bottom: 2px solid #cbd5e1 !important;
    }

    .distribution-live-header {
        display: none !important;
    }
}

.distribution-print-header {
    display: none;
}
</style>
{% if keep_focus_section in ['compare-units', 'division-compare'] %}
<script>
document.addEventListener('DOMContentLoaded', function() {
    const section = document.getElementById('{{ keep_focus_section }}');
    if (section) {
        const scrollToSection = function() {
            const top = section.getBoundingClientRect().top + window.pageYOffset - 16;
            window.scrollTo({ top: top, behavior: 'auto' });
            const targetHash = '#{{ keep_focus_section }}';
            if (window.location.hash !== targetHash) {
                history.replaceState(null, '', targetHash);
            }
        };
        requestAnimationFrame(scrollToSection);
        setTimeout(scrollToSection, 120);
    }
});
</script>
{% endif %}
{% if selected_band and keep_focus_section not in ['compare-units', 'division-compare'] %}
<script>
document.addEventListener('DOMContentLoaded', function() {
    const section = document.getElementById('employee-ranking');
    if (section) {
        const scrollToSection = function() {
            const top = section.getBoundingClientRect().top + window.pageYOffset - 16;
            window.scrollTo({ top: top, behavior: 'auto' });
            if (window.location.hash !== '#employee-ranking') {
                history.replaceState(null, '', '#employee-ranking');
            }
        };
        requestAnimationFrame(scrollToSection);
        setTimeout(scrollToSection, 120);
    }
});
</script>
{% endif %}
<div class="distribution-print-header">
    <div style="font-size: 26px; font-weight: 800; color: #0f172a; margin-bottom: 4px;">TCC Technology Group</div>
    <div style="font-size: 20px; font-weight: 700; color: #1e3a5f; margin-bottom: 10px;">Performance Score Analysis Brief</div>
    <div style="display:grid; grid-template-columns: repeat(2, minmax(220px, 1fr)); gap: 8px 18px; font-size: 12px; color: #334155;">
        <div><strong>Fiscal Year:</strong> {{ selected_year }}</div>
        <div><strong>Prepared:</strong> {{ printed_at_text }}</div>
        {% if is_super_director %}
        <div><strong>Company:</strong> {{ selected_company if selected_company and selected_company != 'ALL' else 'All Companies' }}</div>
        {% endif %}
        <div><strong>Division:</strong> {{ division_scope_text }}</div>
        {% if department_scope_text %}
        <div><strong>Department:</strong> {{ department_scope_text }}</div>
        {% endif %}
        {% if selected_band %}
        <div><strong>Selected Band:</strong> {{ selected_band }}</div>
        {% endif %}
    </div>
</div>
<div class="header-section">
    <div class="distribution-live-header" style="display:flex; flex-direction:column; align-items:center; gap:12px;">
        <div style="width:100%; text-align:center;">
            <h1 class="gradient-text">Performance Score Analysis</h1>
            <p>Review score distribution, ranking, and drill into each employee's PE summary.</p>
        </div>
        <div style="width:100%; display:flex; justify-content:flex-end;">
            <a href="{{ url_for('print_performance_distribution', year=selected_year, division=division_param, department=department_param, company=company_param, band=selected_band, sort_dir=sort_dir, dept_compare_company=dept_compare_company, dept_compare_division=dept_compare_division, compare_units=selected_compare_units, div_compare_company=div_compare_company, compare_division_1=selected_compare_divisions[0] if selected_compare_divisions|length > 0 else None, compare_division_2=selected_compare_divisions[1] if selected_compare_divisions|length > 1 else None, compare_division_3=selected_compare_divisions[2] if selected_compare_divisions|length > 2 else None, compare_division_4=selected_compare_divisions[3] if selected_compare_divisions|length > 3 else None) }}" class="btn-success" target="_blank">Export Score Analysis Brief</a>
        </div>
    </div>
</div>

<div class="alert-info" style="margin-bottom: 20px;">
    {% if is_super_director %}
    <div><strong>Company:</strong> {{ selected_company if selected_company and selected_company != 'ALL' else 'All Companies' }}</div>
    {% endif %}
    <div><strong>Division:</strong> {{ division_scope_text }}</div>
    {% if department_scope_text %}
    <div><strong>Department:</strong> {{ department_scope_text }}</div>
    {% endif %}
</div>

{% if selected_year %}
<form method="get" action="{{ url_for('performance_distribution') }}" style="margin-bottom: 20px;">
    <input type="hidden" name="division" value="{{ division_param or '' }}">
    <input type="hidden" name="department" value="{{ department_param or '' }}">
    <input type="hidden" name="company" value="{{ company_param or '' }}">
    <input type="hidden" name="band" value="{{ selected_band or '' }}">
    <input type="hidden" name="dept_compare_company" value="{{ dept_compare_company }}">
    <input type="hidden" name="dept_compare_division" value="{{ dept_compare_division }}">
    <input type="hidden" name="div_compare_company" value="{{ div_compare_company }}">
    {% for unit in selected_compare_units %}
    <input type="hidden" name="compare_units" value="{{ unit }}">
    {% endfor %}
    {% for division_name in selected_compare_divisions %}
    <input type="hidden" name="compare_division_{{ loop.index }}" value="{{ division_name }}">
    {% endfor %}
    <label class="modern-label" for="eval_year_dist">Select Fiscal Year:</label>
    <select id="eval_year_dist" name="year" class="modern-select" style="width: 200px; display: inline-block;" onchange="this.form.submit()">
        {% for y in available_years %}
        <option value="{{ y }}" {% if y == selected_year %}selected{% endif %}>{{ y }}</option>
        {% endfor %}
    </select>
</form>
{% endif %}

{% if is_super_director %}
<form method="get" action="{{ url_for('performance_distribution') }}" style="margin-bottom: 20px;">
    <input type="hidden" name="year" value="{{ selected_year }}">
    <input type="hidden" name="band" value="{{ selected_band or '' }}">
    <input type="hidden" name="dept_compare_company" value="{{ dept_compare_company }}">
    <input type="hidden" name="dept_compare_division" value="{{ dept_compare_division }}">
    <input type="hidden" name="div_compare_company" value="{{ div_compare_company }}">
    {% for unit in selected_compare_units %}
    <input type="hidden" name="compare_units" value="{{ unit }}">
    {% endfor %}
    {% for division_name in selected_compare_divisions %}
    <input type="hidden" name="compare_division_{{ loop.index }}" value="{{ division_name }}">
    {% endfor %}
    <div style="display: flex; flex-wrap: wrap; gap: 12px 24px; align-items: center;">
        <div style="display: inline-flex; align-items: center; gap: 6px;">
            <label class="modern-label" for="company_filter_dist" style="margin-bottom: 0;">Company:</label>
            <select id="company_filter_dist" name="company" class="modern-select" style="width: 320px; display: inline-block;" onchange="this.form.submit()">
                <option value="ALL" {% if not selected_company or selected_company == "ALL" %}selected{% endif %}>All Companies</option>
                {% for c in available_companies %}
                <option value="{{ c }}" {% if c == selected_company %}selected{% endif %}>{{ c }}</option>
                {% endfor %}
            </select>
        </div>
        <div style="display: inline-flex; align-items: center; gap: 6px;">
            <label class="modern-label" for="division_filter_dist" style="margin-bottom: 0;">Division:</label>
            <select id="division_filter_dist" name="division" class="modern-select" style="width: 360px; display: inline-block;" onchange="this.form.submit()">
                <option value="ALL" {% if not selected_division or selected_division == "ALL" %}selected{% endif %}>All Divisions</option>
                {% for d in available_divisions %}
                <option value="{{ d }}" {% if d == selected_division %}selected{% endif %}>{{ d }}</option>
                {% endfor %}
            </select>
        </div>
        <div style="display: inline-flex; align-items: center; gap: 6px;">
            <label class="modern-label" for="department_filter_dist" style="margin-bottom: 0;">Department:</label>
            <select id="department_filter_dist" name="department" class="modern-select" style="width: 480px; display: inline-block;" onchange="this.form.submit()">
                <option value="ALL" {% if not selected_department or selected_department == "ALL" %}selected{% endif %}>All Departments</option>
                {% for d in available_departments %}
                <option value="{{ d }}" {% if d == selected_department %}selected{% endif %}>{{ d }}</option>
                {% endfor %}
            </select>
        </div>
        <a href="{{ url_for('performance_distribution', year=selected_year) }}" class="btn-secondary">Clear Filters</a>
    </div>
</form>
{% elif show_dept_filters %}
<form method="get" action="{{ url_for('performance_distribution') }}" style="margin-bottom: 20px;">
    <input type="hidden" name="year" value="{{ selected_year }}">
    <input type="hidden" name="band" value="{{ selected_band or '' }}">
    <input type="hidden" name="dept_compare_company" value="{{ dept_compare_company }}">
    <input type="hidden" name="dept_compare_division" value="{{ dept_compare_division }}">
    <input type="hidden" name="div_compare_company" value="{{ div_compare_company }}">
    {% for unit in selected_compare_units %}
    <input type="hidden" name="compare_units" value="{{ unit }}">
    {% endfor %}
    {% for division_name in selected_compare_divisions %}
    <input type="hidden" name="compare_division_{{ loop.index }}" value="{{ division_name }}">
    {% endfor %}
    <div style="display: flex; flex-wrap: wrap; gap: 12px 24px; align-items: center;">
        <div style="display: inline-flex; align-items: center; gap: 6px;">
            <label class="modern-label" for="division_filter_mgr_dist" style="margin-bottom: 0;">Division:</label>
            <select id="division_filter_mgr_dist" name="division" class="modern-select" style="width: 360px; display: inline-block;" onchange="this.form.submit()">
                <option value="ALL" {% if not selected_division or selected_division == "ALL" %}selected{% endif %}>All Divisions</option>
                {% for d in available_divisions %}
                <option value="{{ d }}" {% if d == selected_division %}selected{% endif %}>{{ d }}</option>
                {% endfor %}
            </select>
        </div>
        <div style="display: inline-flex; align-items: center; gap: 6px;">
            <label class="modern-label" for="department_filter_mgr_dist" style="margin-bottom: 0;">Department:</label>
            <select id="department_filter_mgr_dist" name="department" class="modern-select" style="width: 480px; display: inline-block;" onchange="this.form.submit()">
                <option value="ALL" {% if not selected_department or selected_department == "ALL" %}selected{% endif %}>All Departments</option>
                {% for d in available_departments %}
                <option value="{{ d }}" {% if d == selected_department %}selected{% endif %}>{{ d }}</option>
                {% endfor %}
            </select>
        </div>
        <a href="{{ url_for('performance_distribution', year=selected_year) }}" class="btn-secondary">Clear Filters</a>
    </div>
</form>
{% endif %}

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 18px; margin-bottom: 28px;">
    <div style="background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%); color: white; padding: 18px; border-radius: 12px; text-align: center;">
        <div style="font-size: 1.9em; font-weight: 700;">{{ total_staff }}</div>
        <div style="opacity: 0.92;">Headcount</div>
    </div>
    <div style="background: linear-gradient(135deg, #0f766e 0%, #14b8a6 100%); color: white; padding: 18px; border-radius: 12px; text-align: center;">
        <div style="font-size: 1.9em; font-weight: 700;">{{ "%.2f"|format(avg_score) }}</div>
        <div style="opacity: 0.92;">Mean</div>
    </div>
    <div style="background: linear-gradient(135deg, #4338ca 0%, #6366f1 100%); color: white; padding: 18px; border-radius: 12px; text-align: center;">
        <div style="font-size: 1.9em; font-weight: 700;">{{ "%.2f"|format(median_score) }}</div>
        <div style="opacity: 0.92;">Median</div>
    </div>
    <div style="background: linear-gradient(135deg, #f97316 0%, #fbbf24 100%); color: white; padding: 18px; border-radius: 12px; text-align: center;">
        <div style="font-size: 1.9em; font-weight: 700;">{{ "%.2f"|format(max_score) }}</div>
        <div style="opacity: 0.92;">Max</div>
    </div>
    <div style="background: linear-gradient(135deg, #475569 0%, #94a3b8 100%); color: white; padding: 18px; border-radius: 12px; text-align: center;">
        <div style="font-size: 1.9em; font-weight: 700;">{{ "%.2f"|format(min_score) }}</div>
        <div style="opacity: 0.92;">Min</div>
    </div>
</div>

<div class="content-card" style="margin-bottom: 24px;">
    <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; margin-bottom: 14px;">
        <h2 class="gradient-text" style="margin: 0;">Normal Distribution / Score Bands</h2>
        {% if selected_band %}
        <a href="{{ url_for('performance_distribution', year=selected_year, division=division_param, department=department_param, company=company_param) }}{{ compare_query_suffix }}" class="btn-secondary">Show All Bands</a>
        {% endif %}
    </div>
    <div style="margin-bottom: 16px; padding: 14px 16px; border: 1px solid #dbe4f0; border-radius: 12px; background: linear-gradient(180deg, #f8fbff 0%, #eef5ff 100%); overflow-x:auto;">
        <div style="font-weight: 700; color: #1e3a5f; margin-bottom: 10px; font-size: 1rem;">Bell Curve View</div>
        <svg viewBox="0 0 {{ curve_chart.width }} {{ curve_chart.height }}" style="width: 100%; min-width: 680px; max-width: 940px; height: auto; display: block; margin: 0 auto;">
            {% for tick in curve_chart.y_ticks %}
            <line x1="{{ curve_chart.left_pad }}" y1="{{ tick.y }}" x2="{{ curve_chart.width - curve_chart.right_pad }}" y2="{{ tick.y }}" stroke="#dbe4f0" stroke-width="1" stroke-dasharray="4 4"></line>
            <text x="{{ curve_chart.left_pad - 10 }}" y="{{ tick.y + 4 }}" text-anchor="end" font-size="11" fill="#64748b">{{ tick.value }}</text>
            {% endfor %}
            <line x1="{{ curve_chart.left_pad }}" y1="{{ curve_chart.baseline_y }}" x2="{{ curve_chart.width - curve_chart.right_pad }}" y2="{{ curve_chart.baseline_y }}" stroke="#94a3b8" stroke-width="1.4"></line>
            <polygon points="{{ curve_chart.area_polygon_points }}" fill="rgba(59, 130, 246, 0.16)"></polygon>
            <polyline points="{{ curve_chart.polyline_points }}" fill="none" stroke="#2563eb" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"></polyline>
            {% for point in curve_chart.points %}
            <circle cx="{{ point.x }}" cy="{{ point.y }}" r="4.5" fill="#1d4ed8"></circle>
            <text x="{{ point.x }}" y="{{ point.y - 10 }}" text-anchor="middle" font-size="11" font-weight="700" fill="#1e3a5f">{{ point.count }}</text>
            {% endfor %}
            {% for label in curve_chart.labels %}
            <text x="{{ label.x }}" y="{{ curve_chart.height - 14 }}" text-anchor="middle" font-size="10" fill="#64748b">{{ label.label }}</text>
            {% endfor %}
        </svg>
    </div>
    <div style="display:grid; gap:10px;">
        {% for band in distribution_rows %}
        <a href="{{ url_for('performance_distribution', year=selected_year, division=division_param, department=department_param, company=company_param, band=band.label) }}{{ compare_query_suffix }}#employee-ranking"
           style="text-decoration:none; color:inherit; border: 1px solid {% if selected_band == band.label %}#1d4ed8{% else %}#dbe4f0{% endif %}; border-radius: 12px; padding: 10px 12px; background: {% if selected_band == band.label %}linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%){% else %}#ffffff{% endif %};">
            <div style="display:grid; grid-template-columns: 150px 1fr 44px; align-items:center; gap:12px;">
                <div style="font-weight:700; color:#1e3a5f;">{{ band.label }}</div>
                <div style="height: 12px; background:#e2e8f0; border-radius:999px; overflow:hidden;">
                    <div style="height:100%; width: {{ '%.1f'|format(band.width_pct) }}%; background: linear-gradient(135deg, #1d4ed8 0%, #60a5fa 100%);"></div>
                </div>
                <div style="text-align:right; font-weight:700; color:#0f172a;">{{ band.count }}</div>
            </div>
        </a>
        {% endfor %}
    </div>
</div>

{% if is_super_director %}
<div class="content-card" id="division-compare" style="margin-bottom: 24px;">
    <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; margin-bottom: 14px;">
        <h2 class="gradient-text" style="margin: 0;">Division Distribution Comparison</h2>
        <div style="color:#64748b;">Compare up to 4 divisions within one company side by side.</div>
    </div>
    <form method="get" action="{{ url_for('performance_distribution') }}#division-compare" style="margin-bottom: 18px;">
        <input type="hidden" name="year" value="{{ selected_year }}">
        <input type="hidden" name="company" value="{{ company_param or '' }}">
        <input type="hidden" name="division" value="{{ division_param or '' }}">
        <input type="hidden" name="department" value="{{ department_param or '' }}">
        <input type="hidden" name="band" value="{{ selected_band or '' }}">
        <input type="hidden" name="sort_dir" value="{{ sort_dir }}">
        <input type="hidden" name="keep_focus" value="division-compare">
        <input type="hidden" name="dept_compare_company" value="{{ dept_compare_company }}">
        <input type="hidden" name="dept_compare_division" value="{{ dept_compare_division }}">
        {% for unit in selected_compare_units %}
        <input type="hidden" name="compare_units" value="{{ unit }}">
        {% endfor %}
        <div style="display:flex; flex-wrap:wrap; gap:14px 22px; align-items:flex-end;">
            <div>
                <label class="modern-label" for="division_compare_company" style="margin-bottom: 6px;">Company:</label>
                <select id="division_compare_company" name="div_compare_company" class="modern-select" style="width: 300px;" onchange="this.form.submit()">
                    <option value="ALL" {% if not div_compare_company or div_compare_company == 'ALL' %}selected{% endif %}>All Companies</option>
                    {% for option in compare_company_options %}
                    <option value="{{ option }}" {% if option == div_compare_company %}selected{% endif %}>{{ option }}</option>
                    {% endfor %}
                </select>
            </div>
            <div style="display:flex; flex-wrap:wrap; gap:12px 14px; align-items:flex-end;">
                <div>
                    <label class="modern-label" for="compare_division_1" style="margin-bottom: 6px;">Division 1:</label>
                    <select id="compare_division_1" name="compare_division_1" class="modern-select" style="width: 260px;">
                        <option value="">Select</option>
                        {% for option in division_compare_options %}
                        <option value="{{ option }}" {% if selected_compare_divisions|length > 0 and option == selected_compare_divisions[0] %}selected{% endif %}>{{ option }}</option>
                        {% endfor %}
                    </select>
                </div>
                {% if division_compare_options|length > 1 %}
                <div>
                    <label class="modern-label" for="compare_division_2" style="margin-bottom: 6px;">Division 2:</label>
                    <select id="compare_division_2" name="compare_division_2" class="modern-select" style="width: 260px;">
                        <option value="">Select</option>
                        {% for option in division_compare_options %}
                        <option value="{{ option }}" {% if selected_compare_divisions|length > 1 and option == selected_compare_divisions[1] %}selected{% endif %}>{{ option }}</option>
                        {% endfor %}
                    </select>
                </div>
                {% endif %}
                {% if division_compare_options|length > 2 %}
                <div>
                    <label class="modern-label" for="compare_division_3" style="margin-bottom: 6px;">Division 3:</label>
                    <select id="compare_division_3" name="compare_division_3" class="modern-select" style="width: 260px;">
                        <option value="">Select</option>
                        {% for option in division_compare_options %}
                        <option value="{{ option }}" {% if selected_compare_divisions|length > 2 and option == selected_compare_divisions[2] %}selected{% endif %}>{{ option }}</option>
                        {% endfor %}
                    </select>
                </div>
                {% endif %}
                {% if division_compare_options|length > 3 %}
                <div>
                    <label class="modern-label" for="compare_division_4" style="margin-bottom: 6px;">Division 4:</label>
                    <select id="compare_division_4" name="compare_division_4" class="modern-select" style="width: 260px;">
                        <option value="">Select</option>
                        {% for option in division_compare_options %}
                        <option value="{{ option }}" {% if selected_compare_divisions|length > 3 and option == selected_compare_divisions[3] %}selected{% endif %}>{{ option }}</option>
                        {% endfor %}
                    </select>
                </div>
                {% endif %}
            </div>
            <div class="button-group" style="margin: 0;">
                <button type="submit" class="btn-primary">Show Comparison</button>
                <a href="{{ url_for('performance_distribution', year=selected_year, division=division_param, department=department_param, company=company_param, band=selected_band, sort_dir=sort_dir) }}#division-compare" class="btn-secondary">Clear Comparison</a>
            </div>
        </div>
    </form>
    {% if division_compare_cards %}
    <div style="display:grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap:16px;">
        {% for card in division_compare_cards %}
        <div style="border:1px solid #dbe4f0; border-radius:14px; padding:14px; background:linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px; margin-bottom:10px;">
                <div style="font-weight:700; color:#1e3a5f; font-size:1rem;">{{ card.label }}</div>
                <div style="color:#64748b; font-size:0.9rem;">{{ card.headcount }} staff</div>
            </div>
            <div style="display:grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap:10px; margin-bottom:10px;">
                <div style="background:#eff6ff; border-radius:10px; padding:8px 10px; text-align:center;">
                    <div style="font-size:0.8rem; color:#64748b;">Mean</div>
                    <div style="font-weight:700; color:#1e3a5f;">{{ "%.2f"|format(card.avg_score) }}</div>
                </div>
                <div style="background:#f8fafc; border-radius:10px; padding:8px 10px; text-align:center;">
                    <div style="font-size:0.8rem; color:#64748b;">Max</div>
                    <div style="font-weight:700; color:#1e3a5f;">{{ "%.2f"|format(card.max_score) }}</div>
                </div>
                <div style="background:#f8fafc; border-radius:10px; padding:8px 10px; text-align:center;">
                    <div style="font-size:0.8rem; color:#64748b;">Min</div>
                    <div style="font-weight:700; color:#1e3a5f;">{{ "%.2f"|format(card.min_score) }}</div>
                </div>
            </div>
            <div style="padding:10px; border:1px solid #dbe4f0; border-radius:12px; background:#ffffff; overflow-x:auto;">
                <svg viewBox="0 0 {{ card.curve_chart.width }} {{ card.curve_chart.height }}" style="width: 100%; min-width: 300px; max-width: 430px; height: auto; display: block; margin: 0 auto;">
                    {% for tick in card.curve_chart.y_ticks %}
                    <line x1="{{ card.curve_chart.left_pad }}" y1="{{ tick.y }}" x2="{{ card.curve_chart.width - card.curve_chart.right_pad }}" y2="{{ tick.y }}" stroke="#e2e8f0" stroke-width="1" stroke-dasharray="3 4"></line>
                    {% endfor %}
                    <line x1="{{ card.curve_chart.left_pad }}" y1="{{ card.curve_chart.baseline_y }}" x2="{{ card.curve_chart.width - card.curve_chart.right_pad }}" y2="{{ card.curve_chart.baseline_y }}" stroke="#94a3b8" stroke-width="1.2"></line>
                    <polygon points="{{ card.curve_chart.area_polygon_points }}" fill="rgba(59, 130, 246, 0.14)"></polygon>
                    <polyline points="{{ card.curve_chart.polyline_points }}" fill="none" stroke="#2563eb" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"></polyline>
                    {% for point in card.curve_chart.points %}
                    <circle cx="{{ point.x }}" cy="{{ point.y }}" r="3.8" fill="#1d4ed8"></circle>
                    {% endfor %}
                    {% for label in card.curve_chart.labels %}
                    <text x="{{ label.x }}" y="{{ card.curve_chart.height - 14 }}" text-anchor="middle" font-size="8.5" fill="#64748b">{{ label.label }}</text>
                    {% endfor %}
                </svg>
            </div>
        </div>
        {% endfor %}
    </div>
    {% else %}
    <div class="alert-info" style="margin-bottom: 0;">
        Select up to four divisions within a company and click <strong>Show Comparison</strong>.
    </div>
    {% endif %}
</div>
{% endif %}

<div class="content-card" id="compare-units" style="margin-bottom: 24px;">
    <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; margin-bottom: 14px;">
        <h2 class="gradient-text" style="margin: 0;">Department Distribution Comparison</h2>
        <div style="color:#64748b;">Compare up to 4 departments side by side.</div>
    </div>
    <form method="get" action="{{ url_for('performance_distribution') }}#compare-units" style="margin-bottom: 18px;">
        <input type="hidden" name="year" value="{{ selected_year }}">
        <input type="hidden" name="company" value="{{ company_param or '' }}">
        <input type="hidden" name="division" value="{{ division_param or '' }}">
        <input type="hidden" name="department" value="{{ department_param or '' }}">
        <input type="hidden" name="band" value="{{ selected_band or '' }}">
        <input type="hidden" name="sort_dir" value="{{ sort_dir }}">
        <input type="hidden" name="keep_focus" value="compare-units">
        <div style="display:flex; flex-wrap:wrap; gap:14px 22px; align-items:flex-end;">
            {% if is_super_director %}
            <div>
                <label class="modern-label" for="dept_compare_company" style="margin-bottom: 6px;">Company:</label>
                <select id="dept_compare_company" name="dept_compare_company" class="modern-select" style="width: 300px;" onchange="this.form.submit()">
                    <option value="ALL" {% if not dept_compare_company or dept_compare_company == 'ALL' %}selected{% endif %}>All Companies</option>
                    {% for option in compare_company_options %}
                    <option value="{{ option }}" {% if option == dept_compare_company %}selected{% endif %}>{{ option }}</option>
                    {% endfor %}
                </select>
            </div>
            <div>
                <label class="modern-label" for="dept_compare_division" style="margin-bottom: 6px;">Division:</label>
                <select id="dept_compare_division" name="dept_compare_division" class="modern-select" style="width: 320px;" onchange="this.form.submit()">
                    <option value="ALL" {% if not dept_compare_division or dept_compare_division == 'ALL' %}selected{% endif %}>All Divisions</option>
                    {% for option in dept_compare_division_options %}
                    <option value="{{ option }}" {% if option == dept_compare_division %}selected{% endif %}>{{ option }}</option>
                    {% endfor %}
                </select>
            </div>
            {% else %}
            {% endif %}
            <div style="display:flex; flex-wrap:wrap; gap:12px 14px; align-items:flex-end;">
                {% if compare_unit_options|length > 0 %}
                <div>
                    <label class="modern-label" for="compare_unit_1" style="margin-bottom: 6px;">Department 1:</label>
                    <select id="compare_unit_1" name="compare_unit_1" class="modern-select" style="width: 260px;">
                        <option value="">Select</option>
                        {% for option in compare_unit_options %}
                        <option value="{{ option }}" {% if selected_compare_units|length > 0 and option == selected_compare_units[0] %}selected{% endif %}>{{ option }}</option>
                        {% endfor %}
                    </select>
                </div>
                {% endif %}
                {% if compare_unit_options|length > 1 %}
                <div>
                    <label class="modern-label" for="compare_unit_2" style="margin-bottom: 6px;">Department 2:</label>
                    <select id="compare_unit_2" name="compare_unit_2" class="modern-select" style="width: 260px;">
                        <option value="">Select</option>
                        {% for option in compare_unit_options %}
                        <option value="{{ option }}" {% if selected_compare_units|length > 1 and option == selected_compare_units[1] %}selected{% endif %}>{{ option }}</option>
                        {% endfor %}
                    </select>
                </div>
                {% endif %}
                {% if compare_unit_options|length > 2 %}
                <div>
                    <label class="modern-label" for="compare_unit_3" style="margin-bottom: 6px;">Department 3:</label>
                    <select id="compare_unit_3" name="compare_unit_3" class="modern-select" style="width: 260px;">
                        <option value="">Select</option>
                        {% for option in compare_unit_options %}
                        <option value="{{ option }}" {% if selected_compare_units|length > 2 and option == selected_compare_units[2] %}selected{% endif %}>{{ option }}</option>
                        {% endfor %}
                    </select>
                </div>
                {% endif %}
                {% if compare_unit_options|length > 3 %}
                <div>
                    <label class="modern-label" for="compare_unit_4" style="margin-bottom: 6px;">Department 4:</label>
                    <select id="compare_unit_4" name="compare_unit_4" class="modern-select" style="width: 260px;">
                        <option value="">Select</option>
                        {% for option in compare_unit_options %}
                        <option value="{{ option }}" {% if selected_compare_units|length > 3 and option == selected_compare_units[3] %}selected{% endif %}>{{ option }}</option>
                        {% endfor %}
                    </select>
                </div>
                {% endif %}
            </div>
            <div class="button-group" style="margin: 0;">
                <button type="submit" class="btn-primary">Show Comparison</button>
                <a href="{{ url_for('performance_distribution', year=selected_year, division=division_param, department=department_param, company=company_param, band=selected_band, sort_dir=sort_dir) }}#compare-units" class="btn-secondary">Clear Comparison</a>
            </div>
        </div>
    </form>
    {% if compare_cards %}
    <div style="display:grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap:16px;">
        {% for card in compare_cards %}
        <div style="border:1px solid #dbe4f0; border-radius:14px; padding:14px; background:linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px; margin-bottom:10px;">
                <div style="font-weight:700; color:#1e3a5f; font-size:1rem;">{{ card.label }}</div>
                <div style="color:#64748b; font-size:0.9rem;">{{ card.headcount }} staff</div>
            </div>
            <div style="display:grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap:10px; margin-bottom:10px;">
                <div style="background:#eff6ff; border-radius:10px; padding:8px 10px; text-align:center;">
                    <div style="font-size:0.8rem; color:#64748b;">Mean</div>
                    <div style="font-weight:700; color:#1e3a5f;">{{ "%.2f"|format(card.avg_score) }}</div>
                </div>
                <div style="background:#f8fafc; border-radius:10px; padding:8px 10px; text-align:center;">
                    <div style="font-size:0.8rem; color:#64748b;">Max</div>
                    <div style="font-weight:700; color:#1e3a5f;">{{ "%.2f"|format(card.max_score) }}</div>
                </div>
                <div style="background:#f8fafc; border-radius:10px; padding:8px 10px; text-align:center;">
                    <div style="font-size:0.8rem; color:#64748b;">Min</div>
                    <div style="font-weight:700; color:#1e3a5f;">{{ "%.2f"|format(card.min_score) }}</div>
                </div>
            </div>
            <div style="padding:10px; border:1px solid #dbe4f0; border-radius:12px; background:#ffffff; overflow-x:auto;">
                <svg viewBox="0 0 {{ card.curve_chart.width }} {{ card.curve_chart.height }}" style="width: 100%; min-width: 300px; max-width: 430px; height: auto; display: block; margin: 0 auto;">
                    {% for tick in card.curve_chart.y_ticks %}
                    <line x1="{{ card.curve_chart.left_pad }}" y1="{{ tick.y }}" x2="{{ card.curve_chart.width - card.curve_chart.right_pad }}" y2="{{ tick.y }}" stroke="#e2e8f0" stroke-width="1" stroke-dasharray="3 4"></line>
                    {% endfor %}
                    <line x1="{{ card.curve_chart.left_pad }}" y1="{{ card.curve_chart.baseline_y }}" x2="{{ card.curve_chart.width - card.curve_chart.right_pad }}" y2="{{ card.curve_chart.baseline_y }}" stroke="#94a3b8" stroke-width="1.2"></line>
                    <polygon points="{{ card.curve_chart.area_polygon_points }}" fill="rgba(59, 130, 246, 0.14)"></polygon>
                    <polyline points="{{ card.curve_chart.polyline_points }}" fill="none" stroke="#2563eb" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"></polyline>
                    {% for point in card.curve_chart.points %}
                    <circle cx="{{ point.x }}" cy="{{ point.y }}" r="3.8" fill="#1d4ed8"></circle>
                    {% endfor %}
                    {% for label in card.curve_chart.labels %}
                    <text x="{{ label.x }}" y="{{ card.curve_chart.height - 14 }}" text-anchor="middle" font-size="8.5" fill="#64748b">{{ label.label }}</text>
                    {% endfor %}
                </svg>
            </div>
        </div>
        {% endfor %}
    </div>
    {% else %}
    <div class="alert-info" style="margin-bottom: 0;">
        Select up to three departments and click <strong>Show Comparison</strong>.
    </div>
    {% endif %}
</div>

{% if selected_band %}
<div class="alert-info" style="margin-bottom: 18px;">
    Showing employees in score band: <strong>{{ selected_band }}</strong>
</div>
{% endif %}

{% if ranked_subordinates %}
<div class="content-card" id="employee-ranking">
    <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; flex-wrap:wrap; margin-bottom: 14px;">
        <h2 class="gradient-text" style="margin:0;">Employee Ranking</h2>
        <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
            <div style="color:#64748b;">Click <strong>View</strong> to open the employee PE summary.</div>
            <a href="{{ url_for('performance_distribution', year=selected_year, division=division_param, department=department_param, company=company_param, band=selected_band, sort_dir='asc') }}{{ compare_query_suffix }}#employee-ranking" class="btn-secondary" style="padding: 6px 12px; font-size: 0.9em;">Ascending Sort</a>
            <a href="{{ url_for('performance_distribution', year=selected_year, division=division_param, department=department_param, company=company_param, band=selected_band, sort_dir='desc') }}{{ compare_query_suffix }}#employee-ranking" class="btn-secondary" style="padding: 6px 12px; font-size: 0.9em;">Descending Sort</a>
        </div>
    </div>
    <div style="overflow-x:auto;">
        <table class="modern-table">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Employee</th>
                    {% if is_super_director %}<th>Company</th>{% endif %}
                    <th>Division</th>
                    <th>Department</th>
                    <th>Position</th>
                    <th>Job Level</th>
                    <th>Status</th>
                    <th style="text-align:right;">Final Score</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                {% for sub in ranked_subordinates %}
                <tr>
                    <td>{{ row_start + loop.index }}</td>
                    <td>
                        <div style="font-weight:700;">{{ sub.full_name }}</div>
                        <div style="color:#64748b;"><code>{{ sub.employee_id }}</code></div>
                    </td>
                    {% if is_super_director %}<td>{{ sub.company or '-' }}</td>{% endif %}
                    <td>{{ sub.division or '-' }}</td>
                    <td>{{ sub.department or '-' }}</td>
                    <td>{{ sub.position or '-' }}</td>
                    <td>{{ sub.job_level or '-' }}</td>
                    <td>
                        <span style="display:inline-flex; align-items:center; padding:5px 10px; border-radius:999px; font-size:0.82em; font-weight:700; white-space:nowrap; background: {{ sub.workflow_status.bg }}; color: {{ sub.workflow_status.color }}; border: 1px solid {{ sub.workflow_status.border }};">
                            {{ sub.workflow_status.label }}
                        </span>
                    </td>
                    <td style="text-align:right; font-weight:700;">{{ "%.2f"|format(sub.final_total_score|float) if sub.final_total_score is not none else '-' }}</td>
                    <td><a href="{{ url_for('director_view_subordinate', employee_id=sub.employee_id, year=selected_year) }}" class="btn-primary" style="padding: 5px 10px; font-size: 0.85em;">View</a></td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
    </div>
    {% if total_pages > 1 %}
    <div class="button-group" style="margin-top: 20px;">
        {% if current_page > 1 %}
        <a href="{{ url_for('performance_distribution', year=selected_year, division=division_param, department=department_param, company=company_param, band=selected_band, sort_dir=sort_dir, page=current_page - 1) }}{{ compare_query_suffix }}#employee-ranking" class="btn-secondary">Previous</a>
        {% endif %}
        <div class="page-count" style="align-self: center; font-weight: 600;">Page {{ current_page }} of {{ total_pages }}</div>
        {% if current_page < total_pages %}
        <a href="{{ url_for('performance_distribution', year=selected_year, division=division_param, department=department_param, company=company_param, band=selected_band, sort_dir=sort_dir, page=current_page + 1) }}{{ compare_query_suffix }}#employee-ranking" class="btn-secondary">Next</a>
        {% endif %}
    </div>
    {% endif %}
</div>
{% else %}
<div class="alert-warning">
    <strong>No employees found.</strong> There are no completed PE scores for the selected scope.
</div>
{% endif %}

<div class="button-group" style="margin-top: 24px;">
    <a href="{{ url_for('performance_dashboard', year=selected_year, division=division_param, department=department_param, company=company_param) }}" class="btn-secondary">Back to Dashboard</a>
</div>
{% endblock %}
''')


STAFF_PROMOTION_FORM_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<style>
[data-theme="dark"] .staff-promotion-subtitle,
[data-theme="dark"] .staff-promotion-history-title {
    color: #e5e7eb !important;
}
</style>
<div class="header-section">
    <h1 class="gradient-text">Staff Promotion Form</h1>
    <p class="staff-promotion-subtitle">{{ form_subtitle }}</p>
</div>

<div class="alert-info" style="margin-bottom: 20px;">
    <strong>Instruction:</strong> {{ info_text }}
</div>

<div class="section-card" style="padding: 24px; margin-bottom: 24px; border: 1px solid #dbe4f0; border-radius: 24px; background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);">
    <div style="display:flex; gap:24px; align-items:flex-start; flex-wrap:wrap;">
        <div style="display:flex; align-items:center; gap:18px; min-width:340px; flex:1 1 360px;">
            <img src="{{ photo_src }}" alt="{{ profile_snapshot.full_name }}" style="width:112px; height:112px; border-radius:26px; object-fit:cover; border:4px solid #e0ecff; background:#f8fafc; box-shadow: 0 10px 24px rgba(30, 58, 138, 0.10);" onerror="this.onerror=null;this.src='{{ url_for('user_photo_placeholder', name=profile_snapshot.full_name) }}';">
            <div style="min-width:0;">
                <div style="font-size:1.55rem; font-weight:800; color:#1e3a5f; line-height:1.15; margin-top:4px;">{{ profile_snapshot.full_name }}</div>
                <div style="margin-top:6px; color:#475569; font-weight:700; font-size:1rem;">{{ profile_snapshot.position }}</div>
                <div style="margin-top:10px; display:flex; flex-wrap:wrap; gap:8px;">
                    <span style="display:inline-flex; align-items:center; padding:6px 11px; border-radius:999px; background:#e0ecff; color:#1d4ed8; font-size:0.84em; font-weight:700;">Employee ID: {{ profile_snapshot.employee_id }}</span>
                    <span style="display:inline-flex; align-items:center; padding:6px 11px; border-radius:999px; background:#ecfeff; color:#0f766e; font-size:0.84em; font-weight:700;">Job Level {{ profile_snapshot.job_level }}</span>
                </div>
            </div>
        </div>
        <div style="flex:0 0 190px; min-width:190px;">
            <div style="padding:16px 18px; border-radius:18px; background:linear-gradient(135deg, #ecfdf5 0%, #dcfce7 100%); border:1px solid #bbf7d0; text-align:center;">
                <div style="font-size:0.78rem; font-weight:700; letter-spacing:0.08em; text-transform:uppercase; color:#166534;">Current PE Score</div>
                <div style="margin-top:8px; font-size:2rem; line-height:1; font-weight:800; color:#166534;">{{ profile_snapshot.pe_score }}</div>
            </div>
        </div>
    </div>
    <div style="display:grid; grid-template-columns:repeat(3, minmax(0, 1fr)); gap:14px; margin-top:18px;">
        <div style="padding:14px 16px; border-radius:16px; background:#f8fbff; border:1px solid #dbe4f0;"><div style="font-size:0.78rem; color:#64748b; text-transform:uppercase; letter-spacing:0.08em; font-weight:700;">Nickname</div><div style="margin-top:6px; font-weight:700; color:#0f172a;">{{ profile_snapshot.nickname }}</div></div>
        <div style="padding:14px 16px; border-radius:16px; background:#f8fbff; border:1px solid #dbe4f0;"><div style="font-size:0.78rem; color:#64748b; text-transform:uppercase; letter-spacing:0.08em; font-weight:700;">Division</div><div style="margin-top:6px; font-weight:700; color:#0f172a;">{{ profile_snapshot.division }}</div></div>
        <div style="padding:14px 16px; border-radius:16px; background:#f8fbff; border:1px solid #dbe4f0;"><div style="font-size:0.78rem; color:#64748b; text-transform:uppercase; letter-spacing:0.08em; font-weight:700;">Department</div><div style="margin-top:6px; font-weight:700; color:#0f172a;">{{ profile_snapshot.department }}</div></div>
        <div style="padding:14px 16px; border-radius:16px; background:#f8fbff; border:1px solid #dbe4f0;"><div style="font-size:0.78rem; color:#64748b; text-transform:uppercase; letter-spacing:0.08em; font-weight:700;">Tenure</div><div style="margin-top:6px; font-weight:700; color:#0f172a;">{{ profile_snapshot.tenure }}</div></div>
        <div style="padding:14px 16px; border-radius:16px; background:#f8fbff; border:1px solid #dbe4f0;"><div style="font-size:0.78rem; color:#64748b; text-transform:uppercase; letter-spacing:0.08em; font-weight:700;">Age</div><div style="margin-top:6px; font-weight:700; color:#0f172a;">{{ profile_snapshot.age }}</div></div>
        <div style="padding:14px 16px; border-radius:16px; background:#f8fbff; border:1px solid #dbe4f0;"><div style="font-size:0.78rem; color:#64748b; text-transform:uppercase; letter-spacing:0.08em; font-weight:700;">Position</div><div style="margin-top:6px; font-weight:700; color:#0f172a;">{{ profile_snapshot.position }}</div></div>
    </div>
</div>

<div class="section-card" style="padding: 20px; margin-bottom: 18px; max-width: 560px;">
    <div class="staff-promotion-history-title" style="font-size:1.05rem; font-weight:800; color:#1e3a5f; margin-bottom:6px;">PE Score History (Last 3 Years)</div>
    <div style="height: 8px;"></div>
    <div style="display:grid; gap:12px;">
        {% for idx in range(1, 4) %}
        <div style="display:grid; grid-template-columns: minmax(170px, 200px) minmax(120px, 150px); gap:12px; align-items:end;">
            <div>
                <label class="modern-label" for="manual_score_year_{{ idx }}">Fiscal Year {{ idx }}{% if idx == 1 %} (Latest){% endif %}</label>
                <select id="manual_score_year_{{ idx }}" name="manual_score_year_{{ idx }}" class="modern-select" style="width:100%;">
                    <option value="">Select Year</option>
                    {% for year in manual_score_years %}
                    <option value="{{ year }}" {% if form_values['manual_score_year_' ~ idx] == year|string %}selected{% endif %}>{{ year }}</option>
                    {% endfor %}
                </select>
            </div>
            <div>
                <label class="modern-label" for="manual_score_value_{{ idx }}">PE Score {{ idx }}</label>
                <input id="manual_score_value_{{ idx }}" name="manual_score_value_{{ idx }}" class="modern-input" type="number" min="1" max="5" step="0.01" value="{{ form_values['manual_score_value_' ~ idx] }}" placeholder="1.00" style="width:100%;" oninput="if(this.value){let v=parseFloat(this.value); if(!isNaN(v)){ if(v>5)this.value='5'; else if(v<1)this.value='1'; }}" onblur="if(this.value){let v=parseFloat(this.value); if(!isNaN(v)){ if(v>5)v=5; else if(v<1)v=1; this.value=v.toFixed(2); }}">
            </div>
        </div>
        {% endfor %}
    </div>
</div>

<form method="post" action="{{ form_action_url }}">
    {% if form_id %}
    <input type="hidden" name="form_id" value="{{ form_id }}">
    {% endif %}
    <div class="section-card" style="padding: 20px;">
        <div style="display:grid; grid-template-columns:1fr; column-gap:16px; row-gap:24px;">
            <div style="display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:16px; align-items:start;">
                <div>
                    <label class="modern-label" for="current_job_description">Current Job Description</label>
                    <textarea id="current_job_description" name="current_job_description" class="modern-textarea" rows="4" maxlength="3000" required style="width:100%; overflow-y:hidden; resize:none;">{{ form_values.current_job_description }}</textarea>
                </div>
                <div>
                    <label class="modern-label" for="new_job_description">New Job Description</label>
                    <textarea id="new_job_description" name="new_job_description" class="modern-textarea" rows="4" maxlength="3000" required style="width:100%; overflow-y:hidden; resize:none;">{{ form_values.new_job_description }}</textarea>
                </div>
            </div>
            <div style="display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:16px; align-items:end;">
                <div>
                    <label class="modern-label" for="new_job_title">New Job Title</label>
                    <input id="new_job_title" name="new_job_title" class="modern-input" value="{{ form_values.new_job_title }}" maxlength="50" required style="width:100%;">
                </div>
                <div>
                    <label class="modern-label" for="proposed_job_level">Proposed Job Level</label>
                    <select id="proposed_job_level" name="proposed_job_level" class="modern-select" style="max-width:120px;" required>
                        <option value="">Select</option>
                        {% for level in range(5, 14) %}
                        <option value="{{ level }}" {% if form_values.proposed_job_level|string == level|string %}selected{% endif %}>{{ level }}</option>
                        {% endfor %}
                    </select>
                </div>
            </div>
            <div style="display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:16px; align-items:start;">
                <div>
                    <label class="modern-label" for="new_job_assignment">New Job Assignment</label>
                    <textarea id="new_job_assignment" name="new_job_assignment" class="modern-textarea" rows="4" maxlength="1000" required style="width:100%; overflow-y:hidden; resize:none;">{{ form_values.new_job_assignment }}</textarea>
                </div>
                <div>
                    <label class="modern-label" for="reasons_for_adjustment">Reasons for Adjustment</label>
                    <textarea id="reasons_for_adjustment" name="reasons_for_adjustment" class="modern-textarea" rows="4" required style="width:100%; overflow-y:hidden; resize:none;">{{ form_values.reasons_for_adjustment }}</textarea>
                </div>
            </div>
        </div>
    </div>

    <div class="button-group" style="margin-top: 20px;">
        <a href="{{ back_url }}" class="btn-secondary">Back</a>
        <button type="submit" name="form_action" value="save" class="btn-secondary">{{ save_button_label }}</button>
        <button type="submit" class="btn-primary">{{ submit_button_label }}</button>
    </div>
</form>
<script>
(function() {
    function autoResize(el) {
        if (!el) return;
        el.style.height = 'auto';
        el.style.height = (el.scrollHeight + 2) + 'px';
    }
    function extractBulletsFromHtml(html) {
        if (!html || html.indexOf('<li') === -1) return null;
        const container = document.createElement('div');
        container.innerHTML = html;
        const items = Array.from(container.querySelectorAll('li'));
        if (!items.length) return null;
        return items.map((item) => {
            const text = (item.textContent || '').replace(/\s+/g, ' ').trim();
            return text ? '• ' + text : '';
        }).filter(Boolean).join('\n');
    }
    function insertTextAtCursor(el, text) {
        const start = el.selectionStart || 0;
        const end = el.selectionEnd || 0;
        const current = el.value || '';
        el.value = current.slice(0, start) + text + current.slice(end);
        const nextPos = start + text.length;
        el.setSelectionRange(nextPos, nextPos);
        autoResize(el);
        el.dispatchEvent(new Event('input', { bubbles: true }));
    }
    function bindAutoResize(id) {
        const el = document.getElementById(id);
        if (!el) return;
        el.style.overflowY = 'hidden';
        el.style.resize = 'none';
        autoResize(el);
        el.addEventListener('input', function() { autoResize(el); });
        el.addEventListener('change', function() { autoResize(el); });
        el.addEventListener('paste', function(e) {
            const html = e.clipboardData ? e.clipboardData.getData('text/html') : '';
            const bulletText = extractBulletsFromHtml(html);
            if (!bulletText) return;
            e.preventDefault();
            insertTextAtCursor(el, bulletText);
        });
    }
    function initPromotionTextareas() {
        ['current_job_description', 'new_job_description', 'new_job_assignment', 'reasons_for_adjustment'].forEach(bindAutoResize);
    }
    function bindManualScoreValidation() {
        document.querySelectorAll('input[id^="manual_score_value_"]').forEach((el) => {
            if (el.dataset.scoreBound === '1') return;
            const clampScore = (finalize = false) => {
                if (!el.value) return;
                const numeric = parseFloat(el.value);
                if (Number.isNaN(numeric)) {
                    el.value = '';
                    return;
                }
                if (numeric > 5) {
                    el.value = finalize ? '5.00' : '5';
                    return;
                }
                if (numeric < 1) {
                    el.value = finalize ? '1.00' : '1';
                    return;
                }
                if (finalize) {
                    el.value = numeric.toFixed(2);
                }
            };
            el.addEventListener('input', function() { clampScore(false); });
            el.addEventListener('change', function() { clampScore(true); });
            el.addEventListener('blur', function() { clampScore(true); });
            el.dataset.scoreBound = '1';
        });
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            initPromotionTextareas();
            bindManualScoreValidation();
        });
    } else {
        initPromotionTextareas();
        bindManualScoreValidation();
    }
    window.addEventListener('load', function() {
        initPromotionTextareas();
        bindManualScoreValidation();
    });
    window.addEventListener('pageshow', function() {
        initPromotionTextareas();
        bindManualScoreValidation();
    });
    setTimeout(function() {
        initPromotionTextareas();
        bindManualScoreValidation();
    }, 0);
    setTimeout(function() {
        initPromotionTextareas();
        bindManualScoreValidation();
    }, 100);
})();
</script>
{% endblock %}
''')


STAFF_PROMOTION_INBOX_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<style>
[data-theme="dark"] .promotion-nominations-subtitle,
[data-theme="dark"] .promotion-nomination-name {
    color: #e5e7eb !important;
}
</style>
<div class="header-section">
    <h1 class="gradient-text">Promotion Nominations</h1>
    <p class="promotion-nominations-subtitle">Staff proposed for promotion by Business Unit heads.</p>
</div>

{% if available_years %}
<form method="get" action="{{ url_for('staff_promotion_inbox') }}" style="margin-bottom: 18px;">
    <label class="modern-label" for="promotion_eval_year">Select Fiscal Year:</label>
    <select id="promotion_eval_year" name="year" class="modern-select" style="width: 220px; display: inline-block;" onchange="this.form.submit()">
        {% for y in available_years %}
        <option value="{{ y }}" {% if y == selected_year %}selected{% endif %}>{{ y }}</option>
        {% endfor %}
    </select>
    <br>
    <label class="modern-label" for="promotion_sort_by" style="margin-top: 10px; display: inline-block;">Sort By:</label><br>
    <select id="promotion_sort_by" name="sort_by" class="modern-select" style="width: 260px; display: inline-block; margin-top: 6px;" onchange="this.form.submit()">
        <option value="newest" {% if sort_by == 'newest' %}selected{% endif %}>Newest Submitted</option>
        <option value="division" {% if sort_by == 'division' %}selected{% endif %}>Division / Department / Name</option>
        <option value="job_level_asc" {% if sort_by == 'job_level_asc' %}selected{% endif %}>Job Level Low to High</option>
        <option value="job_level_desc" {% if sort_by == 'job_level_desc' %}selected{% endif %}>Job Level High to Low</option>
    </select>
</form>
{% endif %}

<div class="button-group" style="margin-bottom: 18px; justify-content:flex-end;">
    <a href="{{ url_for('print_staff_promotion_forms', year=selected_year) }}" class="btn-secondary" target="_blank">Print Submitted Forms</a>
</div>

{% if forms %}
<div class="section-card" style="padding: 0;">
    <div style="overflow-x:auto;">
        <table class="modern-table">
            <thead>
                <tr>
                    <th>Staff</th>
                    <th>Division</th>
                    <th>Department</th>
                    <th>Current Position</th>
                    <th style="text-align:center;">Current Job Level</th>
                    <th>Status</th>
                    <th>Submitted At</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                {% for form in forms %}
                <tr {% if not form.is_viewed %}style="background: #f8fbff;"{% endif %}>
                    <td>
                        <div style="display:flex; align-items:center; gap:16px; min-height:78px;">
                            <img src="{{ url_for('user_photo_for_employee', employee_id=form.profile_snapshot.employee_id) }}" alt="{{ form.profile_snapshot.full_name }}" style="width:72px; height:72px; border-radius:18px; object-fit:cover; border:2px solid #dbeafe; background:#f8fafc;" onerror="this.onerror=null;this.src='{{ url_for('user_photo_placeholder', name=form.profile_snapshot.full_name) }}';">
                            <div>
                                <div class="promotion-nomination-name" style="font-weight:700; color:#1e3a5f;">{{ form.profile_snapshot.full_name }}</div>
                                <div style="font-size:0.9em; color:#64748b;">{{ form.profile_snapshot.employee_id }}</div>
                                {% if not form.is_viewed %}
                                <div style="font-size:0.78em; color:#1d4ed8; font-weight:700; margin-top:4px;">New</div>
                                {% endif %}
                            </div>
                        </div>
                    </td>
                    <td>{{ form.profile_snapshot.division }}</td>
                    <td>{{ form.profile_snapshot.department }}</td>
                    <td>{{ form.profile_snapshot.position }}</td>
                    <td style="text-align:center;">{{ form.profile_snapshot.job_level }}</td>
                    <td>{{ form.status_label }}</td>
                    <td>{{ form.created_at_display }}</td>
                    <td><a href="{{ form.action_url }}" class="btn-primary" style="padding:6px 12px; font-size:0.85em;">{{ form.action_label }}</a></td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
    </div>
</div>
{% else %}
<div class="alert-warning">
    <strong>No promotion forms found.</strong> There are no staff promotion forms available for the selected year.
</div>
{% endif %}
{% endblock %}
''')


STAFF_PROMOTION_DETAIL_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<style>
[data-theme="dark"] .staff-promotion-detail-subtitle,
[data-theme="dark"] .staff-promotion-detail-history-title {
    color: #e5e7eb !important;
}
</style>
<div class="header-section">
    <h1 class="gradient-text">Promotion Nomination Details</h1>
    <p class="staff-promotion-detail-subtitle">Submitted promotion proposal details for HR &amp; Admin Director review.</p>
</div>

<div class="button-group" style="margin-bottom: 18px; justify-content:flex-end;">
    <a href="{{ url_for('print_single_staff_promotion_form', form_id=form.id, year=selected_year) }}" class="btn-secondary" target="_blank">Print Form</a>
</div>

{% if show_final_actions %}
<div class="section-card" style="padding:16px 20px; margin-bottom:18px; background:#fffaf0; border:1px solid #fcd34d;">
    <div style="display:flex; justify-content:space-between; gap:16px; align-items:center; flex-wrap:wrap;">
        <div>
            <div style="font-size:0.82rem; font-weight:700; letter-spacing:0.08em; text-transform:uppercase; color:#92400e;">Final HR Decision</div>
            <div style="margin-top:6px; color:#78350f;">Use these actions after receiving the top management decision for this nomination.</div>
        </div>
        <form method="post" action="{{ url_for('finalize_staff_promotion_form_route', form_id=form.id, year=selected_year) }}" style="display:flex; gap:10px; flex-wrap:wrap;">
            <button type="submit" name="final_action" value="approve" class="btn-success" onclick="return confirm('Approve this staff promotion nomination?');">Approve</button>
            <button type="submit" name="final_action" value="reject" class="btn-secondary" style="background:#b91c1c; color:#ffffff; border-color:#991b1b;" onclick="return confirm('Reject this staff promotion nomination?');">Reject</button>
        </form>
    </div>
</div>
{% endif %}

{% if form.status_badge %}
<div style="margin-bottom:18px;">
    <span style="display:inline-flex; align-items:center; padding:8px 14px; border-radius:999px; font-size:0.88em; font-weight:800; background: {{ form.status_badge.bg }}; color: {{ form.status_badge.color }}; border:1px solid {{ form.status_badge.border }};">
        {{ form.status_badge.label }}
    </span>
</div>
{% endif %}

<div class="section-card" style="padding: 24px; margin-bottom: 24px; border: 1px solid #dbe4f0; border-radius: 24px; background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);">
    <div style="display:flex; gap:24px; align-items:flex-start; flex-wrap:wrap;">
        <div style="display:flex; align-items:center; gap:18px; min-width:340px; flex:1 1 360px;">
            <img src="{{ photo_src }}" alt="{{ form.profile_snapshot.full_name }}" style="width:112px; height:112px; border-radius:26px; object-fit:cover; border:4px solid #e0ecff; background:#f8fafc; box-shadow: 0 10px 24px rgba(30, 58, 138, 0.10);" onerror="this.onerror=null;this.src='{{ url_for('user_photo_placeholder', name=form.profile_snapshot.full_name) }}';">
            <div style="min-width:0;">
                <div style="font-size:1.55rem; font-weight:800; color:#1e3a5f; line-height:1.15; margin-top:4px;">{{ form.profile_snapshot.full_name }}</div>
                <div style="margin-top:6px; color:#475569; font-weight:700; font-size:1rem;">{{ form.profile_snapshot.position }}</div>
                <div style="margin-top:10px; display:flex; flex-wrap:wrap; gap:8px;">
                    <span style="display:inline-flex; align-items:center; padding:6px 11px; border-radius:999px; background:#e0ecff; color:#1d4ed8; font-size:0.84em; font-weight:700;">Employee ID: {{ form.profile_snapshot.employee_id }}</span>
                    <span style="display:inline-flex; align-items:center; padding:6px 11px; border-radius:999px; background:#ecfeff; color:#0f766e; font-size:0.84em; font-weight:700;">Job Level {{ form.profile_snapshot.job_level }}</span>
                </div>
            </div>
        </div>
        <div style="flex:0 0 190px; min-width:190px;">
            <div style="padding:16px 18px; border-radius:18px; background:linear-gradient(135deg, #ecfdf5 0%, #dcfce7 100%); border:1px solid #bbf7d0; text-align:center;">
                <div style="font-size:0.78rem; font-weight:700; letter-spacing:0.08em; text-transform:uppercase; color:#166534;">Current PE Score</div>
                <div style="margin-top:8px; font-size:2rem; line-height:1; font-weight:800; color:#166534;">{{ form.profile_snapshot.pe_score }}</div>
            </div>
        </div>
    </div>
    <div style="display:grid; grid-template-columns:repeat(3, minmax(0, 1fr)); gap:14px; margin-top:18px;">
        <div style="padding:14px 16px; border-radius:16px; background:#f8fbff; border:1px solid #dbe4f0;"><div style="font-size:0.78rem; color:#64748b; text-transform:uppercase; letter-spacing:0.08em; font-weight:700;">Nickname</div><div style="margin-top:6px; font-weight:700; color:#0f172a;">{{ form.profile_snapshot.nickname }}</div></div>
        <div style="padding:14px 16px; border-radius:16px; background:#f8fbff; border:1px solid #dbe4f0;"><div style="font-size:0.78rem; color:#64748b; text-transform:uppercase; letter-spacing:0.08em; font-weight:700;">Division</div><div style="margin-top:6px; font-weight:700; color:#0f172a;">{{ form.profile_snapshot.division }}</div></div>
        <div style="padding:14px 16px; border-radius:16px; background:#f8fbff; border:1px solid #dbe4f0;"><div style="font-size:0.78rem; color:#64748b; text-transform:uppercase; letter-spacing:0.08em; font-weight:700;">Department</div><div style="margin-top:6px; font-weight:700; color:#0f172a;">{{ form.profile_snapshot.department }}</div></div>
        <div style="padding:14px 16px; border-radius:16px; background:#f8fbff; border:1px solid #dbe4f0;"><div style="font-size:0.78rem; color:#64748b; text-transform:uppercase; letter-spacing:0.08em; font-weight:700;">Tenure</div><div style="margin-top:6px; font-weight:700; color:#0f172a;">{{ form.profile_snapshot.tenure }}</div></div>
        <div style="padding:14px 16px; border-radius:16px; background:#f8fbff; border:1px solid #dbe4f0;"><div style="font-size:0.78rem; color:#64748b; text-transform:uppercase; letter-spacing:0.08em; font-weight:700;">Age</div><div style="margin-top:6px; font-weight:700; color:#0f172a;">{{ form.profile_snapshot.age }}</div></div>
        <div style="padding:14px 16px; border-radius:16px; background:#f8fbff; border:1px solid #dbe4f0;"><div style="font-size:0.78rem; color:#64748b; text-transform:uppercase; letter-spacing:0.08em; font-weight:700;">Position</div><div style="margin-top:6px; font-weight:700; color:#0f172a;">{{ form.profile_snapshot.position }}</div></div>
    </div>
</div>

<div class="section-card" style="padding: 20px; margin-bottom: 18px; max-width: 420px;">
    <div class="staff-promotion-detail-history-title" style="font-size:1.05rem; font-weight:800; color:#1e3a5f; margin-bottom:6px;">PE Score History (Last 3 Years)</div>
    <div style="height: 8px;"></div>
    <div style="overflow-x:auto;">
        <table class="modern-table">
            <thead>
                <tr>
                    <th>Fiscal Year</th>
                    <th style="text-align:right;">PE Score</th>
                </tr>
            </thead>
            <tbody>
                {% if form.manual_score_entries %}
                {% for row in form.manual_score_entries %}
                <tr>
                    <td>{{ row.eval_year }}</td>
                    <td style="text-align:right;">{{ row.final_total_score }}</td>
                </tr>
                {% endfor %}
                {% else %}
                <tr>
                    <td colspan="2" style="color:#64748b;">No PE score history entered yet.</td>
                </tr>
                {% endif %}
            </tbody>
        </table>
    </div>
</div>

<div class="section-card" style="padding: 20px;">
    <div style="display:grid; grid-template-columns:1fr; column-gap:16px; row-gap:24px;">
        <div style="display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:16px; align-items:start;">
            <div style="padding:16px; border:1px solid #dbe4f0; border-radius:16px; background:#f8fbff;"><strong>Current Job Description</strong><br><div style="white-space:pre-wrap; margin-top:8px;">{{ form.current_job_description }}</div></div>
            <div style="padding:16px; border:1px solid #dbe4f0; border-radius:16px; background:#f8fbff;"><strong>New Job Description</strong><br><div style="white-space:pre-wrap; margin-top:8px;">{{ form.new_job_description }}</div></div>
        </div>
        <div style="display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:16px; align-items:end;">
            <div style="padding:16px; border:1px solid #dbe4f0; border-radius:16px; background:#f8fbff;"><strong>New Job Title</strong><br><div style="margin-top:8px;">{{ form.new_job_title }}</div></div>
            <div style="padding:16px; border:1px solid #dbe4f0; border-radius:16px; background:#f8fbff;"><strong>Proposed Job Level</strong><br><div style="margin-top:8px;">{{ form.proposed_job_level }}</div></div>
        </div>
        <div style="display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:16px; align-items:start;">
            <div style="padding:16px; border:1px solid #dbe4f0; border-radius:16px; background:#f8fbff;"><strong>New Job Assignment</strong><br><div style="white-space:pre-wrap; margin-top:8px;">{{ form.new_job_assignment }}</div></div>
            <div style="padding:16px; border:1px solid #dbe4f0; border-radius:16px; background:#f8fbff;"><strong>Reasons for Adjustment</strong><br><div style="white-space:pre-wrap; margin-top:8px;">{{ form.reasons_for_adjustment }}</div></div>
        </div>
    </div>
</div>

<div class="button-group" style="margin-top: 20px;">
    <a href="{{ url_for('staff_promotion_inbox', year=selected_year) }}" class="btn-secondary">Back</a>
</div>
{% endblock %}
''')


STAFF_PROMOTION_PRINT_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Promotion Forms</title>
    <style>
        body { font-family: Arial, sans-serif; color: #0f172a; margin: 24px; }
        .header { border-bottom: 2px solid #cbd5e1; padding-bottom: 12px; margin-bottom: 20px; }
        .header .brand { font-size: 24px; font-weight: 800; }
        .form-card { page-break-inside: avoid; border: 1px solid #cbd5e1; border-radius: 24px; padding: 18px; margin-bottom: 22px; }
        .section-title { font-size: 18px; font-weight: 800; color: #1e3a5f; margin-bottom: 12px; }
        .grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 10px 18px; margin-bottom: 14px; }
        .field-label { font-weight: 700; color: #334155; }
        .profile-header { display: flex; gap: 16px; align-items: flex-start; margin-bottom: 14px; }
        .profile-photo { width: 110px; height: 110px; border-radius: 22px; object-fit: cover; border: 2px solid #dbeafe; background: #f8fafc; }
        .profile-meta { flex: 1; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; margin-bottom: 14px; }
        th, td { border: 1px solid #dbe4f0; padding: 8px 10px; font-size: 13px; }
        th { background: #f8fafc; text-align: left; }
        .text-block { white-space: pre-wrap; line-height: 1.5; }
        .score-history { max-width: 320px; margin-bottom: 12px; }
        .proposal-grid { display: grid; grid-template-columns: 1fr; row-gap: 18px; }
        .proposal-row { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; align-items: start; }
        @media print {
            body { margin: 12mm; }
            .form-card { break-inside: avoid; }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="brand">TCC Technology Group</div>
        <div style="font-size: 20px; font-weight: 700; color: #1e3a5f;">Staff Promotion Forms</div>
        <div style="color:#475569; margin-top:4px;">Printed: {{ printed_at }}</div>
    </div>

    {% for form in forms %}
    <div class="form-card">
        <div class="profile-header">
            <img src="{{ form.photo_src }}" alt="{{ form.profile_snapshot.full_name }}" class="profile-photo">
            <div class="profile-meta">
                <div class="section-title" style="margin-bottom: 6px;">{{ form.profile_snapshot.full_name }} ({{ form.profile_snapshot.employee_id }})</div>
                <div style="color:#475569; font-weight:600;">{{ form.profile_snapshot.position }}</div>
            </div>
        </div>
        <div class="grid">
            <div><span class="field-label">Nickname:</span><br>{{ form.profile_snapshot.nickname }}</div>
            <div><span class="field-label">Division:</span><br>{{ form.profile_snapshot.division }}</div>
            <div><span class="field-label">Department:</span><br>{{ form.profile_snapshot.department }}</div>
            <div><span class="field-label">Tenure:</span><br>{{ form.profile_snapshot.tenure }}</div>
            <div><span class="field-label">Age:</span><br>{{ form.profile_snapshot.age }}</div>
            <div><span class="field-label">PE Score:</span><br>{{ form.profile_snapshot.pe_score }}</div>
            <div><span class="field-label">Position:</span><br>{{ form.profile_snapshot.position }}</div>
            <div><span class="field-label">Job Level:</span><br>{{ form.profile_snapshot.job_level }}</div>
            <div><span class="field-label">Submitted At:</span><br>{{ form.created_at_display }}</div>
        </div>

        <div class="section-title" style="font-size:16px;">PE Score History (Last 3 Years)</div>
        <div style="height: 8px;"></div>
        <table class="score-history">
            <thead><tr><th>Fiscal Year</th><th>PE Score</th></tr></thead>
            <tbody>
                {% if form.manual_score_entries %}
                {% for row in form.manual_score_entries %}
                <tr><td>{{ row.eval_year }}</td><td>{{ row.final_total_score }}</td></tr>
                {% endfor %}
                {% else %}
                <tr><td colspan="2" style="color:#64748b;">No PE score history entered yet.</td></tr>
                {% endif %}
            </tbody>
        </table>

        <div class="section-title" style="font-size:16px;">Promotion Proposal Details</div>
        <div class="proposal-grid">
            <div class="proposal-row">
                <div><span class="field-label">Current Job Description</span><div class="text-block">{{ form.current_job_description }}</div></div>
                <div><span class="field-label">New Job Description</span><div class="text-block">{{ form.new_job_description }}</div></div>
            </div>
            <div class="proposal-row">
                <div><span class="field-label">New Job Title</span><div>{{ form.new_job_title }}</div></div>
                <div><span class="field-label">Proposed Job Level</span><div>{{ form.proposed_job_level }}</div></div>
            </div>
            <div class="proposal-row">
                <div><span class="field-label">New Job Assignment</span><div class="text-block">{{ form.new_job_assignment }}</div></div>
                <div><span class="field-label">Reasons for Adjustment</span><div class="text-block">{{ form.reasons_for_adjustment }}</div></div>
            </div>
        </div>
    </div>
    {% endfor %}
</body>
</html>
'''


PERFORMANCE_DISTRIBUTION_PRINT_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Performance Score Analysis Brief</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #0f172a;
            margin: 24px;
            background: #ffffff;
        }
        .print-header {
            margin-bottom: 20px;
            padding-bottom: 14px;
            border-bottom: 2px solid #cbd5e1;
        }
        .print-header .brand {
            font-size: 26px;
            font-weight: 800;
            margin-bottom: 4px;
        }
        .print-header .title {
            font-size: 20px;
            font-weight: 700;
            color: #1e3a5f;
            margin-bottom: 10px;
        }
        .print-meta {
            display: grid;
            grid-template-columns: repeat(2, minmax(220px, 1fr));
            gap: 8px 18px;
            font-size: 12px;
            color: #334155;
        }
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(5, minmax(120px, 1fr));
            gap: 12px;
            margin: 18px 0 22px 0;
        }
        .summary-card {
            border: 1px solid #dbe4f0;
            border-radius: 12px;
            padding: 12px;
            text-align: center;
            background: #f8fbff;
        }
        .summary-card .value {
            font-size: 26px;
            font-weight: 800;
            color: #1e3a8a;
        }
        .summary-card .label {
            font-size: 12px;
            color: #64748b;
            margin-top: 4px;
            text-transform: uppercase;
            letter-spacing: 0.04em;
        }
        .section-title {
            font-size: 18px;
            font-weight: 700;
            color: #1e3a5f;
            margin: 18px 0 10px 0;
        }
        .chart-wrap,
        .bands-wrap,
        .table-wrap {
            break-inside: avoid;
            page-break-inside: avoid;
            margin-bottom: 18px;
        }
        .chart-box {
            border: 1px solid #dbe4f0;
            border-radius: 12px;
            padding: 14px;
            background: #f8fbff;
        }
        .bands-table,
        .ranking-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 12px;
        }
        .bands-table th,
        .bands-table td,
        .ranking-table th,
        .ranking-table td {
            border: 1px solid #dbe4f0;
            padding: 8px 10px;
            vertical-align: top;
        }
        .bands-table th,
        .ranking-table th {
            background: #eff6ff;
            text-align: left;
            color: #1e3a5f;
        }
    </style>
</head>
<body onload="window.print()">
    <div class="print-header">
        <div class="brand">TCC Technology Group</div>
        <div class="title">Performance Score Analysis Brief</div>
        <div class="print-meta">
            <div><strong>Fiscal Year:</strong> {{ selected_year }}</div>
            <div><strong>Prepared:</strong> {{ printed_at_text }}</div>
            {% if is_super_director %}
            <div><strong>Company:</strong> {{ selected_company if selected_company and selected_company != 'ALL' else 'All Companies' }}</div>
            {% endif %}
            <div><strong>Division:</strong> {{ division_scope_text }}</div>
            {% if department_scope_text %}
            <div><strong>Department:</strong> {{ department_scope_text }}</div>
            {% endif %}
            {% if selected_band %}
            <div><strong>Selected Band:</strong> {{ selected_band }}</div>
            {% endif %}
        </div>
    </div>

    <div class="summary-grid">
        <div class="summary-card"><div class="value">{{ total_staff }}</div><div class="label">Headcount</div></div>
        <div class="summary-card"><div class="value">{{ "%.2f"|format(avg_score) }}</div><div class="label">Mean</div></div>
        <div class="summary-card"><div class="value">{{ "%.2f"|format(median_score) }}</div><div class="label">Median</div></div>
        <div class="summary-card"><div class="value">{{ "%.2f"|format(max_score) }}</div><div class="label">Max</div></div>
        <div class="summary-card"><div class="value">{{ "%.2f"|format(min_score) }}</div><div class="label">Min</div></div>
    </div>

    <div class="chart-wrap">
        <div class="section-title">Bell Curve View</div>
        <div class="chart-box">
            <svg viewBox="0 0 {{ curve_chart.width }} {{ curve_chart.height }}" style="width: 100%; height: auto; display: block;">
                {% for tick in curve_chart.y_ticks %}
                <line x1="{{ curve_chart.left_pad }}" y1="{{ tick.y }}" x2="{{ curve_chart.width - curve_chart.right_pad }}" y2="{{ tick.y }}" stroke="#dbe4f0" stroke-width="1" stroke-dasharray="4 4"></line>
                <text x="{{ curve_chart.left_pad - 10 }}" y="{{ tick.y + 4 }}" text-anchor="end" font-size="11" fill="#64748b">{{ tick.value }}</text>
                {% endfor %}
                <line x1="{{ curve_chart.left_pad }}" y1="{{ curve_chart.baseline_y }}" x2="{{ curve_chart.width - curve_chart.right_pad }}" y2="{{ curve_chart.baseline_y }}" stroke="#94a3b8" stroke-width="1.4"></line>
                <polygon points="{{ curve_chart.area_polygon_points }}" fill="rgba(59, 130, 246, 0.16)"></polygon>
                <polyline points="{{ curve_chart.polyline_points }}" fill="none" stroke="#2563eb" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"></polyline>
                {% for point in curve_chart.points %}
                <circle cx="{{ point.x }}" cy="{{ point.y }}" r="5" fill="#1d4ed8"></circle>
                <text x="{{ point.x }}" y="{{ point.y - 10 }}" text-anchor="middle" font-size="11" font-weight="700" fill="#1e3a5f">{{ point.count }}</text>
                {% endfor %}
                {% for label in curve_chart.labels %}
                <text x="{{ label.x }}" y="{{ curve_chart.height - 12 }}" text-anchor="middle" font-size="10" fill="#64748b">{{ label.label }}</text>
                {% endfor %}
            </svg>
        </div>
    </div>

    <div class="bands-wrap">
        <div class="section-title">Score Bands</div>
        <table class="bands-table">
            <thead>
                <tr>
                    <th>Band</th>
                    <th style="text-align:right;">Count</th>
                    <th style="text-align:right;">Share (%)</th>
                </tr>
            </thead>
            <tbody>
                {% for band in distribution_rows %}
                <tr>
                    <td>{{ band.label }}</td>
                    <td style="text-align:right;">{{ band.count }}</td>
                    <td style="text-align:right;">{{ "%.1f"|format((band.count / total_staff * 100) if total_staff else 0) }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
    </div>

    <div class="table-wrap">
        <div class="section-title">Employee Ranking</div>
        <table class="ranking-table">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Employee</th>
                    {% if is_super_director %}<th>Company</th>{% endif %}
                    <th>Division</th>
                    <th>Department</th>
                    <th>Position</th>
                    <th>Job Level</th>
                    <th>Status</th>
                    <th style="text-align:right;">Final Score</th>
                </tr>
            </thead>
            <tbody>
                {% for sub in ranked_subordinates %}
                <tr>
                    <td>{{ loop.index }}</td>
                    <td>{{ sub.full_name }}<br><span style="color:#64748b;">{{ sub.employee_id }}</span></td>
                    {% if is_super_director %}<td>{{ sub.company or '-' }}</td>{% endif %}
                    <td>{{ sub.division or '-' }}</td>
                    <td>{{ sub.department or '-' }}</td>
                    <td>{{ sub.position or '-' }}</td>
                    <td>{{ sub.job_level or '-' }}</td>
                    <td>{{ sub.workflow_status.label }}</td>
                    <td style="text-align:right;">{{ "%.2f"|format(sub.final_total_score|float) if sub.final_total_score is not none else '-' }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
    </div>
</body>
</html>
'''


def get_director_subordinates(division_filter, eval_year=None, director_id=None, force_filter=False, employee_ids=None):
    """Fetch subordinates' PE scores for a director based on their division filter."""
    conn = get_db_connection()
    if not conn:
        print("DEBUG: No database connection for director subordinates")
        return []

    cursor = None
    try:
        cursor = conn.cursor(dictionary=True)

        def coerce_score(value):
            if value is None:
                return None
            if isinstance(value, (int, float)):
                return float(value)
            if isinstance(value, str):
                cleaned = value.strip()
                if cleaned == "":
                    return None
                try:
                    return float(cleaned)
                except (ValueError, TypeError):
                    return None
            return None

        params = []
        results = []
        excluded_divisions = EXCLUDED_DIVISIONS_BY_EMPLOYEE.get(str(director_id).strip() if director_id is not None else None)

        if eval_year is not None:
            query = """
                SELECT
                    e.employee_id,
                    COALESCE(e.full_name, 'Unknown Employee') AS full_name,
                    COALESCE(e.company, 'N/A') AS company,
                    COALESCE(e.division, 'N/A') AS division,
                    COALESCE(e.department, 'N/A') AS department,
                    COALESCE(e.position, 'N/A') AS position,
                    e.job_level AS job_level,
                    sh.summary_json,
                    af.group_kpi_score AS af_group_kpi_score,
                    af.bu_lob_kpi_total_score AS af_bu_lob_kpi_total_score,
                    af.org_cap_total_score AS af_org_cap_total_score,
                    af.people_dev_total_score AS af_people_dev_total_score,
                    af.bu_obj_total_score AS af_bu_obj_total_score,
                    af.perf_kpi_score AS af_perf_kpi_score,
                    af.core_behaviors_total_score AS af_core_behaviors_total_score,
                    af.leadership_behaviors_total_score AS af_leadership_behaviors_total_score,
                    af.final_total_score AS af_final_total_score
                FROM pe_staff e
                INNER JOIN employee_master em
                    ON TRIM(CAST(em.employee_id AS CHAR)) = TRIM(CAST(e.employee_id AS CHAR))
                LEFT JOIN staff_summary_history sh
                    ON CAST(sh.employee_id AS CHAR) = CAST(e.employee_id AS CHAR)
                    AND sh.eval_year = %s
                LEFT JOIN all_final_scores af
                    ON CAST(af.employee_id AS CHAR) = CAST(e.employee_id AS CHAR)
            """
            params.append(eval_year)

            conditions = [PE_ACTIVE_EMPLOYEE_MASTER_CONDITION, PE_PERMANENT_EMPLOYEE_MASTER_CONDITION, PE_EXCLUDED_COMPANY_SQL]
            if excluded_divisions:
                placeholders = ", ".join(["%s"] * len(excluded_divisions))
                conditions.append(f"e.division NOT IN ({placeholders})")
                params.extend(excluded_divisions)
            if employee_ids:
                placeholders = ", ".join(["%s"] * len(employee_ids))
                conditions.append(f"CAST(e.employee_id AS CHAR) IN ({placeholders})")
                params.extend(employee_ids)
            elif force_filter or director_id not in AUTHORIZED_EXPORTER_ID:
                if division_filter is not None:
                    if isinstance(division_filter, list):
                        placeholders = ", ".join(["%s"] * len(division_filter))
                        conditions.append(f"e.division IN ({placeholders})")
                        params.extend(division_filter)
                    else:
                        conditions.append("e.division = %s")
                        params.append(division_filter)

            if conditions:
                query += " WHERE " + " AND ".join(conditions)

            query += " ORDER BY e.division, e.full_name"

            print(f"DEBUG Director Query (summary): {query}")
            print(f"DEBUG Director Params (summary): {params}")

            cursor.execute(query, params)
            rows = cursor.fetchall()
            workflow_status_map = get_workflow_status_map(rows if isinstance(rows, list) else [], eval_year)

            for row in rows:
                summary_data = {}
                summary_json = row.get("summary_json") if isinstance(row, dict) else None
                if summary_json:
                    try:
                        summary_data = json.loads(summary_json)
                    except (ValueError, TypeError):
                        summary_data = {}

                def pick_score(summary_key, af_key):
                    summary_value = summary_data.get(summary_key)
                    summary_score = coerce_score(summary_value)
                    if summary_score is not None:
                        return summary_score
                    return coerce_score(row.get(af_key))

                results.append({
                    "employee_id": row.get("employee_id"),
                    "full_name": row.get("full_name") or "Unknown Employee",
                    "company": row.get("company") or "N/A",
                    "division": row.get("division") or "N/A",
                    "department": row.get("department") or "N/A",
                    "position": row.get("position") or "N/A",
                    "job_level": row.get("job_level") or "N/A",
                    "group_kpi_score": pick_score("group_kpi_score", "af_group_kpi_score"),
                    "bu_lob_kpi_total_score": pick_score("bu_lob_kpi_score", "af_bu_lob_kpi_total_score"),
                    "org_cap_total_score": pick_score("org_cap_score", "af_org_cap_total_score"),
                    "people_dev_total_score": pick_score("people_dev_score", "af_people_dev_total_score"),
                    "bu_obj_total_score": pick_score("bu_obj_score", "af_bu_obj_total_score"),
                    "perf_kpi_score": pick_score("perf_kpi_score", "af_perf_kpi_score"),
                    "core_behaviors_total_score": pick_score("core_behaviors_score", "af_core_behaviors_total_score"),
                    "leadership_behaviors_total_score": pick_score("leadership_behaviors_score", "af_leadership_behaviors_total_score"),
                    "final_total_score": pick_score("final_total_score", "af_final_total_score"),
                })

            print(f"DEBUG Director Results (summary): {len(results)} rows found")

        if results:
            return results

        # Fallback to all_final_scores when summary history is missing
        params = []

        # First, check what's in all_final_scores table
        cursor.execute("SELECT COUNT(*) as cnt FROM all_final_scores")
        count_result = cursor.fetchone()
        print(f"DEBUG: all_final_scores table has {count_result['cnt']} rows total")

        # Check sample employee_ids in all_final_scores
        cursor.execute("SELECT employee_id FROM all_final_scores LIMIT 5")
        sample_ids = cursor.fetchall()
        print(f"DEBUG: Sample employee_ids in all_final_scores: {[s['employee_id'] for s in sample_ids]}")

        # Check sample employee_ids in employees
        cursor.execute("SELECT employee_id FROM pe_staff LIMIT 5")
        sample_emp_ids = cursor.fetchall()
        print(f"DEBUG: Sample employee_ids in pe_staff: {[s['employee_id'] for s in sample_emp_ids]}")

        # Use INNER JOIN to only get employees who have scores in all_final_scores
        # Cast employee_id to handle potential type mismatches between tables
        query = """
            SELECT
                COALESCE(e.employee_id, af.employee_id) AS employee_id,
                COALESCE(e.full_name, 'Unknown Employee') AS full_name,
                COALESCE(e.company, 'N/A') AS company,
                COALESCE(e.division, 'N/A') AS division,
                COALESCE(e.department, 'N/A') AS department,
                COALESCE(e.position, 'N/A') AS position,
                e.job_level AS job_level,
                af.group_kpi_score, af.bu_lob_kpi_total_score, af.org_cap_total_score,
                af.people_dev_total_score, af.bu_obj_total_score, af.perf_kpi_score,
                af.core_behaviors_total_score, af.leadership_behaviors_total_score,
                af.final_total_score
            FROM all_final_scores af
            LEFT JOIN pe_staff e ON CAST(af.employee_id AS CHAR) = CAST(e.employee_id AS CHAR)
            INNER JOIN employee_master em ON TRIM(CAST(em.employee_id AS CHAR)) = TRIM(CAST(COALESCE(e.employee_id, af.employee_id) AS CHAR))
        """

        conditions = [PE_ACTIVE_EMPLOYEE_MASTER_CONDITION, PE_PERMANENT_EMPLOYEE_MASTER_CONDITION, PE_EXCLUDED_COMPANY_SQL]
        if employee_ids:
            placeholders = ", ".join(["%s"] * len(employee_ids))
            conditions.append(f"CAST(af.employee_id AS CHAR) IN ({placeholders})")
            params.extend(employee_ids)
        elif force_filter or director_id not in AUTHORIZED_EXPORTER_ID:
            if division_filter is not None:
                if isinstance(division_filter, list):
                    placeholders = ", ".join(["%s"] * len(division_filter))
                    conditions.append(f"e.division IN ({placeholders})")
                    params.extend(division_filter)
                else:
                    conditions.append("e.division = %s")
                    params.append(division_filter)

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        query += " ORDER BY e.division, e.full_name"

        print(f"DEBUG Director Query: {query}")
        print(f"DEBUG Director Params: {params}")

        cursor.execute(query, params)
        results = cursor.fetchall()

        print(f"DEBUG Director Results: {len(results)} rows found")

        return results

    except Exception as e:
        print(f"Error fetching director subordinates: {e}")
        import traceback
        traceback.print_exc()
        return []
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@app.route('/performance_dashboard')
def performance_dashboard():
    """Performance Evaluation Dashboard - View subordinates' PE scores by division/department."""
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    employee_id = str(session['employee_id']).strip()

    reporting_employee_ids = get_reporting_employee_ids(employee_id)

    # Check if user has director access
    if not reporting_employee_ids and employee_id not in SPECIAL_EXPORT_ACCESS:
        flash("You do not have permission to access the Performance Evaluation Dashboard.", "error")
        return redirect(url_for('profile_page'))

    division_filter = SPECIAL_EXPORT_ACCESS.get(employee_id)
    is_super_director = str(employee_id) in AUTHORIZED_EXPORTER_ID

    selected_division = None
    selected_department = None
    selected_company = None
    available_divisions = []
    available_departments = []
    available_companies = []

    staff_reporting_rows = []
    employee_ids_for_filter = None
    show_dept_filters = False

    if is_super_director:
        selected_division = request.args.get('division')
        selected_department = request.args.get('department')
        selected_company = request.args.get('company')
        if isinstance(selected_division, str):
            selected_division = selected_division.strip()
        if isinstance(selected_department, str):
            selected_department = selected_department.strip()
        if isinstance(selected_company, str):
            selected_company = selected_company.strip()
        connection = None
        cursor = None
        company_divisions = {}
        company_departments = {}
        division_departments = {}
        try:
            connection = get_db_connection()
            if connection:
                cursor = connection.cursor()
                cursor.execute(
                    "SELECT employee_id, company, division, department FROM pe_staff "
                    "WHERE company IS NOT NULL AND company <> '' "
                    "AND division IS NOT NULL AND division <> '' "
                    "AND department IS NOT NULL AND department <> '' "
                    "ORDER BY company, division, department"
                )
                staff_reporting_rows = cursor.fetchall()
                for row in staff_reporting_rows:
                    if not row or len(row) < 4:
                        continue
                    employee_id_row, company, division, department = row[0], row[1], row[2], row[3]
                    company = str(company).strip() if company is not None else ''
                    division = str(division).strip() if division is not None else ''
                    department = str(department).strip() if department is not None else ''
                    if not company or not division or not department or company in TEMP_BLOCKED_PE_COMPANIES:
                        continue
                    company_divisions.setdefault(company, set()).add(division)
                    company_departments.setdefault(company, set()).add(department)
                    division_departments.setdefault((company, division), set()).add(department)

                if not company_divisions:
                    cursor.execute(
                        "SELECT DISTINCT company, division, department FROM pe_staff "
                        "WHERE company IS NOT NULL AND company <> '' "
                        "AND division IS NOT NULL AND division <> '' "
                        "AND department IS NOT NULL AND department <> '' "
                        "ORDER BY company, division, department"
                    )
                    for row in cursor.fetchall():
                        if not row or len(row) < 3:
                            continue
                        company = str(row[0]).strip() if row[0] is not None else ''
                        division = str(row[1]).strip() if row[1] is not None else ''
                        department = str(row[2]).strip() if row[2] is not None else ''
                        if not company or not division or not department or company in TEMP_BLOCKED_PE_COMPANIES:
                            continue
                        company_divisions.setdefault(company, set()).add(division)
                        company_departments.setdefault(company, set()).add(department)
                        division_departments.setdefault((company, division), set()).add(department)
        except Exception as e:
            print(f"Error loading companies/divisions for director filter: {e}")
        finally:
            if cursor:
                cursor.close()
            if connection:
                connection.close()

        excluded_divisions = EXCLUDED_DIVISIONS_BY_EMPLOYEE.get(employee_id)
        if excluded_divisions:
            for company, divisions in list(company_divisions.items()):
                filtered = [d for d in divisions if d not in excluded_divisions]
                if filtered:
                    company_divisions[company] = filtered
                else:
                    company_divisions.pop(company, None)
            for company, departments in list(company_departments.items()):
                filtered = [d for d in departments if d not in excluded_divisions]
                if filtered:
                    company_departments[company] = filtered
                else:
                    company_departments.pop(company, None)
            division_departments = {
                k: v for k, v in division_departments.items()
                if k[1] not in excluded_divisions
            }

        available_companies = sorted(company_divisions.keys())
        available_divisions = sorted({d for divisions in company_divisions.values() for d in divisions})
        available_departments = sorted({d for deps in company_departments.values() for d in deps})

        # Remove 'TSpace' label from division/department picklists
        available_divisions = [d for d in available_divisions if d not in TSPACE_LABELS]
        available_departments = [d for d in available_departments if d not in TSPACE_LABELS]
        company_divisions = {k: sorted(v) for k, v in company_divisions.items()}
        company_departments = {k: sorted(v) for k, v in company_departments.items()}
        division_departments = {k: sorted(v) for k, v in division_departments.items()}

        if selected_company and selected_company != 'ALL':
            if selected_company not in company_divisions:
                selected_company = None
                selected_division = None
                selected_department = None
            else:
                available_divisions = company_divisions.get(selected_company, [])
                available_departments = company_departments.get(selected_company, [])
                available_divisions = [d for d in available_divisions if d not in TSPACE_LABELS]
                available_departments = [d for d in available_departments if d not in TSPACE_LABELS]
                if selected_division not in available_divisions:
                    selected_division = None
                if selected_division:
                    available_departments = division_departments.get((selected_company, selected_division), [])
                    available_departments = [d for d in available_departments if d not in TSPACE_LABELS]
                if selected_department not in available_departments:
                    selected_department = None

        if staff_reporting_rows:
            excluded_divisions = EXCLUDED_DIVISIONS_BY_EMPLOYEE.get(employee_id)
            if excluded_divisions:
                staff_reporting_rows = [
                    row for row in staff_reporting_rows
                    if row and len(row) >= 3 and str(row[2]).strip() not in excluded_divisions
                ]
            if selected_department and selected_department != "ALL":
                employee_ids_for_filter = [
                    str(row[0]) for row in staff_reporting_rows
                    if row and len(row) >= 4 and str(row[3]).strip() == str(selected_department)
                ]
            elif selected_division and selected_division != "ALL":
                employee_ids_for_filter = [
                    str(row[0]) for row in staff_reporting_rows
                    if row and len(row) >= 4 and str(row[2]).strip() == str(selected_division)
                ]
            elif selected_company and selected_company != "ALL":
                employee_ids_for_filter = [
                    str(row[0]) for row in staff_reporting_rows
                    if row and len(row) >= 4 and str(row[1]).strip() == str(selected_company)
                ]
            else:
                employee_ids_for_filter = [
                    str(row[0]) for row in staff_reporting_rows if row and row[0] is not None
                ]
    else:
        selected_division = request.args.get('division')
        selected_department = request.args.get('department')
        if isinstance(selected_division, str):
            selected_division = selected_division.strip()
        if isinstance(selected_department, str):
            selected_department = selected_department.strip()
        if reporting_employee_ids:
            connection = None
            cursor = None
            division_departments = {}
            try:
                connection = get_db_connection()
                if connection:
                    cursor = connection.cursor()
                    placeholders = ", ".join(["%s"] * len(reporting_employee_ids))
                    cursor.execute(
                        f"SELECT employee_id, division, department FROM pe_staff WHERE employee_id IN ({placeholders})",
                        reporting_employee_ids
                    )
                    staff_reporting_rows = cursor.fetchall()
                    for row in staff_reporting_rows:
                        if not row or len(row) < 3:
                            continue
                        division = str(row[1]).strip() if row[1] is not None else ''
                        department = str(row[2]).strip() if row[2] is not None else ''
                        if not division or not department:
                            continue
                        division_departments.setdefault(division, set()).add(department)
            except Exception as e:
                print(f"Error loading divisions/departments for manager filter: {e}")
            finally:
                if cursor:
                    cursor.close()
                if connection:
                    connection.close()

            available_divisions = sorted(division_departments.keys())
            available_departments = sorted({d for deps in division_departments.values() for d in deps})
            available_divisions = [d for d in available_divisions if d not in TSPACE_LABELS]
            available_departments = [d for d in available_departments if d not in TSPACE_LABELS]
            division_departments = {k: sorted(v) for k, v in division_departments.items()}
            show_dept_filters = len(available_departments) > 2

            if selected_division and selected_division != "ALL":
                available_departments = division_departments.get(selected_division, [])
                available_departments = [d for d in available_departments if d not in TSPACE_LABELS]
                if selected_department not in available_departments:
                    selected_department = None

            if staff_reporting_rows:
                if selected_department and selected_department != "ALL":
                    employee_ids_for_filter = [
                        str(row[0]) for row in staff_reporting_rows
                        if row and len(row) >= 3 and str(row[2]).strip() == str(selected_department)
                    ]
                elif selected_division and selected_division != "ALL":
                    employee_ids_for_filter = [
                        str(row[0]) for row in staff_reporting_rows
                        if row and len(row) >= 3 and str(row[1]).strip() == str(selected_division)
                    ]

    force_filter = False
    if is_super_director:
        if selected_department and selected_department != "ALL":
            force_filter = True
        elif selected_division and selected_division != "ALL":
            division_filter = selected_division
            force_filter = True
        elif selected_company and selected_company != "ALL":
            division_filter = available_divisions
            force_filter = True

    # Get available years (FY2026+ only)
    baseline_year = 2026
    current_year = max(get_current_fiscal_year(), baseline_year)
    requested_year = max(safe_int(request.args.get('year'), session.get('eval_year', current_year)), baseline_year)
    available_years = [y for y in list_summary_years(str(employee_id)) if y >= baseline_year]
    for y in (requested_year, current_year, baseline_year):
        if y not in available_years:
            available_years.insert(0, y)
    available_years = sorted(set(available_years), reverse=True)
    session['eval_year'] = requested_year

    # Get subordinates
    subordinates = get_director_subordinates(division_filter, requested_year, employee_id, force_filter, employee_ids=employee_ids_for_filter if employee_ids_for_filter else (reporting_employee_ids if reporting_employee_ids else None))

    # Search filter (by employee name)
    def normalize_name(value):
        return " ".join(str(value or "").strip().split()).casefold()

    def first_name(value):
        normalized = normalize_name(value)
        return normalized.split(" ", 1)[0] if normalized else ""

    search_query = (request.args.get('q') or "").strip()
    if search_query:
        needle = normalize_name(search_query)
        if " " not in needle:
            # Single-token search: match first name only (exact or prefix), not surname contains.
            first_name_matches = [
                s for s in subordinates
                if first_name(s.get('full_name')) == needle
                or first_name(s.get('full_name')).startswith(needle)
            ]
            if first_name_matches:
                subordinates = first_name_matches
            else:
                subordinates = [
                    s for s in subordinates
                    if normalize_name(s.get('full_name')) == needle
                ]
        else:
            exact_matches = [
                s for s in subordinates
                if normalize_name(s.get('full_name')) == needle
            ]
            if exact_matches:
                subordinates = exact_matches
            else:
                subordinates = [
                    s for s in subordinates
                    if needle in normalize_name(s.get('full_name'))
                ]

    # Exclude Managing Director from dashboard list
    subordinates = [
        s for s in subordinates
        if (s.get('position') or '').strip().casefold() != 'managing director'
    ]

    def to_number(value):
        if value is None:
            return None
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            cleaned = value.strip()
            if cleaned == "":
                return None
            try:
                return float(cleaned)
            except (ValueError, TypeError):
                return None
        return None

    sort_by = (request.args.get('sort_by') or 'name').strip().lower()
    sort_dir = (request.args.get('sort_dir') or 'asc').strip().lower()
    if sort_by == 'final_score':
        def score_key(row):
            value = to_number(row.get('final_total_score'))
            name_key = (row.get('full_name') or '').casefold()
            if sort_dir == 'desc':
                none_rank = value is None
                score = -(value or 0)
            else:
                none_rank = value is not None
                score = value or 0
            return (none_rank, score, name_key)

        subordinates = sorted(subordinates, key=score_key)
    else:
        subordinates = sorted(
            subordinates,
            key=lambda s: (s.get('full_name') or '').casefold(),
            reverse=(sort_dir == 'desc')
        )

    # Calculate statistics (overall, after search filter)
    total_staff = sum(
        1
        for s in subordinates
        if (s.get('position') or '').strip().casefold() != 'managing director'
    )
    scores = [float(s['final_total_score']) for s in subordinates if to_number(s.get('final_total_score')) is not None]
    avg_score = sum(scores) / len(scores) if scores else 0
    max_score = max(scores) if scores else 0
    min_score = min(scores) if scores else 0

    # Pagination (10 rows per page)
    per_page = 10
    current_page = max(1, safe_int(request.args.get('page'), 1))
    total_pages = max(1, (total_staff + per_page - 1) // per_page)
    if current_page > total_pages:
        current_page = total_pages
    full_promotion_status_map = get_dashboard_staff_promotion_status_map(
        [sub.get('employee_id') for sub in subordinates if isinstance(sub, dict)],
        requested_year,
        proposer_employee_id=employee_id,
    )
    proposed_staff_count = sum(
        1 for status in full_promotion_status_map.values()
        if str(status.get('label') or '').strip().lower() == 'proposed'
    )
    start_index = (current_page - 1) * per_page
    subordinates = subordinates[start_index:start_index + per_page]
    workflow_status_map = get_workflow_status_map(subordinates if isinstance(subordinates, list) else [], requested_year)
    for sub in subordinates:
        if isinstance(sub, dict):
            employee_id_value = str(sub.get('employee_id') or '').strip()
            status_data = workflow_status_map.get(employee_id_value, {
                'code': 'draft',
                'label': 'Draft',
                'bg': 'linear-gradient(135deg, #e2e8f0 0%, #cbd5e1 100%)',
                'color': '#334155',
                'border': '#94a3b8',
            })
            status_data = dict(status_data)
            status_data['short_label'] = get_dashboard_status_label(status_data.get('code'))
            sub['workflow_status'] = status_data
            sub['can_submit_promotion'] = can_submit_staff_promotion(employee_id, employee_id_value)
            sub['promotion_status'] = full_promotion_status_map.get(employee_id_value, {
                'label': '-',
                'bg': '#f8fafc',
                'color': '#64748b',
                'border': '#cbd5e1',
            })

    # Build navigation
    nav_html = get_nav_html('performance_dashboard', session.get('job_level'), session.get('full_name', 'N/A'))

    return render_template_string(
        performance_dashboard_TEMPLATE,
        nav_html=nav_html,
        page_title="Performance Evaluation Dashboard",
        divisions=division_filter if isinstance(division_filter, list) else [division_filter] if division_filter else None,
        selected_department=selected_department,
        subordinates=subordinates,
        total_staff=total_staff,
        avg_score=avg_score,
        max_score=max_score,
        min_score=min_score,
        proposed_staff_count=proposed_staff_count,
        available_years=available_years,
        selected_year=requested_year,
        is_super_director=is_super_director,
        available_divisions=available_divisions,
        selected_division=selected_division,
        selected_company=selected_company,
        available_departments=available_departments,
        show_dept_filters=show_dept_filters,
        is_super_admin=is_super_admin_employee(session.get('employee_id')),
        available_companies=available_companies,
        can_access_distribution=(employee_id in SPECIAL_EXPORT_ACCESS or employee_id in AUTHORIZED_EXPORTER_ID),
        company_param=selected_company if selected_company and selected_company != "ALL" else None,
        division_param=selected_division if selected_division and selected_division != "ALL" else None,
        department_param=selected_department if selected_department and selected_department != "ALL" else None,
        search_query=search_query,
        sort_by=sort_by,
        sort_dir=sort_dir,
        current_page=current_page,
        total_pages=total_pages
    )


@app.route('/staff_promotion_form/<employee_id>', methods=['GET', 'POST'])
def staff_promotion_form(employee_id):
    if 'employee_id' not in session:
        return redirect(url_for('login'))
    if not is_staff_promotion_module_enabled():
        flash("Staff Promotion is not available yet.", "info")
        return redirect(url_for('performance_dashboard'))

    viewer_id = str(session.get('employee_id') or '').strip()
    target_employee_id = str(employee_id or '').strip()
    selected_year = resolve_staff_promotion_year_from_request()

    if not can_submit_staff_promotion(viewer_id, target_employee_id):
        flash("You do not have permission to submit a staff promotion form for this employee.", "error")
        return redirect(url_for('performance_dashboard'))

    if request.method == 'POST' and is_staff_promotion_year_locked(selected_year):
        flash("This staff promotion year is closed and is now read-only.", "error")
        return redirect(url_for('staff_promotion_form', employee_id=target_employee_id, year=selected_year))

    profile_snapshot = build_staff_promotion_profile_snapshot(target_employee_id, selected_year)
    profile_snapshot['score_history'] = get_staff_promotion_score_history(target_employee_id, selected_year, limit=3)
    form_values = {
        'current_job_description': '',
        'proposed_job_level': '',
        'new_job_title': '',
        'new_job_description': '',
        'new_job_assignment': '',
        'reasons_for_adjustment': '',
        'manual_score_year_1': '',
        'manual_score_value_1': '',
        'manual_score_year_2': '',
        'manual_score_value_2': '',
        'manual_score_year_3': '',
        'manual_score_value_3': '',
    }
    latest_form = get_staff_promotion_latest_form_for_manager(target_employee_id, viewer_id, selected_year)
    if latest_form and str(latest_form.get('status') or '').strip().lower() not in {'draft_manager', ''}:
        flash("This promotion form has already been submitted and is now in the review workflow.", "info")
        return redirect(url_for('performance_dashboard', year=selected_year))

    if latest_form:
        for key in form_values.keys():
            form_values[key] = str(latest_form.get(key, '') or '').strip()
        latest_profile_snapshot = latest_form.get('profile_snapshot_json')
        if isinstance(latest_profile_snapshot, str):
            try:
                latest_profile_snapshot = json.loads(latest_profile_snapshot or '{}')
            except Exception:
                latest_profile_snapshot = {}
        if not isinstance(latest_profile_snapshot, dict):
            latest_profile_snapshot = {}
        latest_manual_entries = normalize_staff_promotion_manual_score_entries(latest_profile_snapshot.get('manual_score_entries'))
        for idx in range(1, 4):
            entry = latest_manual_entries[idx - 1] if idx - 1 < len(latest_manual_entries) else {}
            form_values[f'manual_score_year_{idx}'] = str(entry.get('eval_year') or '')
            form_values[f'manual_score_value_{idx}'] = str(entry.get('final_total_score') or '')

    if request.method == 'POST':
        for key in form_values.keys():
            form_values[key] = str(request.form.get(key, '') or '').strip()
        manual_score_entries, manual_error = extract_staff_promotion_manual_score_entries(request.form)
        if manual_error:
            flash(manual_error, "error")
        profile_snapshot['manual_score_entries'] = manual_score_entries
        form_action = str(request.form.get('form_action', 'submit') or 'submit').strip().lower()
        if manual_error:
            pass
        elif form_action == 'save':
            target_roles = get_staff_promotion_target_roles(target_employee_id)
            saved = save_staff_promotion_form(
                target_employee_id=target_employee_id,
                proposer_employee_id=viewer_id,
                eval_year=selected_year,
                profile_snapshot=profile_snapshot,
                score_history=profile_snapshot.get('score_history', []),
                form_data=form_values,
                status='draft_manager',
                director_employee_id=target_roles.get('director_employee_id'),
                current_reviewer_employee_id=viewer_id,
                form_id=latest_form.get('id') if isinstance(latest_form, dict) else None,
            )
            if saved:
                flash("Staff promotion form saved as draft.", "success")
                return redirect(url_for('staff_promotion_form', employee_id=target_employee_id, year=selected_year))
            flash("Unable to save the draft. Please try again.", "error")
        else:
            missing_labels = {
                'current_job_description': 'Current Job Description',
                'proposed_job_level': 'Proposed Job Level',
                'new_job_title': 'New Job Title',
                'new_job_description': 'New Job Description',
                'new_job_assignment': 'New Job Assignment',
                'reasons_for_adjustment': 'Reasons for Adjustment',
            }
            missing = [label for key, label in missing_labels.items() if not form_values.get(key)]
            if missing:
                flash("Please complete all promotion form fields before submitting.", "error")
            else:
                target_roles = get_staff_promotion_target_roles(target_employee_id)
                director_id = str(target_roles.get('director_employee_id') or '').strip()
                if not director_id:
                    flash("Director assignment was not found for this employee. Please contact HR.", "error")
                    return redirect(url_for('staff_promotion_form', employee_id=target_employee_id, year=selected_year))
                saved = save_staff_promotion_form(
                    target_employee_id=target_employee_id,
                    proposer_employee_id=viewer_id,
                    eval_year=selected_year,
                    profile_snapshot=profile_snapshot,
                    score_history=profile_snapshot.get('score_history', []),
                    form_data=form_values,
                    status='submitted_to_director',
                    director_employee_id=director_id,
                    current_reviewer_employee_id=director_id,
                    form_id=latest_form.get('id') if isinstance(latest_form, dict) else None,
                )
                if saved:
                    flash("Staff promotion form submitted to Director for review.", "success")
                    return redirect(url_for('performance_dashboard', year=selected_year))
                flash("Unable to save the staff promotion form. Please try again.", "error")

    nav_html = get_nav_html('performance_dashboard', session.get('job_level'), session.get('full_name', 'N/A'))
    return render_template_string(
        STAFF_PROMOTION_FORM_TEMPLATE,
        nav_html=nav_html,
        page_title="Staff Promotion Form",
        form_subtitle="Nomination form for managers to propose staff promotions.",
        info_text="Complete this form to submit a staff promotion nomination to your Director.",
        form_action_url=url_for('staff_promotion_form', employee_id=target_employee_id, year=selected_year),
        form_id=safe_int(latest_form.get('id') if isinstance(latest_form, dict) else 0, 0) or None,
        save_button_label="Save",
        submit_button_label="Submit to Director",
        back_url=url_for('performance_dashboard', year=selected_year),
        selected_year=selected_year,
        promotion_lock_date_text=get_staff_promotion_lock_date(selected_year).strftime('%B %d, %Y'),
        profile_snapshot=profile_snapshot,
        photo_src=url_for('user_photo_for_employee', employee_id=target_employee_id),
        form_values=form_values,
        manual_score_years=get_staff_promotion_manual_year_options(selected_year),
    )


@app.route('/staff_promotion_forms/<int:form_id>/review', methods=['GET', 'POST'])
def review_staff_promotion_form(form_id: int):
    if 'employee_id' not in session:
        return redirect(url_for('login'))
    if not is_staff_promotion_module_enabled():
        flash("Staff Promotion is not available yet.", "info")
        return redirect(url_for('performance_dashboard'))

    viewer_id = str(session.get('employee_id') or '').strip()
    selected_year = max(resolve_staff_promotion_year_from_request(), 2026)
    form = get_staff_promotion_form(form_id, eval_year=selected_year)
    if not form:
        flash("Staff promotion form not found.", "error")
        return redirect(url_for('staff_promotion_inbox', year=selected_year))
    if not is_staff_promotion_test_super_admin(viewer_id) and (viewer_id != str(form.get('current_reviewer_employee_id') or '').strip() or not is_director_promotion_user(viewer_id)):
        flash("You do not have permission to review this promotion form.", "error")
        return redirect(url_for('performance_dashboard'))
    if str(form.get('status') or '').strip().lower() not in {'submitted_to_director', 'draft_director'}:
        flash("This promotion form is no longer in the director review stage.", "info")
        return redirect(url_for('staff_promotion_inbox', year=selected_year))
    if request.method == 'POST' and is_staff_promotion_year_locked(selected_year):
        flash("This staff promotion year is closed and is now read-only.", "error")
        return redirect(url_for('review_staff_promotion_form', form_id=form_id, year=selected_year))

    mark_staff_promotion_form_viewed(form_id)
    form = get_staff_promotion_form(form_id, eval_year=selected_year) or form
    profile_snapshot = dict(form.get('profile_snapshot') or {})
    profile_snapshot['score_history'] = form.get('score_history') or []
    form_values = {
        'current_job_description': str(form.get('current_job_description') or '').strip(),
        'proposed_job_level': str(form.get('proposed_job_level') or '').strip(),
        'new_job_title': str(form.get('new_job_title') or '').strip(),
        'new_job_description': str(form.get('new_job_description') or '').strip(),
        'new_job_assignment': str(form.get('new_job_assignment') or '').strip(),
        'reasons_for_adjustment': str(form.get('reasons_for_adjustment') or '').strip(),
        'manual_score_year_1': '',
        'manual_score_value_1': '',
        'manual_score_year_2': '',
        'manual_score_value_2': '',
        'manual_score_year_3': '',
        'manual_score_value_3': '',
    }
    manual_score_entries = normalize_staff_promotion_manual_score_entries(profile_snapshot.get('manual_score_entries'))
    for idx in range(1, 4):
        entry = manual_score_entries[idx - 1] if idx - 1 < len(manual_score_entries) else {}
        form_values[f'manual_score_year_{idx}'] = str(entry.get('eval_year') or '')
        form_values[f'manual_score_value_{idx}'] = str(entry.get('final_total_score') or '')

    if request.method == 'POST':
        for key in form_values.keys():
            form_values[key] = str(request.form.get(key, '') or '').strip()
        manual_score_entries, manual_error = extract_staff_promotion_manual_score_entries(request.form)
        if manual_error:
            flash(manual_error, "error")
        profile_snapshot['manual_score_entries'] = manual_score_entries
        form_action = str(request.form.get('form_action', 'submit') or 'submit').strip().lower()
        if manual_error:
            pass
        elif form_action == 'save':
            saved = save_staff_promotion_form(
                target_employee_id=form.get('target_employee_id'),
                proposer_employee_id=form.get('proposer_employee_id'),
                eval_year=selected_year,
                profile_snapshot=profile_snapshot,
                score_history=profile_snapshot.get('score_history', []),
                form_data=form_values,
                status='draft_director',
                director_employee_id=form.get('director_employee_id'),
                current_reviewer_employee_id=viewer_id,
                form_id=form_id,
            )
            if saved:
                flash("Staff promotion review saved as draft.", "success")
                return redirect(url_for('review_staff_promotion_form', form_id=form_id, year=selected_year))
            flash("Unable to save the director review draft. Please try again.", "error")
        else:
            missing_labels = {
                'current_job_description': 'Current Job Description',
                'proposed_job_level': 'Proposed Job Level',
                'new_job_title': 'New Job Title',
                'new_job_description': 'New Job Description',
                'new_job_assignment': 'New Job Assignment',
                'reasons_for_adjustment': 'Reasons for Adjustment',
            }
            missing = [label for key, label in missing_labels.items() if not form_values.get(key)]
            if missing:
                flash("Please complete all promotion form fields before submitting to HR & Admin Director.", "error")
            else:
                saved = save_staff_promotion_form(
                    target_employee_id=form.get('target_employee_id'),
                    proposer_employee_id=form.get('proposer_employee_id'),
                    eval_year=selected_year,
                    profile_snapshot=profile_snapshot,
                    score_history=profile_snapshot.get('score_history', []),
                    form_data=form_values,
                    status='submitted_to_hr',
                    director_employee_id=form.get('director_employee_id'),
                    current_reviewer_employee_id=HR_DIRECTOR_EMPLOYEE_ID,
                    form_id=form_id,
                )
                if saved:
                    flash("Staff promotion form submitted to HR & Admin Director.", "success")
                    return redirect(url_for('staff_promotion_inbox', year=selected_year))
                flash("Unable to submit the staff promotion form to HR & Admin Director. Please try again.", "error")

    nav_html = get_nav_html('staff_promotion_inbox', session.get('job_level'), session.get('full_name', 'N/A'))
    return render_template_string(
        STAFF_PROMOTION_FORM_TEMPLATE,
        nav_html=nav_html,
        page_title="Staff Promotion Review",
        form_subtitle="Director review form for staff promotion nominations submitted by managers.",
        info_text="Review, edit, and submit this promotion nomination to HR & Admin Director when ready.",
        form_action_url=url_for('review_staff_promotion_form', form_id=form_id, year=selected_year),
        form_id=form_id,
        save_button_label="Save Review Draft",
        submit_button_label="Submit to HR & Admin Director",
        back_url=url_for('staff_promotion_inbox', year=selected_year),
        selected_year=selected_year,
        promotion_lock_date_text=get_staff_promotion_lock_date(selected_year).strftime('%B %d, %Y'),
        profile_snapshot=profile_snapshot,
        photo_src=url_for('user_photo_for_employee', employee_id=form.get('target_employee_id')),
        form_values=form_values,
        manual_score_years=get_staff_promotion_manual_year_options(selected_year),
    )


@app.route('/staff_promotion_forms')
def staff_promotion_inbox():
    if 'employee_id' not in session:
        return redirect(url_for('login'))
    if not is_staff_promotion_module_enabled():
        flash("Staff Promotion is not available yet.", "info")
        return redirect(url_for('performance_dashboard'))
    viewer_id = str(session.get('employee_id') or '').strip()
    if not can_access_staff_promotion_inbox(viewer_id):
        flash("You do not have permission to access the Staff Promotion page.", "error")
        return redirect(url_for('performance_dashboard'))

    baseline_year = 2026
    current_year = max(get_staff_promotion_year(), baseline_year)
    available_years = [y for y in list_staff_promotion_years() if y >= baseline_year]
    requested_year = max(resolve_staff_promotion_year_from_request(), baseline_year)
    sort_by = str(request.args.get('sort_by') or 'newest').strip().lower()
    if sort_by not in {'newest', 'division', 'job_level_asc', 'job_level_desc'}:
        sort_by = 'newest'
    if requested_year not in available_years:
        available_years.insert(0, requested_year)
    available_years = sorted(set(available_years), reverse=True)

    forms = list_staff_promotion_forms(eval_year=requested_year, sort_by=sort_by)
    viewer_is_hr = is_hr_director_user(viewer_id)
    for form in forms:
        status_value = str(form.get('status') or '').strip().lower()
        if viewer_is_hr:
            if status_value == 'submitted_to_hr':
                form['status_label'] = 'Pending Final Decision'
            elif status_value == 'approved':
                form['status_label'] = 'Approved'
            elif status_value == 'rejected':
                form['status_label'] = 'Rejected'
            elif status_value in {'submitted_to_director', 'draft_director', 'draft_manager'}:
                form['status_label'] = 'Proposed'
            else:
                form['status_label'] = status_value.replace('_', ' ').title() if status_value else '-'
        else:
            if status_value == 'submitted_to_director':
                form['status_label'] = 'Pending Director Review'
            elif status_value == 'draft_director':
                form['status_label'] = 'Director Draft'
            elif status_value == 'submitted_to_hr':
                form['status_label'] = 'Submitted to HR & Admin Director'
            elif status_value == 'approved':
                form['status_label'] = 'Approved'
            elif status_value == 'rejected':
                form['status_label'] = 'Rejected'
            elif status_value == 'draft_manager':
                form['status_label'] = 'Proposed'
            else:
                form['status_label'] = status_value.replace('_', ' ').title() if status_value else '-'
        if viewer_is_hr:
            form['action_label'] = 'View'
            form['action_url'] = url_for('view_staff_promotion_form', form_id=form.get('id'), year=requested_year)
        else:
            form['action_label'] = 'Review'
            form['action_url'] = url_for('review_staff_promotion_form', form_id=form.get('id'), year=requested_year)

    nav_html = get_nav_html('staff_promotion_inbox', session.get('job_level'), session.get('full_name', 'N/A'))
    return render_template_string(
        STAFF_PROMOTION_INBOX_TEMPLATE,
        nav_html=nav_html,
        page_title="Promotion Nominations",
        forms=forms,
        selected_year=requested_year,
        available_years=available_years,
        sort_by=sort_by,
    )


@app.route('/staff_promotion_forms/<int:form_id>/finalize', methods=['POST'])
def finalize_staff_promotion_form_route(form_id: int):
    if 'employee_id' not in session:
        return redirect(url_for('login'))
    if not is_staff_promotion_module_enabled():
        flash("Staff Promotion is not available yet.", "info")
        return redirect(url_for('performance_dashboard'))
    viewer_id = str(session.get('employee_id') or '').strip()
    selected_year = max(resolve_staff_promotion_year_from_request(), 2026)
    if not is_hr_director_user(viewer_id) and not is_staff_promotion_test_super_admin(viewer_id):
        flash("You do not have permission to finalize this promotion form.", "error")
        return redirect(url_for('performance_dashboard'))
    form = get_staff_promotion_form(form_id, eval_year=selected_year)
    if not form:
        flash("Staff promotion form not found.", "error")
        return redirect(url_for('staff_promotion_inbox', year=selected_year))
    final_action = str(request.form.get('final_action') or '').strip().lower()
    if final_action not in {'approve', 'reject'}:
        flash("Invalid final action.", "error")
        return redirect(url_for('view_staff_promotion_form', form_id=form_id, year=selected_year))
    desired_status = 'approved' if final_action == 'approve' else 'rejected'
    success = finalize_staff_promotion_form(form_id, desired_status)
    if success:
        flash(
            "Staff promotion form marked as Approved." if desired_status == 'approved'
            else "Staff promotion form marked as Rejected.",
            "success"
        )
    else:
        flash("Unable to update the final promotion decision. Please try again.", "error")
    return redirect(url_for('view_staff_promotion_form', form_id=form_id, year=selected_year))


@app.route('/staff_promotion_forms/<int:form_id>')
def view_staff_promotion_form(form_id: int):
    if 'employee_id' not in session:
        return redirect(url_for('login'))
    if not is_staff_promotion_module_enabled():
        flash("Staff Promotion is not available yet.", "info")
        return redirect(url_for('performance_dashboard'))
    viewer_id = str(session.get('employee_id') or '').strip()
    selected_year = max(resolve_staff_promotion_year_from_request(), 2026)
    form = get_staff_promotion_form(form_id, eval_year=selected_year)
    if not form:
        flash("Staff promotion form not found.", "error")
        return redirect(url_for('staff_promotion_inbox', year=selected_year))
    if viewer_id == str(form.get('current_reviewer_employee_id') or '').strip() and str(form.get('status') or '').strip().lower() in {'submitted_to_director', 'draft_director'} and is_director_promotion_user(viewer_id):
        return redirect(url_for('review_staff_promotion_form', form_id=form_id, year=selected_year))
    if not is_staff_promotion_test_super_admin(viewer_id) and not is_hr_director_user(viewer_id) and viewer_id != str(form.get('proposer_employee_id') or '').strip():
        flash("You do not have permission to view this promotion form.", "error")
        return redirect(url_for('performance_dashboard'))
    if is_hr_director_user(viewer_id) or is_staff_promotion_test_super_admin(viewer_id):
        mark_staff_promotion_form_viewed(form_id)
        form = get_staff_promotion_form(form_id, eval_year=selected_year) or form

    status_value = str(form.get('status') or '').strip().lower()
    if status_value == 'submitted_to_director':
        form['status_badge'] = {'label': 'Pending Director Review', 'bg': '#dbeafe', 'color': '#1d4ed8', 'border': '#93c5fd'}
    elif status_value == 'draft_director':
        form['status_badge'] = {'label': 'Director Draft', 'bg': '#ede9fe', 'color': '#6d28d9', 'border': '#c4b5fd'}
    elif status_value == 'submitted_to_hr':
        form['status_badge'] = {'label': 'Pending HR & Admin Director Decision', 'bg': '#fef3c7', 'color': '#92400e', 'border': '#fcd34d'}
    elif status_value == 'approved':
        form['status_badge'] = {'label': 'Approved', 'bg': '#dcfce7', 'color': '#166534', 'border': '#86efac'}
    elif status_value == 'rejected':
        form['status_badge'] = {'label': 'Rejected', 'bg': '#fee2e2', 'color': '#991b1b', 'border': '#fca5a5'}
    else:
        form['status_badge'] = None

    current_page = 'staff_promotion_inbox' if (is_hr_director_user(viewer_id) or is_staff_promotion_test_super_admin(viewer_id)) else 'performance_dashboard'
    nav_html = get_nav_html(current_page, session.get('job_level'), session.get('full_name', 'N/A'))
    return render_template_string(
        STAFF_PROMOTION_DETAIL_TEMPLATE,
        nav_html=nav_html,
        page_title="Promotion Nomination Details",
        form=form,
        photo_src=url_for('user_photo_for_employee', employee_id=form['profile_snapshot'].get('employee_id')),
        selected_year=selected_year,
        show_final_actions=(is_hr_director_user(viewer_id) or is_staff_promotion_test_super_admin(viewer_id)) and status_value == 'submitted_to_hr',
    )


@app.route('/staff_promotion_forms/print')
def print_staff_promotion_forms():
    if 'employee_id' not in session:
        return redirect(url_for('login'))
    if not is_staff_promotion_module_enabled():
        flash("Staff Promotion is not available yet.", "info")
        return redirect(url_for('performance_dashboard'))
    if not is_hr_director_user(session.get('employee_id')) and not is_staff_promotion_test_super_admin(session.get('employee_id')):
        flash("Only HR & Admin Director can print submitted promotion forms.", "error")
        return redirect(url_for('performance_dashboard'))
    selected_year = max(resolve_staff_promotion_year_from_request(), 2026)
    forms = list_staff_promotion_forms(eval_year=selected_year)
    for form in forms:
        profile_snapshot = form.get('profile_snapshot', {}) if isinstance(form, dict) else {}
        employee_id = profile_snapshot.get('employee_id')
        full_name = profile_snapshot.get('full_name')
        form['photo_src'] = get_employee_photo_src(employee_id, full_name, session.get('access_token'))
    return render_template_string(
        STAFF_PROMOTION_PRINT_TEMPLATE,
        forms=forms,
        printed_at=datetime.datetime.now().strftime('%d %b %Y %H:%M'),
    )


@app.route('/staff_promotion_forms/<int:form_id>/print')
def print_single_staff_promotion_form(form_id: int):
    if 'employee_id' not in session:
        return redirect(url_for('login'))
    if not is_staff_promotion_module_enabled():
        flash("Staff Promotion is not available yet.", "info")
        return redirect(url_for('performance_dashboard'))
    viewer_id = str(session.get('employee_id') or '').strip()
    selected_year = max(resolve_staff_promotion_year_from_request(), 2026)
    form = get_staff_promotion_form(form_id, eval_year=selected_year)
    if not form:
        flash("Staff promotion form not found.", "error")
        return redirect(url_for('staff_promotion_inbox', year=selected_year))
    if not is_staff_promotion_test_super_admin(viewer_id) and not is_hr_director_user(viewer_id) and viewer_id != str(form.get('proposer_employee_id') or '').strip():
        flash("You do not have permission to print this promotion form.", "error")
        return redirect(url_for('performance_dashboard'))
    form['photo_src'] = get_employee_photo_src(
        form.get('profile_snapshot', {}).get('employee_id'),
        form.get('profile_snapshot', {}).get('full_name'),
        session.get('access_token'),
    )
    return render_template_string(
        STAFF_PROMOTION_PRINT_TEMPLATE,
        forms=[form],
        printed_at=datetime.datetime.now().strftime('%d %b %Y %H:%M'),
    )


@app.route('/performance_distribution')
def performance_distribution():
    """Performance distribution view with score bands and employee drilldown."""
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    employee_id = str(session['employee_id']).strip()
    if employee_id not in SPECIAL_EXPORT_ACCESS and employee_id not in AUTHORIZED_EXPORTER_ID:
        flash("Only directors can access the Performance Score Analysis page.", "error")
        return redirect(url_for('performance_dashboard'))
    reporting_employee_ids = get_reporting_employee_ids(employee_id)

    if not reporting_employee_ids and employee_id not in SPECIAL_EXPORT_ACCESS and employee_id not in AUTHORIZED_EXPORTER_ID:
        flash("You do not have permission to access the Performance Score Analysis page.", "error")
        return redirect(url_for('profile_page'))

    division_filter = SPECIAL_EXPORT_ACCESS.get(employee_id)
    is_super_director = str(employee_id) in AUTHORIZED_EXPORTER_ID

    selected_division = None
    selected_department = None
    selected_company = None
    available_divisions = []
    available_departments = []
    available_companies = []
    company_divisions = {}
    company_departments = {}
    division_departments = {}
    staff_reporting_rows = []
    employee_ids_for_filter = None
    show_dept_filters = False

    if is_super_director:
        selected_division = request.args.get('division')
        selected_department = request.args.get('department')
        selected_company = request.args.get('company')
        if isinstance(selected_division, str):
            selected_division = selected_division.strip()
        if isinstance(selected_department, str):
            selected_department = selected_department.strip()
        if isinstance(selected_company, str):
            selected_company = selected_company.strip()

        connection = None
        cursor = None
        try:
            connection = get_db_connection()
            if connection:
                cursor = connection.cursor()
                cursor.execute(
                    "SELECT ps.employee_id, ps.company, ps.division, ps.department FROM pe_staff ps "
                    "INNER JOIN employee_master em ON TRIM(CAST(em.employee_id AS CHAR)) = TRIM(CAST(ps.employee_id AS CHAR)) "
                    f"WHERE {PE_ACTIVE_EMPLOYEE_MASTER_CONDITION} "
                    f"AND {PE_PERMANENT_EMPLOYEE_MASTER_CONDITION} "
                    "AND ps.company IS NOT NULL AND ps.company <> '' "
                    "AND ps.division IS NOT NULL AND ps.division <> '' "
                    "AND ps.department IS NOT NULL AND ps.department <> '' "
                    "ORDER BY ps.company, ps.division, ps.department"
                )
                staff_reporting_rows = cursor.fetchall()
                for row in staff_reporting_rows:
                    if not row or len(row) < 4:
                        continue
                    employee_id_row, company, division, department = row[0], row[1], row[2], row[3]
                    company = str(company).strip() if company is not None else ''
                    division = str(division).strip() if division is not None else ''
                    department = str(department).strip() if department is not None else ''
                    if not company or not division or not department or company in TEMP_BLOCKED_PE_COMPANIES:
                        continue
                    company_divisions.setdefault(company, set()).add(division)
                    company_departments.setdefault(company, set()).add(department)
                    division_departments.setdefault((company, division), set()).add(department)

                if not company_divisions:
                    cursor.execute(
                        "SELECT DISTINCT ps.company, ps.division, ps.department FROM pe_staff ps "
                        "INNER JOIN employee_master em ON TRIM(CAST(em.employee_id AS CHAR)) = TRIM(CAST(ps.employee_id AS CHAR)) "
                        f"WHERE {PE_ACTIVE_EMPLOYEE_MASTER_CONDITION} "
                        f"AND {PE_PERMANENT_EMPLOYEE_MASTER_CONDITION} "
                        "AND ps.company IS NOT NULL AND ps.company <> '' "
                        "AND ps.division IS NOT NULL AND ps.division <> '' "
                        "AND ps.department IS NOT NULL AND ps.department <> '' "
                        "ORDER BY ps.company, ps.division, ps.department"
                    )
                    for row in cursor.fetchall():
                        if not row or len(row) < 3:
                            continue
                        company = str(row[0]).strip() if row[0] is not None else ''
                        division = str(row[1]).strip() if row[1] is not None else ''
                        department = str(row[2]).strip() if row[2] is not None else ''
                        if not company or not division or not department or company in TEMP_BLOCKED_PE_COMPANIES:
                            continue
                        company_divisions.setdefault(company, set()).add(division)
                        company_departments.setdefault(company, set()).add(department)
                        division_departments.setdefault((company, division), set()).add(department)
        except Exception as e:
            print(f"Error loading companies/divisions for distribution filter: {e}")
        finally:
            if cursor:
                cursor.close()
            if connection:
                connection.close()

        excluded_divisions = EXCLUDED_DIVISIONS_BY_EMPLOYEE.get(employee_id)
        if excluded_divisions:
            for company, divisions in list(company_divisions.items()):
                filtered = [d for d in divisions if d not in excluded_divisions]
                if filtered:
                    company_divisions[company] = filtered
                else:
                    company_divisions.pop(company, None)
            for company, departments in list(company_departments.items()):
                filtered = [d for d in departments if d not in excluded_divisions]
                if filtered:
                    company_departments[company] = filtered
                else:
                    company_departments.pop(company, None)
            division_departments = {
                k: v for k, v in division_departments.items()
                if k[1] not in excluded_divisions
            }

        available_companies = sorted(company_divisions.keys())
        available_divisions = sorted({d for divisions in company_divisions.values() for d in divisions})
        available_departments = sorted({d for deps in company_departments.values() for d in deps})
        available_divisions = [d for d in available_divisions if d not in TSPACE_LABELS]
        available_departments = [d for d in available_departments if d not in TSPACE_LABELS]
        company_divisions = {k: sorted(v) for k, v in company_divisions.items()}
        company_departments = {k: sorted(v) for k, v in company_departments.items()}
        division_departments = {k: sorted(v) for k, v in division_departments.items()}

        if selected_company and selected_company != 'ALL':
            if selected_company not in company_divisions:
                selected_company = None
                selected_division = None
                selected_department = None
            else:
                available_divisions = company_divisions.get(selected_company, [])
                available_departments = company_departments.get(selected_company, [])
                available_divisions = [d for d in available_divisions if d not in TSPACE_LABELS]
                available_departments = [d for d in available_departments if d not in TSPACE_LABELS]
                if selected_division not in available_divisions:
                    selected_division = None
                if selected_division:
                    available_departments = division_departments.get((selected_company, selected_division), [])
                    available_departments = [d for d in available_departments if d not in TSPACE_LABELS]
                if selected_department not in available_departments:
                    selected_department = None

        if staff_reporting_rows:
            excluded_divisions = EXCLUDED_DIVISIONS_BY_EMPLOYEE.get(employee_id)
            if excluded_divisions:
                staff_reporting_rows = [
                    row for row in staff_reporting_rows
                    if row and len(row) >= 4 and str(row[2]).strip() not in excluded_divisions and str(row[1]).strip() not in TEMP_BLOCKED_PE_COMPANIES
                ]
            else:
                staff_reporting_rows = [
                    row for row in staff_reporting_rows
                    if row and len(row) >= 4 and str(row[1]).strip() not in TEMP_BLOCKED_PE_COMPANIES
                ]
            if selected_department and selected_department != "ALL":
                employee_ids_for_filter = [
                    str(row[0]) for row in staff_reporting_rows
                    if row and len(row) >= 4 and str(row[3]).strip() == str(selected_department)
                ]
            elif selected_division and selected_division != "ALL":
                employee_ids_for_filter = [
                    str(row[0]) for row in staff_reporting_rows
                    if row and len(row) >= 4 and str(row[2]).strip() == str(selected_division)
                ]
            elif selected_company and selected_company != "ALL":
                employee_ids_for_filter = [
                    str(row[0]) for row in staff_reporting_rows
                    if row and len(row) >= 4 and str(row[1]).strip() == str(selected_company)
                ]
            else:
                employee_ids_for_filter = [
                    str(row[0]) for row in staff_reporting_rows if row and row[0] is not None
                ]
    else:
        selected_division = request.args.get('division')
        selected_department = request.args.get('department')
        if isinstance(selected_division, str):
            selected_division = selected_division.strip()
        if isinstance(selected_department, str):
            selected_department = selected_department.strip()
        if reporting_employee_ids:
            connection = None
            cursor = None
            division_departments = {}
            try:
                connection = get_db_connection()
                if connection:
                    cursor = connection.cursor()
                    placeholders = ", ".join(["%s"] * len(reporting_employee_ids))
                    cursor.execute(
                        f"SELECT ps.employee_id, ps.division, ps.department FROM pe_staff ps "
                        f"INNER JOIN employee_master em ON TRIM(CAST(em.employee_id AS CHAR)) = TRIM(CAST(ps.employee_id AS CHAR)) "
                        f"WHERE {PE_ACTIVE_EMPLOYEE_MASTER_CONDITION} "
                        f"AND {PE_PERMANENT_EMPLOYEE_MASTER_CONDITION} "
                        f"AND ps.employee_id IN ({placeholders})",
                        reporting_employee_ids
                    )
                    staff_reporting_rows = cursor.fetchall()
                    for row in staff_reporting_rows:
                        if not row or len(row) < 3:
                            continue
                        division = str(row[1]).strip() if row[1] is not None else ''
                        department = str(row[2]).strip() if row[2] is not None else ''
                        company = ''
                        if len(row) > 3 and row[3] is not None:
                            company = str(row[3]).strip()
                        if not division or not department or company in TEMP_BLOCKED_PE_COMPANIES:
                            continue
                        division_departments.setdefault(division, set()).add(department)
            except Exception as e:
                print(f"Error loading divisions/departments for distribution filter: {e}")
            finally:
                if cursor:
                    cursor.close()
                if connection:
                    connection.close()

            available_divisions = sorted(division_departments.keys())
            available_departments = sorted({d for deps in division_departments.values() for d in deps})
            available_divisions = [d for d in available_divisions if d not in TSPACE_LABELS]
            available_departments = [d for d in available_departments if d not in TSPACE_LABELS]
            division_departments = {k: sorted(v) for k, v in division_departments.items()}
            show_dept_filters = len(available_departments) > 2

            if selected_division and selected_division != "ALL":
                available_departments = division_departments.get(selected_division, [])
                available_departments = [d for d in available_departments if d not in TSPACE_LABELS]
                if selected_department not in available_departments:
                    selected_department = None

            if staff_reporting_rows:
                if selected_department and selected_department != "ALL":
                    employee_ids_for_filter = [
                        str(row[0]) for row in staff_reporting_rows
                        if row and len(row) >= 3 and str(row[2]).strip() == str(selected_department)
                    ]
                elif selected_division and selected_division != "ALL":
                    employee_ids_for_filter = [
                        str(row[0]) for row in staff_reporting_rows
                        if row and len(row) >= 3 and str(row[1]).strip() == str(selected_division)
                    ]

    force_filter = False
    if is_super_director:
        if selected_department and selected_department != "ALL":
            force_filter = True
        elif selected_division and selected_division != "ALL":
            division_filter = selected_division
            force_filter = True
        elif selected_company and selected_company != "ALL":
            division_filter = available_divisions
            force_filter = True

    baseline_year = 2026
    current_year = max(get_current_fiscal_year(), baseline_year)
    requested_year = max(safe_int(request.args.get('year'), session.get('eval_year', current_year)), baseline_year)
    available_years = [y for y in list_summary_years(str(employee_id)) if y >= baseline_year]
    for y in (requested_year, current_year, baseline_year):
        if y not in available_years:
            available_years.insert(0, y)
    available_years = sorted(set(available_years), reverse=True)
    session['eval_year'] = requested_year

    subordinates = get_director_subordinates(
        division_filter,
        requested_year,
        employee_id,
        force_filter,
        employee_ids=employee_ids_for_filter if employee_ids_for_filter else (reporting_employee_ids if reporting_employee_ids else None)
    )

    subordinates = [
        s for s in subordinates
        if (s.get('position') or '').strip().casefold() != 'managing director'
    ]

    workflow_status_map = get_workflow_status_map(subordinates if isinstance(subordinates, list) else [], requested_year)
    for sub in subordinates:
        if isinstance(sub, dict):
            employee_id_value = str(sub.get('employee_id') or '').strip()
            status_data = workflow_status_map.get(employee_id_value, {
                'code': 'draft',
                'label': 'Draft',
                'bg': 'linear-gradient(135deg, #e2e8f0 0%, #cbd5e1 100%)',
                'color': '#334155',
                'border': '#94a3b8',
            })
            sub['workflow_status'] = dict(status_data)

    scores = []
    for sub in subordinates:
        final_score = safe_float(sub.get('final_total_score'), None)
        if final_score is not None:
            scores.append(final_score)

    distribution_rows = build_performance_distribution_rows(subordinates)
    curve_chart = build_distribution_curve_data(distribution_rows)
    selected_band = (request.args.get('band') or '').strip() or None
    sort_dir = (request.args.get('sort_dir') or 'desc').strip().lower()
    if sort_dir not in {'asc', 'desc'}:
        sort_dir = 'desc'
    dept_compare_company = (request.args.get('dept_compare_company') or '').strip()
    dept_compare_division = (request.args.get('dept_compare_division') or '').strip()
    div_compare_company = (request.args.get('div_compare_company') or '').strip()
    compare_by = 'department'
    if is_super_director:
        if dept_compare_company and dept_compare_company != 'ALL' and dept_compare_company not in available_companies:
            dept_compare_company = ''
        if div_compare_company and div_compare_company != 'ALL' and div_compare_company not in available_companies:
            div_compare_company = ''
        compare_company_options = available_companies
        dept_compare_division_options = []
        division_compare_options = []
        if dept_compare_company and dept_compare_company != 'ALL':
            dept_compare_division_options = [d for d in company_divisions.get(dept_compare_company, []) if d not in TSPACE_LABELS]
        if div_compare_company and div_compare_company != 'ALL':
            division_compare_options = [d for d in company_divisions.get(div_compare_company, []) if d not in TSPACE_LABELS]
        if dept_compare_division and dept_compare_division not in dept_compare_division_options:
            dept_compare_division = ''
        if dept_compare_company and dept_compare_company != 'ALL':
            if dept_compare_division:
                compare_unit_options = [
                    d for d in division_departments.get((dept_compare_company, dept_compare_division), [])
                    if d not in TSPACE_LABELS
                ]
            else:
                compare_unit_options = [d for d in company_departments.get(dept_compare_company, []) if d not in TSPACE_LABELS]
        else:
            compare_unit_options = available_departments
    else:
        compare_unit_options = available_departments
        dept_compare_company = ''
        dept_compare_division = ''
        div_compare_company = ''
        compare_company_options = []
        dept_compare_division_options = []
        division_compare_options = []
    compare_unit_inputs = []
    compare_unit_inputs.extend(request.args.getlist('compare_units'))
    for key in ('compare_unit_1', 'compare_unit_2', 'compare_unit_3', 'compare_unit_4'):
        compare_unit_inputs.append(request.args.get(key))
    selected_compare_units = []
    for unit in compare_unit_inputs:
        unit_name = str(unit or '').strip()
        if unit_name and unit_name in compare_unit_options and unit_name not in selected_compare_units:
            selected_compare_units.append(unit_name)
    selected_compare_units = selected_compare_units[:4]
    compare_cards = build_compare_distribution_cards(subordinates, compare_by, selected_compare_units)
    selected_compare_divisions = []
    for key in ('compare_division_1', 'compare_division_2', 'compare_division_3', 'compare_division_4'):
        division_name = str(request.args.get(key) or '').strip()
        if division_name and division_name in division_compare_options and division_name not in selected_compare_divisions:
            selected_compare_divisions.append(division_name)
    selected_compare_divisions = selected_compare_divisions[:4]
    division_compare_cards = []
    if is_super_director and div_compare_company and div_compare_company != 'ALL':
        division_compare_cards = build_super_admin_division_compare_cards(subordinates, div_compare_company, selected_compare_divisions)
    compare_query_suffix = ''
    keep_focus_section = (request.args.get('keep_focus') or '').strip()
    if dept_compare_company:
        compare_query_suffix += f"&dept_compare_company={quote_plus(dept_compare_company)}"
    if dept_compare_division:
        compare_query_suffix += f"&dept_compare_division={quote_plus(dept_compare_division)}"
    for unit in selected_compare_units:
        compare_query_suffix += f"&compare_units={quote_plus(unit)}"
    if div_compare_company:
        compare_query_suffix += f"&div_compare_company={quote_plus(div_compare_company)}"
    for index, division_name in enumerate(selected_compare_divisions, start=1):
        compare_query_suffix += f"&compare_division_{index}={quote_plus(division_name)}"
    ranked_subordinates = subordinates
    if selected_band:
        ranked_subordinates = [
            sub for sub in subordinates
            if classify_performance_score_band(sub.get('final_total_score')) == selected_band
        ]

    ranked_subordinates = sorted(
        ranked_subordinates,
        key=lambda s: (
            safe_float(s.get('final_total_score'), float('-inf')),
            (s.get('full_name') or '').casefold()
        ),
        reverse=(sort_dir == 'desc')
    )

    per_page = 20
    current_page = max(1, safe_int(request.args.get('page'), 1))
    total_pages = max(1, (len(ranked_subordinates) + per_page - 1) // per_page)
    if current_page > total_pages:
        current_page = total_pages
    start_index = (current_page - 1) * per_page
    ranked_subordinates = ranked_subordinates[start_index:start_index + per_page]

    total_staff = len(subordinates)
    avg_score = (sum(scores) / len(scores)) if scores else 0.0
    median_score = calculate_median_score(scores)
    max_score = max(scores) if scores else 0.0
    min_score = min(scores) if scores else 0.0

    division_scope_text = selected_division if selected_division and selected_division != "ALL" else "All Assigned Divisions"
    if is_super_director and selected_company and selected_company != "ALL" and not selected_division:
        division_scope_text = "All Divisions"
    department_scope_text = selected_department if selected_department and selected_department != "ALL" else None

    nav_html = get_nav_html('performance_dashboard', session.get('job_level'), session.get('full_name', 'N/A'))
    return render_template_string(
        PERFORMANCE_DISTRIBUTION_TEMPLATE,
        nav_html=nav_html,
        page_title="Performance Score Analysis",
        available_years=available_years,
        selected_year=requested_year,
        is_super_director=is_super_director,
        available_companies=available_companies,
        available_divisions=available_divisions,
        available_departments=available_departments,
        selected_company=selected_company,
        selected_division=selected_division,
        selected_department=selected_department,
        show_dept_filters=show_dept_filters,
        company_param=selected_company if selected_company and selected_company != "ALL" else None,
        division_param=selected_division if selected_division and selected_division != "ALL" else None,
        department_param=selected_department if selected_department and selected_department != "ALL" else None,
        division_scope_text=division_scope_text,
        department_scope_text=department_scope_text,
        total_staff=total_staff,
        avg_score=avg_score,
        median_score=median_score,
        max_score=max_score,
        min_score=min_score,
        distribution_rows=distribution_rows,
        curve_chart=curve_chart,
        compare_by=compare_by,
        dept_compare_company=dept_compare_company,
        dept_compare_division=dept_compare_division,
        div_compare_company=div_compare_company,
        compare_company_options=compare_company_options,
        dept_compare_division_options=dept_compare_division_options,
        division_compare_options=division_compare_options,
        compare_unit_options=compare_unit_options,
        selected_compare_units=selected_compare_units,
        compare_cards=compare_cards,
        selected_compare_divisions=selected_compare_divisions,
        division_compare_cards=division_compare_cards,
        compare_query_suffix=compare_query_suffix,
        keep_focus_section=keep_focus_section,
        ranked_subordinates=ranked_subordinates,
        selected_band=selected_band,
        sort_dir=sort_dir,
        row_start=start_index,
        current_page=current_page,
        total_pages=total_pages,
        printed_at_text=datetime.datetime.now().strftime('%d %b %Y %H:%M'),
    )


@app.route('/print_performance_distribution')
def print_performance_distribution():
    return performance_distribution_print_mode()


def performance_distribution_print_mode():
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    employee_id = str(session['employee_id']).strip()
    if employee_id not in SPECIAL_EXPORT_ACCESS and employee_id not in AUTHORIZED_EXPORTER_ID:
        flash("Only directors can access the Performance Score Analysis page.", "error")
        return redirect(url_for('performance_dashboard'))

    reporting_employee_ids = get_reporting_employee_ids(employee_id)
    division_filter = SPECIAL_EXPORT_ACCESS.get(employee_id)
    is_super_director = str(employee_id) in AUTHORIZED_EXPORTER_ID

    selected_division = request.args.get('division')
    selected_department = request.args.get('department')
    selected_company = request.args.get('company')
    if isinstance(selected_division, str):
        selected_division = selected_division.strip()
    if isinstance(selected_department, str):
        selected_department = selected_department.strip()
    if isinstance(selected_company, str):
        selected_company = selected_company.strip()

    available_divisions = []
    available_departments = []
    available_companies = []
    staff_reporting_rows = []
    employee_ids_for_filter = None
    show_dept_filters = False

    if is_super_director:
        connection = None
        cursor = None
        company_divisions = {}
        company_departments = {}
        division_departments = {}
        try:
            connection = get_db_connection()
            if connection:
                cursor = connection.cursor()
                cursor.execute(
                    "SELECT ps.employee_id, ps.company, ps.division, ps.department FROM pe_staff ps "
                    "INNER JOIN employee_master em ON TRIM(CAST(em.employee_id AS CHAR)) = TRIM(CAST(ps.employee_id AS CHAR)) "
                    f"WHERE {PE_ACTIVE_EMPLOYEE_MASTER_CONDITION} "
                    f"AND {PE_PERMANENT_EMPLOYEE_MASTER_CONDITION} "
                    "AND ps.company IS NOT NULL AND ps.company <> '' "
                    "AND ps.division IS NOT NULL AND ps.division <> '' "
                    "AND ps.department IS NOT NULL AND ps.department <> '' "
                    "ORDER BY ps.company, ps.division, ps.department"
                )
                staff_reporting_rows = cursor.fetchall()
                for row in staff_reporting_rows:
                    if not row or len(row) < 4:
                        continue
                    company = str(row[1]).strip() if row[1] is not None else ''
                    division = str(row[2]).strip() if row[2] is not None else ''
                    department = str(row[3]).strip() if row[3] is not None else ''
                    if not company or not division or not department:
                        continue
                    company_divisions.setdefault(company, set()).add(division)
                    company_departments.setdefault(company, set()).add(department)
                    division_departments.setdefault((company, division), set()).add(department)
        except Exception as e:
            print(f"Error loading companies/divisions for print distribution filter: {e}")
        finally:
            if cursor:
                cursor.close()
            if connection:
                connection.close()

        excluded_divisions = EXCLUDED_DIVISIONS_BY_EMPLOYEE.get(employee_id)
        if excluded_divisions:
            for company, divisions in list(company_divisions.items()):
                filtered = [d for d in divisions if d not in excluded_divisions]
                if filtered:
                    company_divisions[company] = filtered
                else:
                    company_divisions.pop(company, None)
            for company, departments in list(company_departments.items()):
                filtered = [d for d in departments if d not in excluded_divisions]
                if filtered:
                    company_departments[company] = filtered
                else:
                    company_departments.pop(company, None)
            division_departments = {
                k: v for k, v in division_departments.items()
                if k[1] not in excluded_divisions
            }

        available_companies = sorted(company_divisions.keys())
        available_divisions = sorted({d for divisions in company_divisions.values() for d in divisions})
        available_departments = sorted({d for deps in company_departments.values() for d in deps})
        available_divisions = [d for d in available_divisions if d not in TSPACE_LABELS]
        available_departments = [d for d in available_departments if d not in TSPACE_LABELS]
        company_divisions = {k: sorted(v) for k, v in company_divisions.items()}
        company_departments = {k: sorted(v) for k, v in company_departments.items()}
        division_departments = {k: sorted(v) for k, v in division_departments.items()}

        if selected_company and selected_company != 'ALL':
            if selected_company in company_divisions:
                available_divisions = [d for d in company_divisions.get(selected_company, []) if d not in TSPACE_LABELS]
                available_departments = [d for d in company_departments.get(selected_company, []) if d not in TSPACE_LABELS]
                if selected_division and selected_division in available_divisions:
                    available_departments = [d for d in division_departments.get((selected_company, selected_division), []) if d not in TSPACE_LABELS]

        if staff_reporting_rows:
            excluded_divisions = EXCLUDED_DIVISIONS_BY_EMPLOYEE.get(employee_id)
            if excluded_divisions:
                staff_reporting_rows = [
                    row for row in staff_reporting_rows
                    if row and len(row) >= 4 and str(row[2]).strip() not in excluded_divisions and str(row[1]).strip() not in TEMP_BLOCKED_PE_COMPANIES
                ]
            else:
                staff_reporting_rows = [
                    row for row in staff_reporting_rows
                    if row and len(row) >= 4 and str(row[1]).strip() not in TEMP_BLOCKED_PE_COMPANIES
                ]
            if selected_department and selected_department != "ALL":
                employee_ids_for_filter = [
                    str(row[0]) for row in staff_reporting_rows
                    if row and len(row) >= 4 and str(row[3]).strip() == str(selected_department)
                ]
            elif selected_division and selected_division != "ALL":
                employee_ids_for_filter = [
                    str(row[0]) for row in staff_reporting_rows
                    if row and len(row) >= 4 and str(row[2]).strip() == str(selected_division)
                ]
            elif selected_company and selected_company != "ALL":
                employee_ids_for_filter = [
                    str(row[0]) for row in staff_reporting_rows
                    if row and len(row) >= 4 and str(row[1]).strip() == str(selected_company)
                ]
            else:
                employee_ids_for_filter = [str(row[0]) for row in staff_reporting_rows if row and row[0] is not None]
    else:
        if reporting_employee_ids:
            connection = None
            cursor = None
            division_departments = {}
            try:
                connection = get_db_connection()
                if connection:
                    cursor = connection.cursor()
                    placeholders = ", ".join(["%s"] * len(reporting_employee_ids))
                    cursor.execute(
                        f"SELECT ps.employee_id, ps.division, ps.department FROM pe_staff ps "
                        f"INNER JOIN employee_master em ON TRIM(CAST(em.employee_id AS CHAR)) = TRIM(CAST(ps.employee_id AS CHAR)) "
                        f"WHERE {PE_ACTIVE_EMPLOYEE_MASTER_CONDITION} "
                        f"AND {PE_PERMANENT_EMPLOYEE_MASTER_CONDITION} "
                        f"AND ps.employee_id IN ({placeholders})",
                        reporting_employee_ids
                    )
                    staff_reporting_rows = cursor.fetchall()
                    for row in staff_reporting_rows:
                        if not row or len(row) < 3:
                            continue
                        division = str(row[1]).strip() if row[1] is not None else ''
                        department = str(row[2]).strip() if row[2] is not None else ''
                        if not division or not department:
                            continue
                        division_departments.setdefault(division, set()).add(department)
            except Exception as e:
                print(f"Error loading divisions/departments for print distribution filter: {e}")
            finally:
                if cursor:
                    cursor.close()
                if connection:
                    connection.close()

            available_divisions = sorted([d for d in division_departments.keys() if d not in TSPACE_LABELS])
            available_departments = sorted({d for deps in division_departments.values() for d in deps if d not in TSPACE_LABELS})
            show_dept_filters = len(available_departments) > 2
            if staff_reporting_rows:
                if selected_department and selected_department != "ALL":
                    employee_ids_for_filter = [
                        str(row[0]) for row in staff_reporting_rows
                        if row and len(row) >= 3 and str(row[2]).strip() == str(selected_department)
                    ]
                elif selected_division and selected_division != "ALL":
                    employee_ids_for_filter = [
                        str(row[0]) for row in staff_reporting_rows
                        if row and len(row) >= 3 and str(row[1]).strip() == str(selected_division)
                    ]

    force_filter = False
    if is_super_director:
        if selected_department and selected_department != "ALL":
            force_filter = True
        elif selected_division and selected_division != "ALL":
            division_filter = selected_division
            force_filter = True
        elif selected_company and selected_company != "ALL":
            division_filter = available_divisions
            force_filter = True

    baseline_year = 2026
    current_year = max(get_current_fiscal_year(), baseline_year)
    requested_year = max(safe_int(request.args.get('year'), session.get('eval_year', current_year)), baseline_year)

    subordinates = get_director_subordinates(
        division_filter,
        requested_year,
        employee_id,
        force_filter,
        employee_ids=employee_ids_for_filter if employee_ids_for_filter else (reporting_employee_ids if reporting_employee_ids else None)
    )
    subordinates = [s for s in subordinates if (s.get('position') or '').strip().casefold() != 'managing director']

    workflow_status_map = get_workflow_status_map(subordinates if isinstance(subordinates, list) else [], requested_year)
    for sub in subordinates:
        if isinstance(sub, dict):
            employee_id_value = str(sub.get('employee_id') or '').strip()
            status_data = workflow_status_map.get(employee_id_value, {
                'code': 'draft',
                'label': 'Draft',
                'bg': 'linear-gradient(135deg, #e2e8f0 0%, #cbd5e1 100%)',
                'color': '#334155',
                'border': '#94a3b8',
            })
            sub['workflow_status'] = dict(status_data)

    scores = []
    for sub in subordinates:
        final_score = safe_float(sub.get('final_total_score'), None)
        if final_score is not None:
            scores.append(final_score)

    distribution_rows = build_performance_distribution_rows(subordinates)
    curve_chart = build_distribution_curve_data(distribution_rows)
    selected_band = (request.args.get('band') or '').strip() or None
    sort_dir = (request.args.get('sort_dir') or 'desc').strip().lower()
    if sort_dir not in {'asc', 'desc'}:
        sort_dir = 'desc'
    ranked_subordinates = subordinates
    if selected_band:
        ranked_subordinates = [
            sub for sub in subordinates
            if classify_performance_score_band(sub.get('final_total_score')) == selected_band
        ]

    ranked_subordinates = sorted(
        ranked_subordinates,
        key=lambda s: (
            safe_float(s.get('final_total_score'), float('-inf')),
            (s.get('full_name') or '').casefold()
        ),
        reverse=(sort_dir == 'desc')
    )

    total_staff = len(subordinates)
    avg_score = (sum(scores) / len(scores)) if scores else 0.0
    median_score = calculate_median_score(scores)
    max_score = max(scores) if scores else 0.0
    min_score = min(scores) if scores else 0.0

    division_scope_text = selected_division if selected_division and selected_division != "ALL" else "All Assigned Divisions"
    if is_super_director and selected_company and selected_company != "ALL" and not selected_division:
        division_scope_text = "All Divisions"
    department_scope_text = selected_department if selected_department and selected_department != "ALL" else None

    return render_template_string(
        PERFORMANCE_DISTRIBUTION_PRINT_TEMPLATE,
        selected_year=requested_year,
        selected_company=selected_company,
        is_super_director=is_super_director,
        division_scope_text=division_scope_text,
        department_scope_text=department_scope_text,
        selected_band=selected_band,
        sort_dir=sort_dir,
        printed_at_text=datetime.datetime.now().strftime('%d %b %Y %H:%M'),
        total_staff=total_staff,
        avg_score=avg_score,
        median_score=median_score,
        max_score=max_score,
        min_score=min_score,
        curve_chart=curve_chart,
        distribution_rows=distribution_rows,
        ranked_subordinates=ranked_subordinates,
    )


@app.route('/director_export_csv')
def director_export_csv():
    """Export subordinates' detailed scores as CSV for directors."""
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    employee_id = str(session['employee_id']).strip()

    reporting_employee_ids = get_reporting_employee_ids(employee_id)
    if not reporting_employee_ids and employee_id not in SPECIAL_EXPORT_ACCESS:
        flash("You do not have permission to export.", "error")
        return redirect(url_for('profile_page'))

    division_filter = SPECIAL_EXPORT_ACCESS.get(employee_id)

    temp_csv_file_name = f'director_export_{employee_id}_{int(time.time())}.csv'
    temp_fd, temp_file_path = tempfile.mkstemp(suffix='.csv', prefix='director_export_')
    os.close(temp_fd)

    if export_scores_to_csv(temp_file_path, division_filter, employee_ids=reporting_employee_ids if reporting_employee_ids else None):
        @after_this_request
        def remove_file(response):
            try:
                if os.path.exists(temp_file_path):
                    os.remove(temp_file_path)
            except Exception as error:
                app.logger.error("Error cleaning up temporary file %s: %s", temp_file_path, error)
            return response

        try:
            response = send_file(
                temp_file_path,
                as_attachment=True,
                mimetype='text/csv',
                download_name=temp_csv_file_name
            )
            return response
        except Exception as e:
            if os.path.exists(temp_file_path):
                os.remove(temp_file_path)
            flash("Error processing the CSV file for download. Please try again.", "error")
            return redirect(url_for('performance_dashboard'))
    else:
        flash("Error exporting scores. Please try again.", "error")
        return redirect(url_for('performance_dashboard'))


@app.route('/director_export_summary_csv')
def director_export_summary_csv():
    """Export subordinates' summary scores as CSV for directors."""
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    employee_id = str(session['employee_id']).strip()

    reporting_employee_ids = get_reporting_employee_ids(employee_id)
    if not reporting_employee_ids and employee_id not in SPECIAL_EXPORT_ACCESS:
        flash("You do not have permission to export.", "error")
        return redirect(url_for('profile_page'))

    division_filter = SPECIAL_EXPORT_ACCESS.get(employee_id)

    temp_csv_file_name = f'director_summary_export_{employee_id}_{int(time.time())}.csv'
    temp_fd, temp_file_path = tempfile.mkstemp(suffix='.csv', prefix='director_summary_')
    os.close(temp_fd)

    if export_summary_to_csv(temp_file_path, division_filter, employee_ids=reporting_employee_ids if reporting_employee_ids else None):
        @after_this_request
        def remove_file(response):
            try:
                if os.path.exists(temp_file_path):
                    os.remove(temp_file_path)
            except Exception as error:
                app.logger.error("Error cleaning up temporary file %s: %s", temp_file_path, error)
            return response

        try:
            response = send_file(
                temp_file_path,
                as_attachment=True,
                mimetype='text/csv',
                download_name=temp_csv_file_name
            )
            return response
        except Exception as e:
            if os.path.exists(temp_file_path):
                os.remove(temp_file_path)
            flash("Error processing the CSV file for download. Please try again.", "error")
            return redirect(url_for('performance_dashboard'))
    else:
        flash("Error exporting summary. Please try again.", "error")
        return redirect(url_for('performance_dashboard'))


@app.route('/director_view_subordinate/<employee_id>')
def director_view_subordinate(employee_id):
    """Allow directors to view a subordinate's PE form summary."""
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    director_id = str(session['employee_id']).strip()

    reporting_employee_ids = get_reporting_employee_ids(director_id)
    if not reporting_employee_ids and director_id not in SPECIAL_EXPORT_ACCESS:
        flash("You do not have permission to view this page.", "error")
        return redirect(url_for('profile_page'))

    division_filter = SPECIAL_EXPORT_ACCESS.get(director_id)

    # Verify the subordinate is in director's division
    subordinate_profile = get_employee_profile(employee_id)
    if not subordinate_profile:
        flash("Employee not found.", "error")
        return redirect(url_for('performance_dashboard'))

    subordinate_division = subordinate_profile.get('division')

    if reporting_employee_ids:
        if str(employee_id) not in [str(eid) for eid in reporting_employee_ids]:
            flash("You do not have permission to view this employee.", "error")
            return redirect(url_for('performance_dashboard'))
    else:
        # Check if subordinate is in director's allowed divisions
        if division_filter is not None:
            if isinstance(division_filter, list):
                if subordinate_division not in division_filter:
                    flash("You do not have permission to view this employee.", "error")
                    return redirect(url_for('performance_dashboard'))
            else:
                if subordinate_division != division_filter:
                    flash("You do not have permission to view this employee.", "error")
                    return redirect(url_for('performance_dashboard'))

    # Redirect to the subordinate's summary page (read-only view)
    # Store the subordinate's employee_id temporarily to view their data
    session['viewing_subordinate'] = employee_id
    session['is_director_view'] = True

    return redirect(url_for('director_subordinate_summary', employee_id=employee_id))


@app.route('/director_print_summary/<employee_id>')
def director_print_summary(employee_id):
    """Allow directors to print a subordinate's PE summary."""
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    director_id = str(session['employee_id']).strip()

    reporting_employee_ids = get_reporting_employee_ids(director_id)
    if not reporting_employee_ids and director_id not in SPECIAL_EXPORT_ACCESS:
        flash("You do not have permission to view this page.", "error")
        return redirect(url_for('profile_page'))

    division_filter = SPECIAL_EXPORT_ACCESS.get(director_id)

    profile = get_employee_profile(employee_id)
    if not profile:
        flash("Employee not found.", "error")
        return redirect(url_for('performance_dashboard'))

    subordinate_division = profile.get('division')
    if reporting_employee_ids:
        if str(employee_id) not in [str(eid) for eid in reporting_employee_ids]:
            flash("You do not have permission to view this employee.", "error")
            return redirect(url_for('performance_dashboard'))
    else:
        if division_filter is not None:
            if isinstance(division_filter, list):
                if subordinate_division not in division_filter:
                    flash("You do not have permission to view this employee.", "error")
                    return redirect(url_for('performance_dashboard'))
            else:
                if subordinate_division != division_filter:
                    flash("You do not have permission to view this employee.", "error")
                    return redirect(url_for('performance_dashboard'))

    eval_year = resolve_eval_year_from_request()
    job_level = profile.get('job_level', 0)

    def get_form_data_for_employee(form_id: str) -> Dict[str, Any]:
        if form_id != 'group_kpi' or not uses_admin_managed_group_kpi(profile.get('company')):
            data = load_form_data_from_db(employee_id, form_id, eval_year)
            if data:
                return _normalize_form_data(form_id, data)

        if form_id in ['org_capability', 'people_dev', 'bu_obj']:
            num_rows = 15 if form_id == 'bu_obj' else 10
            return _normalize_form_data(form_id, {
                'descriptions': [''] * num_rows,
                'weights': [''] * num_rows,
                'scores': [''] * num_rows,
                'results': ['0.00'] * num_rows,
                'short_descriptions': [[''] * 5 for _ in range(num_rows)],
                'total_score': '0.00'
            })
        if form_id == 'bu_lob_kpi':
            return _normalize_form_data(form_id, {
                'descriptions': [''] * 5,
                'weights': [''] * 5,
                'scores': [''] * 5,
                'results': ['0.00'] * 5,
                'short_descriptions': [[''] * 5 for _ in range(5)],
                'total_score': '0.00'
            })
        if form_id == 'group_kpi':
            group_weight = get_weight_limit('group_kpi', job_level)
            global_group_data = load_form_data_from_db(GLOBAL_GROUP_KPI_EMPLOYEE_ID[0], 'group_kpi', eval_year)
            group_score_value = safe_get(global_group_data, 'group_score', '') if global_group_data else ''
            group_score_num = safe_float(group_score_value, 0.0)
            group_result_value = "{:.2f}".format((group_score_num * group_weight) / 100) if group_score_value else '0.00'
            return {
                'group_score': group_score_value,
                'group_weight': str(group_weight),
                'group_result': group_result_value
            }
        if form_id in ['core_behaviors', 'leadership_behaviors']:
            return {'scores': {}}
        if form_id == 'comments':
            return {'employee_comments': '', 'supervisor_comments': ''}

        return {}

    def filter_table_data(data, num_rows):
        if not data:
            return []
        filtered_rows = []
        for i in range(num_rows):
            desc_val = data['descriptions'][i].strip() if i < len(data.get('descriptions', [])) and \
                                                          data['descriptions'][i] else ''
            score_val = data['scores'][i].strip() if i < len(data.get('scores', [])) and data['scores'][i] else ''
            if desc_val or score_val:
                filtered_rows.append({'description': desc_val, 'score': score_val})
        return filtered_rows

    group_kpi_data = get_form_data_for_employee('group_kpi')
    bu_lob_kpi_data = get_form_data_for_employee('bu_lob_kpi')
    org_cap_data = get_form_data_for_employee('org_capability')
    people_dev_data = get_form_data_for_employee('people_dev')
    bu_obj_data = get_form_data_for_employee('bu_obj')
    comments_data = get_form_data_for_employee('comments')
    core_behaviors_data = get_form_data_for_employee('core_behaviors')
    leadership_behaviors_data = get_form_data_for_employee('leadership_behaviors')

    bu_lob_kpi_filtered = filter_table_data(bu_lob_kpi_data, 5)
    org_cap_filtered = filter_table_data(org_cap_data, 10)
    people_dev_filtered = filter_table_data(people_dev_data, 10)
    bu_obj_filtered = filter_table_data(bu_obj_data, 15)

    group_score_str = group_kpi_data.get('group_score', '')
    group_score_val = float(group_score_str) if str(group_score_str).replace('.', '', 1).isdigit() else 0
    has_group_kpi_data = (job_level >= 8 and group_score_val > 0)

    summary_data = load_summary_history(employee_id, eval_year)
    if not summary_data:
        summary_data = get_subordinate_summary_data(employee_id) or {}

    return render_template_string(
        PRINT_SUMMARY_HTML,
        profile=profile,
        group_kpi_data=group_kpi_data,
        bu_lob_kpi_data=bu_lob_kpi_data,
        org_cap_data=org_cap_data,
        people_dev_data=people_dev_data,
        bu_obj_data=bu_obj_data,
        comments_data=comments_data,
        core_behaviors_data=core_behaviors_data,
        leadership_behaviors_data=leadership_behaviors_data,
        core_behaviors_map=get_core_behaviors_display_map(job_level),
        leadership_behaviors_map=get_leadership_behaviors_display_map(job_level),
        summary_data=summary_data,
        job_level=job_level,
        bu_lob_kpi_filtered=bu_lob_kpi_filtered,
        org_cap_filtered=org_cap_filtered,
        people_dev_filtered=people_dev_filtered,
        bu_obj_filtered=bu_obj_filtered,
        has_group_kpi_data=has_group_kpi_data,
        selected_year=eval_year,
    )


DIRECTOR_SUBORDINATE_SUMMARY_TEMPLATE = BASE_WITH_NAV.replace('{% block content %}{% endblock %}', '''
{% block content %}
<div style="display:flex; justify-content:center; margin-bottom: 14px;">
    <img src="{{ photo_src }}"
         alt="Staff Photo"
         style="width: 108px; height: 108px; border-radius: 999px; object-fit: cover; border: 3px solid #e5e7eb; background: #f8fafc;"
         onerror="this.onerror=null;this.src='{{ url_for('user_photo_placeholder', name=profile.full_name) }}';">
</div>

<div class="header-section">
    <h1 class="gradient-text">{{ profile.full_name }}</h1>
    <p>Performance Evaluation Summary</p>
</div>

<div class="button-group" style="margin-top: 0; margin-bottom: 20px;">
    <a href="{{ url_for('supervisor_behavior_review', employee_id=profile.employee_id, year=selected_year if selected_year is defined else session.eval_year) }}" class="btn-primary">Supervisor Review</a>
</div>

<div style="background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%); padding: 20px; border-radius: 12px; margin-bottom: 20px;">
    <div style="display: flex; flex-wrap: wrap; gap: 12px 24px; align-items: center;">
        <div><strong>Employee ID:</strong> {{ profile.employee_id }}</div>
        <div><strong>Division/Department:</strong> {{ profile.division }}</div>
        <div><strong>Position:</strong> {{ profile.position }}</div>
        <div><strong>Job Level:</strong> {{ profile.job_level }}</div>
    </div>
</div>

{% if summary %}
<div style="
    background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
    color: white;
    padding: 30px;
    border-radius: 16px;
    text-align: center;
    margin: 30px auto;
    width: fit-content;">

    <h2 style="color: white; font-size: 3em; margin-bottom: 10px; margin-top: 0;">
        {{ summary.final_total_score }} / 5.00
    </h2>
    <p style="font-size: 1.3em; opacity: 0.95; margin-bottom: 0;">
        Final Performance Score
    </p>
</div>

<div style="margin: 40px 0;">
    <h2 class="gradient-text" style="font-size: 1.8em; margin-bottom: 20px;">Score Components Breakdown</h2>

    <table class="modern-table summary-table">
        <colgroup>
            <col style="width: 70%;">
            <col style="width: 10%;">
            <col style="width: 10%;">
            <col style="width: 10%;">
        </colgroup>
        <thead>
            <tr>
                <th>Component</th>
                <th style="text-align: center;">Weight (%)</th>
                <th style="text-align: right;">Score</th>
                <th style="text-align: right;">Weighted Score</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td colspan="4" style="background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%); font-weight: bold;">
                    <span class="summary-accent-text">Performance KPI Components ({{ summary.perf_kpi_weight_pct }}%)</span>
                </td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">Group Shared KPI</td>
                <td style="text-align: center;">{{ summary.group_kpi_weight }}</td>
                <td style="text-align: right;">{{ summary.group_kpi_avg_score }}</td>
                <td style="text-align: right;">{{ summary.group_kpi_score }}</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">BU/LoB Shared KPI</td>
                <td style="text-align: center;">{{ summary.bu_lob_kpi_weight }}</td>
                <td style="text-align: right;">{{ summary.bu_lob_kpi_avg_score }}</td>
                <td style="text-align: right;">{{ summary.bu_lob_kpi_score }}</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">Organizational Capability Development</td>
                <td style="text-align: center;">{{ summary.org_cap_weight }}</td>
                <td style="text-align: right;">{{ summary.org_cap_avg_score }}</td>
                <td style="text-align: right;">{{ summary.org_cap_score }}</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">People Development</td>
                <td style="text-align: center;">{{ summary.people_dev_weight }}</td>
                <td style="text-align: right;">{{ summary.people_dev_avg_score }}</td>
                <td style="text-align: right;">{{ summary.people_dev_score }}</td>
            </tr>
            <tr>
                <td style="padding-left: 30px;">Business Unit Objectives</td>
                <td style="text-align: center;">{{ summary.bu_obj_weight }}</td>
                <td style="text-align: right;">{{ summary.bu_obj_avg_score }}</td>
                <td style="text-align: right;">{{ summary.bu_obj_score }}</td>
            </tr>

            <tr style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);">
                <td><strong>Performance KPI</strong></td>
                <td style="text-align: center;"><strong>{{ summary.perf_kpi_weight_pct }}%</strong></td>
                <td style="text-align: right;"><strong>{{ summary.total_kpi_score }}</strong></td>
                <td style="text-align: right;"><strong>{{ summary.perf_kpi_score }}</strong></td>
            </tr>

            {% if summary.core_behaviors_weight_pct > 0 %}
            <tr>
                <td><strong>Core Behaviors</strong></td>
                <td style="text-align: center;"><strong>{{ summary.core_behaviors_weight_pct }}%</strong></td>
                <td style="text-align: right;"><strong>{{ summary.core_behaviors_avg }}</strong></td>
                <td style="text-align: right;"><strong>{{ summary.core_behaviors_score }}</strong></td>
            </tr>
            {% endif %}

            {% if summary.leadership_behaviors_weight_pct > 0 %}
            <tr>
                <td><strong>Leadership Behaviors</strong></td>
                <td style="text-align: center;"><strong>{{ summary.leadership_behaviors_weight_pct }}%</strong></td>
                <td style="text-align: right;"><strong>{{ summary.leadership_behaviors_avg }}</strong></td>
                <td style="text-align: right;"><strong>{{ summary.leadership_behaviors_score }}</strong></td>
            </tr>
            {% endif %}

            <tr style="background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);">
                <td><strong class="summary-accent-text">Total Weight/Final Score</strong></td>
                <td style="text-align: center;"><strong>{{ summary.total_weight }}%</strong></td>
                <td style="text-align: right;"><strong>-</strong></td>
                <td style="text-align: right;"><strong style="font-size: 1.3em; color: #16a34a;">{{ summary.final_total_score }}</strong></td>
            </tr>
        </tbody>
    </table>
</div>

{% if supervisor_review_summary and supervisor_review_summary.has_review %}
<div class="content-card" style="margin-top: 24px;">
    <div style="display:flex; justify-content:space-between; align-items:center; gap:12px; margin-bottom: 12px; flex-wrap: wrap;">
        <h2 class="gradient-text" style="margin-bottom: 0;">Supervisor Review Result</h2>
        <span style="
            display:inline-flex;
            align-items:center;
            padding: 7px 14px;
            border-radius: 999px;
            font-size: 0.92em;
            font-weight: 700;
            {% if supervisor_review_summary.status_finalized %}
            background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
            color: #1e3a8a;
            border: 1px solid #93c5fd;
            {% else %}
            background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
            color: #92400e;
            border: 1px solid #f59e0b;
            {% endif %}
        ">{{ supervisor_review_summary.status_label }}</span>
    </div>
    <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 10px; margin-bottom: 16px;">
        <div class="info-box" style="margin-bottom: 0;">
            <div class="info-box-title">Last Reviewed By</div>
            <div class="info-box-text">{{ supervisor_review_summary.status_meta.last_reviewed_by_name or '-' }}</div>
            <div style="margin-top: 6px; color: #64748b; font-size: 0.92em;">{{ supervisor_review_summary.status_meta.last_reviewed_at_text or '-' }}</div>
        </div>
        <div class="info-box" style="margin-bottom: 0;">
            <div class="info-box-title">Finalized By</div>
            <div class="info-box-text">{{ supervisor_review_summary.status_meta.finalized_by_name or '-' }}</div>
            <div style="margin-top: 6px; color: #64748b; font-size: 0.92em;">{{ supervisor_review_summary.status_meta.finalized_at_text or '-' }}</div>
        </div>
    </div>
    {% if supervisor_review_summary.comment %}
    <div class="info-box" style="margin-bottom: 16px;">
        <div class="info-box-title">Supervisor Review Comment</div>
        <div class="info-box-text">{{ supervisor_review_summary.comment }}</div>
    </div>
    {% endif %}
    {% if supervisor_review_summary.group_kpi %}
    <table class="modern-table" style="margin-bottom: 16px;">
        <thead>
            <tr>
                <th>Description</th>
                <th style="text-align:right;">Final Score</th>
                <th style="text-align:right;">Weighted Score</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>{{ supervisor_review_summary.group_kpi.description }}</td>
                <td style="text-align:right;">{{ supervisor_review_summary.group_kpi.admin_score }}</td>
                <td style="text-align:right;">{{ supervisor_review_summary.group_kpi.admin_result }}</td>
            </tr>
        </tbody>
    </table>
    {% endif %}

    {% for section in supervisor_review_summary.kpi_sections %}
    <div style="margin-bottom: 16px;">
        <h3 class="gradient-text" style="font-size: 1.1em; margin-bottom: 10px;">{{ section.title }}</h3>
        <table class="modern-table">
            <thead>
                <tr>
                    <th>Description</th>
                    <th style="text-align:right;">Employee Score</th>
                    <th style="text-align:right;">Employee Result</th>
                    <th style="text-align:right;">Supervisor Score</th>
                    <th style="text-align:right;">Supervisor Result</th>
                </tr>
            </thead>
            <tbody>
                {% for row in section.rows %}
                <tr>
                    <td>{{ row.description }}</td>
                    <td style="text-align:right;">{{ row.employee_score }}</td>
                    <td style="text-align:right;">{{ row.employee_result }}</td>
                    <td style="text-align:right;">{{ row.supervisor_score or '-' }}</td>
                    <td style="text-align:right;">{{ row.supervisor_result }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
    </div>
    {% endfor %}

    {% if supervisor_review_summary.core_items %}
    <div style="margin-bottom: 16px;">
        <h3 class="gradient-text" style="font-size: 1.1em; margin-bottom: 10px;">Core Behaviors</h3>
        <table class="modern-table">
            <thead>
                <tr>
                    <th>Dimensions</th>
                    <th style="text-align:right;">Self Score</th>
                    <th style="text-align:right;">Supervisor Score</th>
                </tr>
            </thead>
            <tbody>
                {% for item in supervisor_review_summary.core_items %}
                <tr>
                    <td>{{ item[0] }}</td>
                    <td style="text-align:right;">{{ item[1] }}</td>
                    <td style="text-align:right;">{{ item[2] }}</td>
                </tr>
                {% endfor %}
                <tr>
                    <td style="background: #dbeafe;"><strong>Average Score</strong></td>
                    <td style="text-align:right; background: #dbeafe;"><strong>-</strong></td>
                    <td style="text-align:right; background: #dbeafe;"><strong>{{ supervisor_review_summary.core_avg }}</strong></td>
                </tr>
            </tbody>
        </table>
    </div>
    {% endif %}

    {% if supervisor_review_summary.leadership_items %}
    <div style="margin-bottom: 16px;">
        <h3 class="gradient-text" style="font-size: 1.1em; margin-bottom: 10px;">Leadership Behaviors</h3>
        <table class="modern-table">
            <thead>
                <tr>
                    <th>Dimensions</th>
                    <th style="text-align:right;">Self Score</th>
                    <th style="text-align:right;">Supervisor Score</th>
                </tr>
            </thead>
            <tbody>
                {% for item in supervisor_review_summary.leadership_items %}
                <tr>
                    <td>{{ item[0] }}</td>
                    <td style="text-align:right;">{{ item[1] }}</td>
                    <td style="text-align:right;">{{ item[2] }}</td>
                </tr>
                {% endfor %}
                <tr>
                    <td style="background: #dbeafe;"><strong>Average Score</strong></td>
                    <td style="text-align:right; background: #dbeafe;"><strong>-</strong></td>
                    <td style="text-align:right; background: #dbeafe;"><strong>{{ supervisor_review_summary.leadership_avg }}</strong></td>
                </tr>
            </tbody>
        </table>
    </div>
    {% endif %}
</div>
{% endif %}
{% else %}
<div class="alert-warning">
    <strong>No scores available.</strong> This employee has not completed their performance evaluation yet.
</div>
{% endif %}

{% if form_details %}
<div class="content-card" style="margin-top: 30px;">
    <h2 class="gradient-text" style="margin-bottom: 10px;">Form Details</h2>
    <p style="color: #64748b; margin-bottom: 20px;">All submitted form data for this employee and year.</p>
</div>

{% for form in form_details %}
<div class="content-card" style="margin-top: 20px;">
    <h3 class="gradient-text" style="margin-bottom: 15px;">{{ form.title }}</h3>

    {% if form.type == 'group' %}
        {% if form.data %}
        <table class="modern-table">
            <thead>
                <tr>
                    <th>Description</th>
                    <th style="text-align:right;">Employee Score</th>
                    <th style="text-align:right;">Employee Result</th>
                    <th style="text-align:right;">Supervisor Score</th>
                    <th style="text-align:right;">Supervisor Result</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{ form.data.group_desc or 'Group Shared KPI' }}</td>
                    <td style="text-align:right;">{{ "%.2f"|format((form.data.group_score or 0)|float) }}</td>
                    <td style="text-align:right;">{{ "%.2f"|format((form.data.group_result or 0)|float) }}</td>
                    <td style="text-align:right;">{{ form.review_score }}</td>
                    <td style="text-align:right;">{{ form.review_result }}</td>
                </tr>
            </tbody>
        </table>
        {% else %}
        <div class="alert-warning">No data available.</div>
        {% endif %}
    {% elif form.type == 'kpi' %}
        {% if form.rows %}
        <div style="overflow-x: auto;">
            <table class="modern-table">
                <thead>
                    <tr>
                        <th style="width: 70%;">Description</th>
                        <th style="text-align:right; width: 8%;">Weight (%)</th>
                        <th style="text-align:right; width: 8%;">Employee Score</th>
                        <th style="text-align:right; width: 8%;">Employee Result</th>
                        <th style="text-align:right; width: 8%;">Supervisor Score</th>
                        <th style="text-align:right; width: 8%;">Supervisor Result</th>
                    </tr>
                </thead>
                <tbody>
                    {% for row in form.rows %}
                    <tr>
                        <td>{{ row.description or '-' }}</td>
                        <td style="text-align:right;">{{ row.weight or '-' }}{% if row.weight %}%{% endif %}</td>
                        <td style="text-align:right;">{{ row.score or '-' }}</td>
                        <td style="text-align:right;">{{ row.result or '-' }}</td>
                        <td style="text-align:right;">{{ row.review_score or '-' }}</td>
                        <td style="text-align:right;">{{ row.review_result or '-' }}</td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>
        </div>
        {% else %}
        <div class="alert-warning">No data available.</div>
        {% endif %}
    {% elif form.type == 'behaviors' %}
        {% if form.behavior_items %}
        <table class="modern-table">
            <thead>
                <tr>
                    <th>Dimensions</th>
                    <th style="text-align:right;">Self Score</th>
                    <th style="text-align:right;">Supervisor Score</th>
                </tr>
            </thead>
            <tbody>
                {% for item in form.behavior_items %}
                <tr>
                    <td>{{ item[0] }}</td>
                    <td style="text-align:right;">{{ item[1] }}</td>
                    <td style="text-align:right;">{{ item[2] }}</td>
                </tr>
                {% endfor %}
                <tr>
                    <td style="background: #dbeafe;"><strong>Average Score</strong></td>
                    <td style="text-align:right; background: #dbeafe;"><strong>{{ form.average_score }}</strong></td>
                    <td style="text-align:right; background: #dbeafe;"><strong>{{ form.review_average_score }}</strong></td>
                </tr>
            </tbody>
        </table>
        {% else %}
        <div class="alert-warning">No data available.</div>
        {% endif %}
    {% elif form.type == 'comments' %}
        {% if form.data %}
        <div class="info-box">
            <div class="info-box-title">Employee Comments</div>
            <div class="info-box-text">{{ form.data.employee_comments or '-' }}</div>
        </div>
        <div class="info-box">
            <div class="info-box-title">Supervisor Comments</div>
            <div class="info-box-text">{{ form.data.supervisor_comments or '-' }}</div>
        </div>
        {% else %}
        <div class="alert-warning">No data available.</div>
        {% endif %}
    {% else %}
        <div class="alert-warning">No data available.</div>
    {% endif %}
</div>
{% endfor %}
{% endif %}

<div class="button-group" style="margin-top: 30px;">
    <a href="{{ url_for('performance_dashboard') }}" class="btn-secondary">Back</a>\r\n    <a href="{{ url_for('director_print_summary', employee_id=profile.employee_id, year=selected_year if selected_year is defined else session.eval_year) }}" class="btn-secondary" target="_blank">Print Summary</a>
    <a href="{{ url_for('performance_dashboard') }}" class="btn-primary">Back to Dashboard</a>
</div>
{% endblock %}
''')


def get_subordinate_summary_data(employee_id):
    """Get the summary data for a subordinate's PE form."""
    conn = get_db_connection()
    if not conn:
        return None

    try:
        cursor = conn.cursor(dictionary=True)

        # Get scores from all_final_scores
        cursor.execute("""
            SELECT * FROM all_final_scores WHERE employee_id = %s
        """, (employee_id,))
        scores = cursor.fetchone()

        if not scores:
            return None

        # Get employee profile for job level
        profile = get_employee_profile(employee_id)
        job_level = profile.get('job_level', 4)

        # Get weight distribution based on job level
        if 4 <= job_level <= 7:
            perf_kpi_weight = 70
            core_behaviors_weight = 30
            leadership_behaviors_weight = 0
        elif 8 <= job_level <= 9:
            perf_kpi_weight = 80
            core_behaviors_weight = 15
            leadership_behaviors_weight = 5
        elif 10 <= job_level <= 11:
            perf_kpi_weight = 90
            core_behaviors_weight = 5
            leadership_behaviors_weight = 5
        elif 12 <= job_level <= 15:
            perf_kpi_weight = 95
            core_behaviors_weight = 0
            leadership_behaviors_weight = 5
        else:
            perf_kpi_weight = 70
            core_behaviors_weight = 30
            leadership_behaviors_weight = 0

        # Build summary data similar to summary_page
        summary_data = {
            'group_kpi_weight': '10' if job_level >= 8 else '0',
            'group_kpi_avg_score': "{:.2f}".format(float(scores.get('group_kpi_score', 0) or 0) / 0.1) if job_level >= 8 and float(scores.get('group_kpi_score', 0) or 0) > 0 else '0.00',
            'group_kpi_score': "{:.2f}".format(float(scores.get('group_kpi_score', 0) or 0)),
            'bu_lob_kpi_weight': '15',
            'bu_lob_kpi_avg_score': "{:.2f}".format(float(scores.get('bu_lob_kpi_total_score', 0) or 0) / 0.15) if float(scores.get('bu_lob_kpi_total_score', 0) or 0) > 0 else '0.00',
            'bu_lob_kpi_score': "{:.2f}".format(float(scores.get('bu_lob_kpi_total_score', 0) or 0)),
            'org_cap_weight': '15',
            'org_cap_avg_score': "{:.2f}".format(float(scores.get('org_cap_total_score', 0) or 0) / 0.15) if float(scores.get('org_cap_total_score', 0) or 0) > 0 else '0.00',
            'org_cap_score': "{:.2f}".format(float(scores.get('org_cap_total_score', 0) or 0)),
            'people_dev_weight': '10',
            'people_dev_avg_score': "{:.2f}".format(float(scores.get('people_dev_total_score', 0) or 0) / 0.1) if float(scores.get('people_dev_total_score', 0) or 0) > 0 else '0.00',
            'people_dev_score': "{:.2f}".format(float(scores.get('people_dev_total_score', 0) or 0)),
            'bu_obj_weight': '20' if job_level < 8 else '10',
            'bu_obj_avg_score': "{:.2f}".format(float(scores.get('bu_obj_total_score', 0) or 0) / (0.2 if job_level < 8 else 0.1)) if float(scores.get('bu_obj_total_score', 0) or 0) > 0 else '0.00',
            'bu_obj_score': "{:.2f}".format(float(scores.get('bu_obj_total_score', 0) or 0)),
            'total_kpi_score': "{:.2f}".format(float(scores.get('perf_kpi_score', 0) or 0) / (perf_kpi_weight / 100)) if float(scores.get('perf_kpi_score', 0) or 0) > 0 else '0.00',
            'perf_kpi_weight_pct': perf_kpi_weight,
            'perf_kpi_score': "{:.2f}".format(float(scores.get('perf_kpi_score', 0) or 0)),
            'core_behaviors_weight_pct': core_behaviors_weight,
            'core_behaviors_avg': "{:.2f}".format(float(scores.get('core_behaviors_avg_score', 0) or 0)),
            'core_behaviors_score': "{:.2f}".format(float(scores.get('core_behaviors_total_score', 0) or 0)),
            'leadership_behaviors_weight_pct': leadership_behaviors_weight,
            'leadership_behaviors_avg': "{:.2f}".format(float(scores.get('leadership_behaviors_avg_score', 0) or 0)),
            'leadership_behaviors_score': "{:.2f}".format(float(scores.get('leadership_behaviors_total_score', 0) or 0)),
            'total_weight': perf_kpi_weight + core_behaviors_weight + leadership_behaviors_weight,
            'final_total_score': "{:.2f}".format(float(scores.get('final_total_score', 0) or 0))
        }

        return summary_data

    except Exception as e:
        print(f"Error getting subordinate summary: {e}")
        return None
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()


@app.route('/director_subordinate_summary/<employee_id>')
def director_subordinate_summary(employee_id):
    """View a subordinate's PE summary (director view)."""
    if 'employee_id' not in session:
        return redirect(url_for('login'))

    director_id = str(session['employee_id']).strip()

    reporting_employee_ids = get_reporting_employee_ids(director_id)
    if not reporting_employee_ids and director_id not in SPECIAL_EXPORT_ACCESS:
        flash("You do not have permission to view this page.", "error")
        return redirect(url_for('profile_page'))

    division_filter = SPECIAL_EXPORT_ACCESS.get(director_id)

    # Get subordinate profile
    profile = get_employee_profile(employee_id)
    if not profile:
        flash("Employee not found.", "error")
        return redirect(url_for('performance_dashboard'))

    # Verify subordinate is in director's division
    subordinate_division = profile.get('division')
    if reporting_employee_ids:
        if str(employee_id) not in [str(eid) for eid in reporting_employee_ids]:
            flash("You do not have permission to view this employee.", "error")
            return redirect(url_for('performance_dashboard'))
    else:
        if division_filter is not None:
            if isinstance(division_filter, list):
                if subordinate_division not in division_filter:
                    flash("You do not have permission to view this employee.", "error")
                    return redirect(url_for('performance_dashboard'))
            else:
                if subordinate_division != division_filter:
                    flash("You do not have permission to view this employee.", "error")
                    return redirect(url_for('performance_dashboard'))

    eval_year = get_eval_year()
    profile_job_level = safe_int(profile.get('job_level'), 0)
    # Get summary data (prefer saved summary history for consistency with Score Summary page)
    summary_data = load_summary_history(employee_id, eval_year)
    if not summary_data:
        summary_data = get_subordinate_summary_data(employee_id)
    form_details = []
    form_definitions = []
    if profile_job_level >= 8:
        form_definitions.append(('group_kpi', 'Group Shared KPI'))
    form_definitions.extend([
        ('bu_lob_kpi', 'BU/LoB Shared KPI'),
        ('org_capability', 'Organizational Capability Development'),
    ])
    if profile_job_level >= 8:
        form_definitions.append(('people_dev', 'People Development'))
    form_definitions.append(('bu_obj', 'Business Unit Objectives'))
    if profile_job_level <= 11:
        form_definitions.append(('core_behaviors', 'Core Behaviors'))
    if profile_job_level >= 8:
        form_definitions.append(('leadership_behaviors', 'Leadership Behaviors'))
    form_definitions.append(('comments', 'Comments'))
    kpi_rows_map = {
        'bu_lob_kpi': 5,
        'org_capability': 10,
        'people_dev': 10,
        'bu_obj': 15,
    }

    for form_id, title in form_definitions:
        data = load_form_data_from_db(employee_id, form_id, eval_year)
        if data:
            data = _normalize_form_data(form_id, data)

        entry = {'id': form_id, 'title': title, 'data': data}
        if form_id == 'group_kpi':
            entry['type'] = 'group'
            review_data = load_supervisor_review_from_db(employee_id, form_id, eval_year) or {}
            entry['review_score'] = "{:.2f}".format(safe_float(review_data.get('group_score'), 0.0)) if safe_float(review_data.get('group_score'), 0.0) > 0 else '-'
            entry['review_result'] = "{:.2f}".format(safe_float(review_data.get('group_result'), 0.0)) if safe_float(review_data.get('group_result'), 0.0) > 0 else '-'
        elif form_id in kpi_rows_map:
            entry['type'] = 'kpi'
            review_data = load_supervisor_review_from_db(employee_id, form_id, eval_year) or {}
            review_scores = review_data.get('scores', []) if isinstance(review_data.get('scores'), list) else []
            review_results = review_data.get('results', []) if isinstance(review_data.get('results'), list) else []
            rows = []
            num_rows = kpi_rows_map[form_id]
            descriptions = data.get('descriptions', []) if data else []
            weights = data.get('weights', []) if data else []
            scores = data.get('scores', []) if data else []
            results = data.get('results', []) if data else []
            shorts = data.get('short_descriptions', []) if data else []
            for i in range(num_rows):
                short_vals = []
                if i < len(shorts) and isinstance(shorts[i], list):
                    short_vals = [s for s in shorts[i] if s]
                description = descriptions[i] if i < len(descriptions) else ''
                if not str(description or '').strip():
                    continue
                rows.append({
                    'description': description,
                    'weight': weights[i] if i < len(weights) else '',
                    'score': scores[i] if i < len(scores) else '',
                    'result': results[i] if i < len(results) else '',
                    'review_score': review_scores[i] if i < len(review_scores) and review_scores[i] else '-',
                    'review_result': review_results[i] if i < len(review_results) and review_results[i] else '-',
                    'short': ', '.join(short_vals),
                })
            entry['rows'] = rows
        elif form_id in ['core_behaviors', 'leadership_behaviors']:
            entry['type'] = 'behaviors'
            scores = {}
            if data and isinstance(data.get('scores'), dict):
                scores = data.get('scores')
            review_data = load_supervisor_review_from_db(employee_id, form_id, eval_year) or {}
            review_scores, review_avg = summarize_review_scores(review_data)
            behavior_map = (
                get_core_behaviors_display_map(profile.get('job_level'))
                if form_id == 'core_behaviors'
                else get_leadership_behaviors_display_map(profile.get('job_level'))
            )
            behavior_items = []
            numeric_scores = []
            for behavior_id in sorted(behavior_map.keys()):
                try:
                    title = safe_get(behavior_map.get(behavior_id, {}), 'title', str(behavior_id))
                    raw_score = scores.get(str(behavior_id), '')
                    if raw_score in (None, ''):
                        behavior_items.append((title, '-', review_scores.get(str(behavior_id), '-')))
                        continue

                    score_value = safe_float(raw_score, 0.0)
                    numeric_scores.append(score_value)
                    behavior_items.append((title, "{:.2f}".format(score_value), review_scores.get(str(behavior_id), '-')))
                except Exception:
                    continue
            entry['behavior_items'] = behavior_items
            entry['average_score'] = "{:.2f}".format(sum(numeric_scores) / len(numeric_scores)) if numeric_scores else "0.00"
            entry['review_average_score'] = review_avg
        elif form_id == 'comments':
            entry['type'] = 'comments'
        else:
            entry['type'] = 'unknown'

        form_details.append(entry)

    # Build navigation
    nav_html = get_nav_html('performance_dashboard', session.get('job_level'), session.get('full_name', 'N/A'))

    return render_template_string(
        DIRECTOR_SUBORDINATE_SUMMARY_TEMPLATE,
        nav_html=nav_html,
        page_title=f"PE Summary - {profile.get('full_name', 'Employee')}",
        profile=profile,
        summary=summary_data,
        form_details=form_details,
        photo_src=get_employee_photo_src(employee_id, profile.get('full_name'), session.get('access_token')),
        selected_year=eval_year
    )


@app.route('/logout')
def logout():
    session.clear()
    # Redirect to Azure AD logout endpoint, then back to the app
    logout_url = f"{AUTHORITY}/oauth2/v2.0/logout?post_logout_redirect_uri=https://pe.tcc-technology.com/"
    return redirect(logout_url)

@app.route("/healthz")
def healthz():
    return "ok", 200


if __name__ == '__main__':
    verify_table_exists()
    verify_versions_table_exists()
    verify_summary_table_exists()
    verify_supervisor_review_table_exists()
    verify_staff_promotion_table_exists()
    app.run(host='0.0.0.0', port=80, debug=False)
    





















